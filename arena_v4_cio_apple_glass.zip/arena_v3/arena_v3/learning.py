"""
Signal Aggregator (zentrale Entscheidungsinstanz) und Meta-Learner (leistungsabhängige, statistisch abgesicherte Gewichtung).

Lernprinzip (gegen Zufall und Überanpassung):
  * Grundlage sind NETTO-Ergebnisse der Schatten-Konten in R-Vielfachen (Nettogewinn / geplantes Risiko).
  * Zeitliche Gewichtung (Halbwertszeit), Shrinkage Richtung 0 und Konfidenzintervall (untere Schranke zählt).
  * Unter der Mindeststichprobe n_min bleibt ein Agent beim Neutralwert (plus Strategie-Vorwissen, das mit Daten verblasst).
  * Gewichte werden nur alle `learn_every` Kerzen aktualisiert und geglättet; Maximalgewicht ist begrenzt.
  * Statistisch klar negative Agenten werden vorübergehend deaktiviert und danach auf Bewährung wieder zugelassen.
"""
from __future__ import annotations

import math
from collections import namedtuple

from .agents import pearson

Decision = namedtuple("Decision", "sym dir score agreement conflict conf exp_ret risk parts reason blocked")


class MetaLearner:
    def __init__(self, cfg, agent_meta: dict):
        """agent_meta: {name: Agent}"""
        self.cfg = cfg
        self.agents = agent_meta
        self.trades = {a: [] for a in agent_meta}        # (bar, trend, r_multiple)
        self.weights = {a: {"all": 1.0, "up": 1.0, "down": 1.0, "range": 1.0} for a in agent_meta}
        self.disabled_until = {}
        self.reset_bar = {a: 0 for a in agent_meta}
        self.probation = {a for a, ag in agent_meta.items() if getattr(ag, "experimental", False)}   # neue Agenten: erst beweisen
        self.log = []

    # ---------------- Daten ----------------
    def record(self, agent, bar, trend, r):
        if agent in self.trades:
            self.trades[agent].append((int(bar), trend, float(r)))
            if len(self.trades[agent]) > 4000:
                self.trades[agent] = self.trades[agent][-4000:]

    def _stats(self, agent, now_bar, trend=None, since=0):
        hl = self.cfg.half_life_bars
        n = s1 = s2 = 0.0
        for bar, tr, r in self.trades[agent]:
            if bar < since or (trend and tr != trend):
                continue
            w = 0.5 ** (max(0, now_bar - bar) / hl)
            n += w
            s1 += w * r
            s2 += w * r * r
        if n <= 0:
            return 0.0, 0.0, 0.0
        mean = s1 / n
        return n, mean, max(0.0, s2 / n - mean * mean)

    def _estimate(self, n, mean, var):
        k = self.cfg.shrink_k
        m = n * mean / (n + k)                                   # Shrinkage Richtung 0
        se = math.sqrt((var + 1.0) / (n + 1.0))                  # Unsicherheit (Prior-Varianz 1 R^2)
        return m, m - self.cfg.z_conf * se, m + self.cfg.z_conf * se

    # ---------------- Gewichte ----------------
    def _w_perf(self, n, mean, var):
        if n < self.cfg.n_min:
            return 1.0
        _, lcb, _ = self._estimate(n, mean, var)
        return max(self.cfg.w_min, min(self.cfg.w_max, 1.0 + 4.0 * lcb))

    def target_weights(self, agent, now_bar):
        n, mean, var = self._stats(agent, now_bar)
        w_all = self._w_perf(n, mean, var)
        out = {"all": w_all}
        aff = self.agents[agent].affinity
        for tr in ("up", "down", "range"):
            nr, mr, vr = self._stats(agent, now_bar, trend=tr)
            alpha = nr / (nr + 30.0)
            w_r = self._w_perf(nr, mr, vr) if nr >= self.cfg.n_min else w_all
            prior = 1.0 + (aff[tr] - 1.0) * (1 - alpha)               # Vorwissen verblasst mit Daten
            out[tr] = max(self.cfg.w_min, min(self.cfg.w_max, (alpha * w_r + (1 - alpha) * w_all) * prior))
        return out

    def update(self, now_bar, ts=0):
        """Ein Lernzyklus. Gibt einen Protokolleintrag zurück."""
        s = self.cfg.weight_smooth
        events = []
        dis_bars = self.cfg.disable_hours * 3600 / self.cfg.interval_sec
        for a in self.agents:
            if a in self.disabled_until and now_bar >= self.disabled_until[a]:
                del self.disabled_until[a]
                self.probation.add(a)
                self.reset_bar[a] = now_bar
                events.append(f"{a}: auf Bewährung reaktiviert")
            tgt = self.target_weights(a, now_bar)
            for k, v in tgt.items():
                self.weights[a][k] = (1 - s) * self.weights[a][k] + s * v
            n, mean, var = self._stats(a, now_bar, since=self.reset_bar[a])
            if a in self.probation and n >= self.cfg.n_min:
                self.probation.discard(a)
            if a not in self.disabled_until and n >= self.cfg.deact_n:
                _, _, ucb = self._estimate(n, mean, var)
                if ucb < -0.05:
                    self.disabled_until[a] = now_bar + dis_bars
                    events.append(f"{a}: vorübergehend deaktiviert (n={n:.0f}, obere Schranke {ucb:.2f} R)")
        rec = {"bar": now_bar, "ts": ts, "weights": {a: round(w["all"], 3) for a, w in self.weights.items()},
               "disabled": sorted(self.disabled_until), "events": events}
        self.log.append(rec)
        self.log = self.log[-200:]
        return rec

    def weight(self, agent, trend, now_bar):
        if agent in self.disabled_until and now_bar < self.disabled_until[agent]:
            return 0.0
        w = self.weights[agent].get(trend, self.weights[agent]["all"])
        if agent in self.probation:
            w = min(w, 0.3)
        return w

    def reliability(self, agent, now_bar):
        """0..1: wie belastbar ist die bisherige Netto-Performance (Stichprobe UND Qualität)."""
        n, mean, var = self._stats(agent, now_bar)
        if n <= 0:
            return 0.0
        _, lcb, _ = self._estimate(n, mean, var)
        return (n / (n + 40.0)) * max(0.0, min(1.0, 0.5 + 2.0 * lcb))

    def agent_stats(self, agent, now_bar):
        n, mean, var = self._stats(agent, now_bar)
        m, lcb, ucb = self._estimate(n, mean, var) if n > 0 else (0, 0, 0)
        return {"n_eff": round(n, 1), "mean_r": round(mean, 3), "lcb": round(lcb, 3), "ucb": round(ucb, 3)}


class SignalAggregator:
    def __init__(self, cfg, params, agents):
        self.cfg, self.p = cfg, params
        self.agents = {a.name: a for a in agents}
        self.hist = {a.name: [] for a in agents}
        self.div = {a.name: 1.0 for a in agents}
        self.corr = {}

    def record(self, strength_by_agent: dict):
        for a, v in strength_by_agent.items():
            h = self.hist[a]
            h.append(v)
            if len(h) > 400:
                del h[:100]

    def refresh_corr(self):
        """Korrelationen zwischen Agenten -> Diversitätsfaktor (stark korrelierte Agenten zählen weniger)."""
        names = [a for a in self.agents if self.agents[a].in_team and getattr(self.agents[a], "enabled", True)]
        for a in names:
            cs = []
            for b in names:
                if a == b:
                    continue
                n = min(len(self.hist[a]), len(self.hist[b]), 300)
                c = pearson(self.hist[a][-n:], self.hist[b][-n:]) if n >= 30 else 0.0
                self.corr[(a, b)] = c
                cs.append(max(0.0, c))
            self.div[a] = max(0.4, 1.0 / (1.0 + self.cfg.corr_gamma * (sum(cs) / len(cs) if cs else 0.0)))

    def decide(self, sym, sigs: dict, learner: MetaLearner, regime, now_bar, ts, lock_reason=None) -> Decision:
        p, cfg = self.p, self.cfg
        long_w = short_w = num = den = 0.0
        parts, agree_n = [], {1: 0, -1: 0}
        exp_num = risk_num = exp_den = conf_sum = 0.0
        sums = {1: [0.0, 0.0, 0.0, 0.0], -1: [0.0, 0.0, 0.0, 0.0]}   # [Σ w c exp, Σ w c risk, Σ w c, Σ w]
        for name, sg in sigs.items():
            ag = self.agents[name]
            if not ag.in_team or not getattr(ag, "enabled", True):
                continue
            w = learner.weight(name, regime.trend, now_bar) * self.div.get(name, 1.0) * max(0.0, min(2.0, float(getattr(ag, "team_influence", 1.0))))
            if w <= 0:
                continue
            parts.append({"agent": name, "dir": sg.dir, "conf": round(sg.conf, 2), "w": round(w, 2)})
            if sg.dir == 0:
                den += cfg.neutral_weight * w
                continue
            den += w
            num += w * sg.dir * sg.conf
            if sg.dir > 0:
                long_w += w * sg.conf
            else:
                short_w += w * sg.conf
            agree_n[sg.dir] += 1
            sums[sg.dir][0] += w * sg.conf * sg.exp_ret
            sums[sg.dir][1] += w * sg.conf * sg.risk
            sums[sg.dir][2] += w * sg.conf
            sums[sg.dir][3] += w
        score = num / den if den > 0 else 0.0
        tot = long_w + short_w
        agreement = (max(long_w, short_w) / tot) if tot > 0 else 0.0
        conflict = (min(long_w, short_w) / tot) if tot > 0 else 0.0
        d = 1 if score > 0 else -1 if score < 0 else 0
        exp_ret = sums[d][0] / sums[d][2] if d and sums[d][2] > 0 else 0.0
        risk = sums[d][1] / sums[d][2] if d and sums[d][2] > 0 else 0.0
        conf = sums[d][2] / sums[d][3] if d and sums[d][3] > 0 else 0.0
        # Qualitätsfaktor: sind die zustimmenden Agenten insgesamt gut bewertet? (Gewichte < 1 = schlechte Netto-Bilanz)
        quality = min(1.0, sums[d][3] / agree_n[d]) if d and agree_n[d] else 0.0
        conf *= quality
        reason = f"Score {score:+.2f}, Übereinstimmung {agreement:.0%}, Konflikt {conflict:.0%}, {agree_n[d] if d else 0} Agenten"
        blocked = None
        if d == 0 or abs(score) < p["team.consensus"]:
            blocked = "kein Konsens"
        elif quality < 0.4:
            blocked = "Agenten-Gewichte zu niedrig (schlechte Netto-Bilanz)"
        elif agreement < p["team.agreement"]:
            blocked = "Übereinstimmung zu gering"
        elif conflict > cfg.conflict_thr:
            blocked = "widersprüchliche Signale"
        elif agree_n[d] < 2:
            blocked = "weniger als 2 Agenten"
        elif conf < p["team.min_conf"]:
            blocked = "Confidence zu niedrig"
        elif regime.unusual:
            blocked = "ungewöhnliche Marktbedingungen"
        elif regime.vol_pct > p["team.vol_filter"]:
            blocked = "Volatilitätsfilter"
        elif p["team.skip_block"] < 6 and int(ts // 3_600_000 % 24) // 4 == p["team.skip_block"]:
            blocked = "Zeitfilter"
        elif lock_reason:
            blocked = lock_reason
        return Decision(sym, d, score, agreement, conflict, conf, exp_ret, risk, parts, reason, blocked)
