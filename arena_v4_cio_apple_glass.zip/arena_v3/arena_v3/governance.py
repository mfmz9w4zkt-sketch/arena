"""Autonome Team-Governance mit deterministischer, auditierbarer Gewichtung."""
from __future__ import annotations
import time

class ChiefIntelligenceOfficer:
    """Verteilt Team-Einfluss anhand robuster Shadow-Performance; niemals Risikohoheit."""
    def __init__(self, db):
        self.db = db
        self.last = db.kv_get("cio_governance", {}) or {}

    @staticmethod
    def _score(agent, system):
        trades = system.shadow_closed.get(agent.name, [])
        n = len(trades)
        if n < 12:
            return 0.25, "Datenbasis aufbauen"
        wins = sum(max(0.0, t.net_pnl) for t in trades)
        losses = sum(max(0.0, -t.net_pnl) for t in trades)
        pf = wins / losses if losses else (2.0 if wins else 0.0)
        avg_r = sum(t.r_multiple for t in trades) / n
        confidence = min(1.0, n / 60.0)
        score = max(0.0, min(2.0, (0.55 * min(pf, 2.0) + 0.45 * max(-1.0, min(1.0, avg_r + 0.5))) * confidence))
        reason = "Netto-Performance unter Druck" if losses > wins else ("Vorläufige Einstufung – Stichprobe klein" if n < 30 else "Netto-Performance und Stichprobe berücksichtigt")
        return score, reason

    def govern(self, app, force=False):
        sysm = app.systems.get("champion")
        if not sysm: return self.last
        now = time.time()
        if not force and now - float(self.last.get("updated_at", 0)) < 300: return self.last
        ranked = []
        for a in sysm.agents:
            enabled = bool(app.agent_controls.get(a.name, {}).get("enabled", True))
            score, reason = self._score(a, sysm)
            ranked.append((a, enabled, score, reason))
        eligible = sorted((x for x in ranked if x[1]), key=lambda x: x[2], reverse=True)
        max_score = max((x[2] for x in eligible), default=1.0) or 1.0
        decisions = {}
        for rank, (a, enabled, score, reason) in enumerate(eligible):
            influence = max(0.10, min(1.75, 0.25 + 1.25 * score / max_score))
            team_vote = rank < max(1, (len(eligible) * 3 + 4) // 5) and score >= 0.20
            a.enabled, a.in_team, a.team_influence = True, team_vote, influence
            a.manual_rating = max(1, min(5, int(round(1 + 2 * score))))
            decisions[a.name] = {"enabled": True, "team_vote": team_vote, "influence": round(influence, 3), "rating": a.manual_rating, "rank": rank + 1, "score": round(score, 3), "reason": reason, "role": "Lead" if rank == 0 else "Core" if team_vote else "Observer"}
        for a, enabled, score, reason in ranked:
            if not enabled:
                a.enabled, a.in_team, a.team_influence = False, False, 0.0
                decisions[a.name] = {"enabled": False, "team_vote": False, "influence": 0.0, "rating": 1, "rank": None, "score": round(score, 3), "reason": "Vom Nutzer deaktiviert", "role": "Ausgeschaltet"}
        self.last = {"agent": "Chief Intelligence Officer", "updated_at": now, "policy": "Shadow-Netto-Performance, Profit Factor, durchschnittliches R und Stichprobengröße", "decisions": decisions, "risk_authority": False}
        self.db.kv_set("cio_governance", self.last)
        return self.last
