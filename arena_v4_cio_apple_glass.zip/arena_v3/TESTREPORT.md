# Testbericht KI-Trading-Arena V3

Erstellt: 2026-11-08 17:10  |  Python 3.12.3  |  Alle Tests laufen offline (synthetische Daten).

## Ergebnis: **89 von 89 Tests bestanden**

| Test | Ergebnis | Dauer (s) |
|---|---|---|
| S_Hebel_und_Risiko.test_S_hebelgrenze_technisch_erzwungen | bestanden | 0.0 |
| S_Hebel_und_Risiko.test_S_hohe_confidence_allein_loest_keinen_hohen_hebel_aus | bestanden | 0.0 |
| S_Hebel_und_Risiko.test_S_kein_martingale_risiko_sinkt_nach_verlustserie | bestanden | 0.0 |
| S_Hebel_und_Risiko.test_S_keine_hebelerhoehung_nach_verlusten_und_drawdown | bestanden | 0.0 |
| S_Hebel_und_Risiko.test_S_keine_umgehung_der_grenzen_durch_agenten_optimierer_konfiguration | bestanden | 1.07 |
| S_Hebel_und_Risiko.test_S_portfolio_exposure_und_gesamtrisiko_begrenzt | bestanden | 2.47 |
| S_Hebel_und_Risiko.test_S_positionsgroesse_aus_risiko_nicht_aus_hebel | bestanden | 0.0 |
| S_Hebel_und_Risiko.test_S_stop_loss_immer_vor_liquidation_mit_sicherheitsabstand | bestanden | 0.0 |
| S_Hebel_und_Risiko.test_S_tages_wochen_gesamt_limits | bestanden | 0.0 |
| S_Hebel_und_Risiko.test_S_zu_riskante_trades_werden_abgelehnt | bestanden | 0.0 |
| T01_Syntax_Import.test_S_nur_paper_trading_keine_echten_orders | bestanden | 0.0 |
| T01_Syntax_Import.test_T01_syntax_aller_python_dateien | bestanden | 0.14 |
| T01_Syntax_Import.test_T02_importpruefung | bestanden | 0.01 |
| T03_Demo_und_Zyklen.test_T03_demo_modus_und_dashboarddaten | bestanden | 0.61 |
| T03_Demo_und_Zyklen.test_T04_ein_vollstaendiger_zyklus | bestanden | 0.29 |
| T03_Demo_und_Zyklen.test_T05_mehrere_aufeinanderfolgende_zyklen | bestanden | 2.34 |
| T06_Kooperation.test_T06_agenten_kooperation_gemeinsame_entscheidung | bestanden | 0.0 |
| T06_Kooperation.test_T06b_ein_einzelner_agent_loest_keinen_trade_aus | bestanden | 0.0 |
| T06_Kooperation.test_T06c_zufalls_baseline_zaehlt_nicht_zum_team | bestanden | 0.0 |
| T06_Kooperation.test_T07_widerspruechliche_signale | bestanden | 0.0 |
| T06_Kooperation.test_T07b_gegensignal_schliesst_position | bestanden | 0.86 |
| T08_Gewichtung.test_T08_gute_agenten_mehr_gewicht_schlechte_weniger | bestanden | 0.0 |
| T08_Gewichtung.test_T08b_kurzfristiges_glueck_wird_nicht_belohnt | bestanden | 0.0 |
| T08_Gewichtung.test_T08c_statistisch_schlechter_agent_wird_deaktiviert_und_bewaehrung | bestanden | 0.0 |
| T08_Gewichtung.test_T08d_gewichte_bleiben_begrenzt | bestanden | 0.01 |
| T09_Kosten.test_T09_gebuehrenberechnung | bestanden | 0.0 |
| T09_Kosten.test_T10_funding_konstant_konservativ_beide_seiten_zahlen | bestanden | 0.0 |
| T09_Kosten.test_T10b_funding_echte_raten_mit_vorzeichen_und_genau_ein_intervall | bestanden | 0.0 |
| T11_Stops_Liquidation.test_S_maintenance_margin_stufen | bestanden | 0.0 |
| T11_Stops_Liquidation.test_T11_stop_loss_ausfuehrung_mit_slippage | bestanden | 0.0 |
| T11_Stops_Liquidation.test_T11b_kurzluecke_wird_zum_schlechteren_eroeffnungskurs_ausgefuehrt | bestanden | 0.0 |
| T11_Stops_Liquidation.test_T11c_stop_slippage_groesser_als_normale_slippage | bestanden | 0.0 |
| T11_Stops_Liquidation.test_T12_liquidationspreis_formel_und_buchung | bestanden | 0.0 |
| T13_DB.test_T13_datenbankpersistenz | bestanden | 1.48 |
| T13_DB.test_T13b_datei_datenbank_ueberlebt_neuoeffnen | bestanden | 0.02 |
| T14_Neustart.test_T14_neustart_gleiches_ergebnis_wie_durchlauf | bestanden | 3.96 |
| T14_Neustart.test_T14b_schutz_vor_doppelten_trades | bestanden | 0.31 |
| T15_Backtest.test_T15_backtest_reproduzierbar_mit_kosten | bestanden | 7.39 |
| T15_Backtest.test_T15b_kein_lookahead_signale_unabhaengig_von_zukunftsdaten | bestanden | 0.2 |
| T15_Backtest.test_T15c_ergebnis_unabhaengig_von_daten_nach_dem_testende | bestanden | 3.37 |
| T16_WalkForward.test_T16_walk_forward_fenster_ohne_ueberlappung_und_oos_auswertung | bestanden | 11.86 |
| T16_WalkForward.test_T16b_optimierung_nutzt_nur_erlaubten_parameterraum | bestanden | 0.0 |
| T17_ChampionChallenger.test_T17_challenger_nur_nach_robustem_walk_forward | bestanden | 0.0 |
| T17_ChampionChallenger.test_T17b_befoerderung_nur_bei_allen_kriterien | bestanden | 0.0 |
| T17_ChampionChallenger.test_T17c_automatischer_rollback | bestanden | 0.0 |
| T18_Notfall.test_T18_notfallabschaltung_gesamt_drawdown | bestanden | 0.0 |
| T18_Notfall.test_T18b_system_schliesst_positionen_bei_notfall | bestanden | 0.27 |
| T19_Tod.test_T19_ki_stirbt_wenn_geld_bei_null_ist_dauerhaft | bestanden | 1.4 |
| T19_Tod.test_T19b_team_konto_tod | bestanden | 0.26 |
| T20_Dashboard.test_T20_http_state_login_und_seite | bestanden | 0.92 |
| T21_Universum_und_Aggressives_Profil.test_T21_standarduniversum_50_paare_gueltig | bestanden | 0.0 |
| T21_Universum_und_Aggressives_Profil.test_T21b_universum_laeuft_durch_50_paare | bestanden | 1.21 |
| T21_Universum_und_Aggressives_Profil.test_T21c_hohe_hebel_werden_tatsaechlich_genehmigt | bestanden | 0.0 |
| T21_Universum_und_Aggressives_Profil.test_T21d_profile_und_alte_grenzen_als_referenz | bestanden | 0.0 |
| T21_Universum_und_Aggressives_Profil.test_T21e_binance_available_filtert_ungueltige_symbole | bestanden | 0.0 |
| T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22_ohne_login_umleitung_und_401 | bestanden | 0.0 |
| T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22b_cookie_90_tage_httponly_und_funktioniert | bestanden | 0.01 |
| T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22c_cookie_ueberlebt_neustart_manipulation_und_ablauf_werden_abgelehnt | bestanden | 0.0 |
| T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22d_falsches_passwort_und_basic_auth_fuer_skripte | bestanden | 0.01 |
| T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22e_logout_loescht_cookie | bestanden | 0.0 |
| T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22f_agenten_haben_verlauf_signale_positionen_trades | bestanden | 0.01 |
| T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22g_websocket_zustand_ohne_trades_und_mit_cookie | bestanden | 0.02 |
| T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22h_sperre_nach_fuenf_fehlversuchen | bestanden | 0.51 |
| T23_Datenluecken_und_Pruefung.test_T23_align_fuellt_luecken_statt_alle_paare_zu_kuerzen | bestanden | 0.0 |
| T23_Datenluecken_und_Pruefung.test_T23b_align_beginnt_wenn_alle_paare_daten_haben | bestanden | 0.0 |
| T23_Datenluecken_und_Pruefung.test_T23c_live_tick_mit_50_paaren_und_luecken_laeuft | bestanden | 0.63 |
| T23_Datenluecken_und_Pruefung.test_T23d_einzelner_abruffehler_stoppt_nicht_alles | bestanden | 2.17 |
| T23_Datenluecken_und_Pruefung.test_T23e_diagnose_nennt_das_paar_mit_zu_kurzer_historie | bestanden | 0.03 |
| T23_Datenluecken_und_Pruefung.test_T23f_vorab_pruefung_filtert_ungueltig_kurz_und_luecken | bestanden | 0.01 |
| T23_Datenluecken_und_Pruefung.test_T23g_netzwerkproblem_verwirft_keine_paare | bestanden | 0.0 |
| T23_Datenluecken_und_Pruefung.test_T23h_ungueltiges_symbol_wird_nicht_wiederholt | bestanden | 0.0 |
| T23_Datenluecken_und_Pruefung.test_T23i_gesperrter_host_faellt_auf_naechsten_host_zurueck | bestanden | 0.0 |
| T24_Struktur_und_MTF.test_T24_mtf_und_struktur_sind_kausal | bestanden | 0.18 |
| T24_Struktur_und_MTF.test_T24b_mtf_aufwaertstrend_und_unbekannt_bei_wenig_daten | bestanden | 0.0 |
| T24_Struktur_und_MTF.test_T24c_mtf_nutzt_keine_unvollstaendige_hoehere_kerze | bestanden | 0.01 |
| T24_Struktur_und_MTF.test_T24d_struktur_bos_choch_sweep_fvg_und_gleiche_hochs | bestanden | 0.0 |
| T25_Neue_Agenten.test_T25_orderbuch_agent | bestanden | 0.01 |
| T25_Neue_Agenten.test_T25b_derivate_agent | bestanden | 0.01 |
| T25_Neue_Agenten.test_T25c_marktstruktur_agent | bestanden | 0.01 |
| T25_Neue_Agenten.test_T25d_multi_timeframe_agent | bestanden | 0.0 |
| T25_Neue_Agenten.test_T25e_liquidations_agent | bestanden | 0.01 |
| T25_Neue_Agenten.test_T25f_zusatzdaten_buch_zusammenfassung | bestanden | 0.0 |
| T26_Integration_der_neuen_Agenten.test_T26_team_hat_15_agenten_neue_starten_auf_bewaehrung | bestanden | 0.0 |
| T26_Integration_der_neuen_Agenten.test_T26b_backtest_laeuft_und_agenten_ohne_daten_bleiben_neutral | bestanden | 3.55 |
| T26_Integration_der_neuen_Agenten.test_T26c_alter_speicherstand_ohne_neue_agenten_laedt | bestanden | 0.87 |
| T26_Integration_der_neuen_Agenten.test_T26d_live_tick_mit_zusatzdaten_und_ausfaellen | bestanden | 0.09 |
| T26_Integration_der_neuen_Agenten.test_T26e_extras_werden_nur_einmal_je_kerze_geholt | bestanden | 0.0 |
| T26_Integration_der_neuen_Agenten.test_T26f_demo_laeuft_mit_allen_15_agenten | bestanden | 3.32 |
| T26_Integration_der_neuen_Agenten.test_T26g_scalper_meidet_ruhige_maerkte | bestanden | 0.0 |

## Aufgetretene Fehler

Im finalen Lauf keine. (Während der Entwicklung gefundene und behobene Fehler: siehe README, Abschnitt Änderungen/Bugfixes.)

## Beispielhafte Backtesting-Ergebnisse (SYNTHETISCHE Daten!)

Zufallsdaten mit eingebauten Marktphasen. Bei so wenigen Trades sind Sharpe/Profit Factor statistisch wertlos (Zahlen wie Sharpe 5 sind Zufall). **Das sagt nichts über Profitabilität an echten Märkten.** Es belegt nur, dass die Pipeline funktioniert.

**Backtest (Standardparameter, Kerzen 400-3500, seed 11)** (12.7s): Netto -15.80%, Profit Factor 0.21, Sharpe -6.05, Sortino -5.76, Max-Drawdown 15.8%, Trades 27, Gebühren 28.95, Slippage 33.88, Funding 1.15, Liquidationen 0

| Marktphase | Trades | Netto (USDT) | Profit Factor |
|---|---|---|---|
| Seitwaerts | 12 | -51.02 | 0.22 |
| Niedrige Volatilitaet | 3 | 3.83 | 1.91 |
| Bear | 5 | -42.12 | 0.11 |
| Bull | 10 | -46.93 | 0.28 |
| Hohe Volatilitaet | 10 | -47.18 | 0.12 |

**Walk-forward (Out-of-sample, 3 Folds, 4 Versuche je Fold):** Netto -0.50%, PF 0.10, Sharpe -5.98, MaxDD 0.7%, Trades 3. Robust: **False** (Prüfungen: {'pf': False, 'mdd': True, 'trades': False, 'folds': False, 'net_positive': False, 'regimes': False})

| Fold | Training | Test | Train-Score | Basis-Score | OOS Netto | OOS Trades |
|---|---|---|---|---|---|---|
| 0 | [320, 1520] | [1520, 2020] | -0.53 | -1.55 | -0.28% | 2 |
| 1 | [820, 2020] | [2020, 2520] | -0.29 | -1.35 | -0.22% | 1 |
| 2 | [1320, 2520] | [2520, 3020] | -0.55 | -1.19 | 0.00% | 0 |

**Hebel-Studie (feste Stufen, Out-of-sample, Parameter fix):** gewählt **1x** (höchste Rendite hatte 2x). ACHTUNG: nur 1 Trades (< 30) - keine belastbare Aussage. Gewählt wird die beste robuste, risikoadjustierte Stufe (Score aus Rendite, Profit Factor, Sharpe, Sortino, Drawdown, Liquidationen) - nicht die höchste Rendite. Keine Aussage über künftige Profitabilität.

| Hebel | Netto | PF | Sharpe | Sortino | MaxDD | Trades | Liq. | Gebühren | Funding | Margin-Anteil | unsicher abgelehnt | Score |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1x | -0.44% | 0.00 | -5.89 | -5.63 | 0.7% | 1 | 0 | 0.50 | 0.15 | 49.4% | 0 | -0.98 |
| 2x | 0.45% | - | 4.78 | 188749425046400.44 | 0.2% | 0 | 0 | 0.00 | 0.00 | - | 0 | -1.00 |
| 3x | -0.61% | 0.00 | -3.04 | -3.40 | 1.8% | 1 | 0 | 1.46 | 0.44 | 48.6% | 0 | -0.98 |
| 5x | 0.00% | - | - | - | 0.0% | 0 | 0 | 0.00 | 0.00 | - | 0 | -1.00 |
| 10x | -2.25% | 0.00 | -5.89 | -5.63 | 3.5% | 1 | 0 | 2.33 | 0.70 | 23.2% | 0 | -0.98 |
| 15x | -2.25% | 0.00 | -5.89 | -5.63 | 3.5% | 1 | 0 | 2.35 | 0.70 | 15.6% | 0 | -0.98 |
| 20x | -2.25% | 0.00 | -5.89 | -5.63 | 3.5% | 1 | 0 | 2.35 | 0.70 | 11.7% | 0 | -0.98 |

## Vollständig implementiert UND getestet
Execution Simulator (Gebühren, Slippage, Spread, Funding, Gaps, Stop-Loss, Take-Profit, Trailing, Isolated Margin, Maintenance-Margin-Stufen, Liquidation) · Risk Engine (Risiko je Trade bis 5 %, Tages-/Wochen-/Gesamtlimits, Notfallabschaltung, Exposure, Portfoliorisiko, Cooldown) · adaptiver Hebel-Manager bis 125x mit Stufen-Gates · Signal Aggregator mit Konsens, Konflikterkennung, Korrelationsabzug · Meta-Learner (Shrinkage, Konfidenzgrenzen, Halbwertszeit, Deaktivierung, Bewährung) · Marktphasen-Erkennung · Regel-Agenten (15, davon 5 neue auf Bewährung) · Schatten-Konten · KI-Tod bei Geld = 0 · Backtesting (reproduzierbar, ohne Look-ahead) · Walk-forward · Hebel-Studie · eingebauter Optimierer · Champion/Challenger inkl. Rollback · SQLite-Persistenz und Neustart (identisches Ergebnis) · Schutz vor doppelten Orders · Dashboard-Daten, Login, Seite · Demo-Modus.

## Implementiert, aber NICHT automatisch getestet (kein Netzwerk in der Testumgebung)
- Echte Binance-Kursabfrage, Historien-Download, Funding-Historie (Code mit Timeout/Retry/Validierung vorhanden; Validierung getestet, API selbst nicht).
- KI-Agenten (LLM) über die Claude-API (`--llm`): Parsing/Fehlerbehandlung vorhanden, echte Aufrufe ungetestet.
- Optuna-Backend (optional, nicht installiert getestet; Fallback-Suche ist getestet).
- Dauerbetrieb (24/7), Hintergrundoptimierung auf echten Daten, Browser-Darstellung des Dashboards (nur Daten und HTTP getestet, nicht visuell).

## Offene Punkte
- Die Meta-Learner-Gewichte lernen nur aus Schatten-Konten; LLM-Agenten brauchen daher Wochen, bis sie Gewicht bekommen.
- Funding im Backtest ist ohne echte Historie eine konstante, konservative Schätzung.
- Optimierung läuft standardmäßig ohne Schatten-Konten (schneller); die Walk-forward-Auswertung nutzt die volle Pipeline.

## Bekannte Einschränkungen
- Nur Simulation: Spread, Slippage und Liquidität sind Modelle; echte Märkte (Orderbuch, Ausfälle, Liquidationsmotor der Börse) können schlechter sein.
- Kerzen-Auflösung 15 Minuten: Reihenfolge von Stop und Ziel innerhalb einer Kerze ist unbekannt (es wird pessimistisch Stop zuerst angenommen).
- **Es gibt keinen Beleg für Profitabilität.** Alle Beispiel-Ergebnisse stammen aus Zufallsdaten.
