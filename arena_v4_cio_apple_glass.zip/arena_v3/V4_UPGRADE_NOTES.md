# KI-Trading-Arena V4 – Upgrade-Notizen

## Neue Funktionen

- Agent Control Center im Agenten-Detail: Agent global aktivieren/deaktivieren, Team-Abstimmung erlauben/entziehen, manueller Rating-Wert 1–5 und Team-Einfluss 0–200 %.
- Agentensteuerung wird in SQLite unter `agent_controls` gespeichert und beim Neustart sowie beim Aufbau von Champion-/Challenger-Systemen wieder angewendet.
- Einflussfaktor wirkt direkt auf das Gewicht im SignalAggregator; deaktivierte Agenten erzeugen weder neue Schattenkonto-Aufträge noch Team-Stimmen.
- Aktivitätsprofile `conservative`, `normal`, `active`, `high` ändern ausschließlich Signal-Zulassungsschwellen. Zentrale Risiko-, Drawdown- und Positionslimits bleiben unverändert.
- Dashboard-WebSocket-Push alle 0,5 Sekunden, Zustands-Cache 0,4 Sekunden, UI-Render-Throttle 0,5 Sekunden und Trades-Aktualisierung alle 4 Sekunden.
- Trade-Historie lädt initial bis zu 10.000 geschlossene Team-Trades und zeigt 300 pro Seite.
- Globales Paper-Trading-Pausieren löscht ausstehende Orders, verhindert neue Entries und lässt das Management bereits offener Positionen (Stops/TP/Risiko) weiterlaufen.

## Bedienung

1. Tab **Agenten** öffnen.
2. Agent auswählen.
3. `Entscheidungseinfluss` auf 0–200 % einstellen.
4. `Darf im Team abstimmen` ausschalten, wenn der Agent nur beobachtet werden soll.
5. `Bot aktiv` ausschalten, um Signalerzeugung und neue Schattenkonto-Trades des Agenten zu stoppen.
6. Handelsaktivität im selben Tab wählen.

## Sicherheitsgrenzen

- Der Team-Einfluss kann die zentrale Risk Engine nicht umgehen.
- Höhere Aktivitätsprofile lockern ausschließlich Signalhürden, nicht Positionsgrößen-, Hebel-, Verlust- oder Drawdown-Grenzen.
- `high` ist für kontrollierte Paper-Tests gedacht, nicht als Freigabe für Live-Kapital.
- Die Plattform bleibt Paper-Trading-only; es werden keine echten Orders gesendet.

## V4.1 – autonome Team-Governance und Apple-Glass-UI

- Neuer `Chief Intelligence Officer` (CIO) bewertet Agenten anhand der Netto-Ergebnisse ihrer Shadow-Konten, Profit Factor, durchschnittlichem R und Stichprobengröße.
- Der CIO weist automatisch Teamrollen (`Lead`, `Core`, `Observer`) und begrenzte Einflussgewichte zu. Die Einstufung wird persistent gespeichert und standardmäßig spätestens alle fünf Minuten aktualisiert.
- Nutzerseitig bleibt nur die Freigabe/Deaktivierung einzelner Agenten. Teamstimme, Einfluss und Rating werden nicht manuell konfiguriert.
- Deaktivierte Agenten bleiben außerhalb des Teams und erhalten Einfluss 0. Das erneute Aktivieren gibt sie für die automatische CIO-Bewertung frei.
- Die zentrale Risk Engine, harte Verlustlimits und der globale Paper-Trading-Stopp bleiben außerhalb der CIO-Kompetenz.
- Das Dashboard zeigt CIO-Rollen, Rang und Einfluss. Die vorhandene Apple-orientierte Glasoberfläche (Systemschrift, Blur/Saturation, transparente Panels, dezente Verläufe, Light/Dark-Modus) bleibt bestehen.

## Validierung V4.1

- Python-Compile: erfolgreich.
- Dashboard-JavaScript-Syntaxprüfung: erfolgreich.
- Evolution-Unit-Tests: 3/3 erfolgreich.
- Smoke-Test: Demo-App initialisiert 16 Agenten; CIO erstellt 16 Einstufungen; manuelles Deaktivieren bleibt wirksam.
- Vollständiger Integrationstestlauf: innerhalb des verfügbaren Zeitfensters abgebrochen (Timeout); daher keine Aussage über vollständige Testsuite.
