# V4 Runbook
Start (Paper, SAFE): `python start_v3.py live --config config.v4.paper.json` bzw. `python start_v3.py demo`. Passwort: `DASHBOARD_PASSWORD`.
Optionen: `--activity 1-5`, `--risk-profile aggressive_paper` (nur bewusst, Spielgeld).
Tests: `python run_tests.py` (149 Tests, schreibt TESTREPORT.md) oder `python -m unittest discover -s tests -p "test_*.py" -t .` (152 Tests inkl. Evolution). Bericht: `python run_v4_report.py` (synthetisch).
Dashboard (Agenten-Tab): Aktivität, Auto-Hebel, Quality Gate, "Warum nicht öfter?", Ablation; je Agent (antippen): Ein/Aus, Stimmrecht, Hebel-Obergrenze.
API (POST JSON): `/api/agent {agent,enabled,influence,lev_cap}`, `/api/activity {level}`, `/api/gate_mode {mode}`, `/api/auto_leverage {on}`, `/api/contribution`.
Rollback: Challenger mit Drift/Drawdown wird automatisch deaktiviert; Champion bleibt. Gate "beobachtend" sperrt Beförderungen.
Migration: alte SQLite-Stände laden unverändert (neue Felder optional; fehlende `controls` = Standard).
