"""
Zentrale Konfiguration der KI-Trading-Arena V3.

WICHTIG: HARD (HardLimits) ist unveränderlich (frozen dataclass). Die Risk Engine nimmt immer min(Konfiguration, HARD).
Weder Konfigurationsdatei, noch Optimierer, Meta-Learner oder Agenten können diese Grenzen überschreiten.
Alles läuft ausschließlich als Paper Trading (Spielgeld). Live-Trading ist NICHT implementiert.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict, fields

LIVE_TRADING_IMPLEMENTED = False  # bewusst fest: es gibt keinen Code, der echte Orders sendet


@dataclass(frozen=True)
class HardLimits:
    """AGGRESSIVES Profil (nur Paper/Spielgeld): hohe Hebel, hohes Risiko je Trade, viele Positionen.
    Das frühere konservative Profil steht unten als SAFE_LIMITS (zum Vergleich / für Tests)."""
    max_leverage: int = 125            # absolute Hebel-Obergrenze (Binance-Maximum bei BTC/ETH)
    max_risk_per_trade: float = 0.05   # max. 5 % der Kontoequity Verlust pro Trade (bei Stop-Loss, inkl. Kosten)
    max_daily_loss: float = 0.15       # 15 % Tagesverlust -> keine neuen Positionen
    max_weekly_loss: float = 0.30      # 30 % Wochenverlust -> keine neuen Positionen
    max_total_drawdown: float = 0.50   # 50 % Drawdown vom Höchststand -> Notfallabschaltung
    max_portfolio_exposure_x: float = 40.0  # Summe aller Positionsgrößen <= 40x Equity
    max_portfolio_risk: float = 0.15   # Summe der Stop-Loss-Risiken aller Positionen <= 15 % Equity
    max_risk_per_symbol: float = 0.05  # max. Risiko pro Handelspaar
    max_open_positions: int = 50
    min_liq_safety_mult: float = 1.2   # Liquidationsabstand >= 1,2 x Stop-Abstand (Stop liegt immer VOR der Liquidation)


HARD = HardLimits()   # ABSOLUTE Obergrenze (nie überschreitbar). Das Betriebsprofil (limits_for) ist immer <= HARD.
# Früheres konservatives Profil (Referenz): 20x, 1 %/Trade, 3 %/Tag, 6 %/Woche, 10 % Drawdown, 3x Exposure, 5 Positionen
SAFE_LIMITS = HardLimits(max_leverage=20, max_risk_per_trade=0.01, max_daily_loss=0.03, max_weekly_loss=0.06,
                         max_total_drawdown=0.10, max_portfolio_exposure_x=3.0, max_portfolio_risk=0.03,
                         max_risk_per_symbol=0.01, max_open_positions=5, min_liq_safety_mult=1.5)

AGGRESSIVE_PAPER = HARD   # früheres V3-Standardprofil; in V4 nur noch per ausdrücklichem Startparameter (--risk-profile aggressive_paper)


def limits_for(cfg) -> HardLimits:
    """Wirksames Risikoprofil. V4-Standard: SAFE_LIMITS. Jedes Feld ist zusätzlich elementweise durch HARD begrenzt
    (Limits können nur restriktiver werden, nie lockerer als HARD)."""
    base = HARD if getattr(cfg, "risk_profile", "safe") == "aggressive_paper" else SAFE_LIMITS
    kw = {}
    for f_ in fields(HardLimits):
        a, b = getattr(base, f_.name), getattr(HARD, f_.name)
        kw[f_.name] = max(a, b) if f_.name == "min_liq_safety_mult" else min(a, b)   # Liquidationsabstand: größer = restriktiver
    return HardLimits(**kw)


# Standard-Universum: 50 liquide USDT-Paare (Binance). Nicht verfügbare Paare werden beim Start automatisch entfernt.
DEFAULT_SYMBOLS = ("BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "BNBUSDT", "ADAUSDT", "DOGEUSDT", "AVAXUSDT", "LINKUSDT",
                   "DOTUSDT", "LTCUSDT", "TRXUSDT", "ATOMUSDT", "NEARUSDT", "UNIUSDT", "AAVEUSDT", "SUIUSDT", "APTUSDT",
                   "ARBUSDT", "OPUSDT", "INJUSDT", "FILUSDT", "ETCUSDT", "BCHUSDT", "XLMUSDT", "HBARUSDT", "ICPUSDT",
                   "IMXUSDT", "RUNEUSDT", "MKRUSDT", "FETUSDT", "TIAUSDT", "SEIUSDT", "STXUSDT", "ALGOUSDT", "VETUSDT",
                   "GRTUSDT", "SANDUSDT", "MANAUSDT", "AXSUSDT", "EGLDUSDT", "CRVUSDT", "LDOUSDT", "SHIBUSDT", "WLDUSDT",
                   "TONUSDT", "PEPEUSDT", "ENAUSDT", "RENDERUSDT", "GALAUSDT")


@dataclass
class Config:
    # ---- Märkte & Takt
    symbols: tuple = DEFAULT_SYMBOLS
    interval_sec: int = 900            # 15-Minuten-Kerzen
    start_equity: float = 1000.0
    warmup_bars: int = 320             # Kerzen, bevor gehandelt wird (Indikator-Einschwingen)
    # ---- Ausführungsmodell
    fee_taker: float = 0.0005
    fee_maker: float = 0.0002
    half_spread: float = 0.0001        # halber Spread pro Ausführung
    slip_base: float = 0.0002
    slip_vol_mult: float = 0.05        # zusätzlich: 5 % der ATR% (als Bruchteil)
    stop_slip_mult: float = 2.5        # Stops werden schlechter ausgeführt als normale Orders
    liq_fee_rate: float = 0.005        # Liquidationsgebühr (Reserve bei der Liquidationsberechnung)
    funding_const_8h: float = 0.0001   # nur wenn keine echten Funding-Daten vorliegen
    funding_conservative: bool = True  # bei konstantem Funding zahlen Long UND Short (kein Vorteil für Shorts)
    expected_hold_bars: int = 24
    # ---- Risiko / Sizing (alles wird auf HARD begrenzt)
    risk_frac: float = 0.03            # Ziel-Risiko je Trade (3 %), hart begrenzt auf HARD.max_risk_per_trade
    target_atr_pct: float = 0.004
    max_margin_share: float = 0.5      # max. Anteil der Equity als Margin pro Position
    min_notional: float = 10.0
    cooldown_bars: int = 4
    death_equity: float = 0.0          # Tod: Equity <= max(death_equity, min_notional/max_leverage = 0,08 USDT) -> KI stirbt dauerhaft
    liq_safety_mult: float = 1.2
    gap_atr_mult: float = 1.0          # Kurslücken-Puffer in ATR
    max_cost_ratio: float = 0.5        # Kosten dürfen höchstens 50 % des erwarteten Bruttogewinns sein
    min_net_edge: float = 0.0005       # erwarteter Nettogewinn je Notional mindestens 0,05 %
    lev_policy: str = "tier_pref"      # tier_pref (Hebel passend zur Signalstufe) | min_feasible (kleinster nötiger Hebel)
    lev_mode: str = "adaptive"         # adaptive | fixed (fixed nur für die Hebel-Studie)
    fixed_lev: int = 1
    lev_rel_floor: float = 0.5         # Mindest-Zuverlässigkeit für die Hebelstufe (0 = streng statistisch; ohne Schatten-Konten wäre sie sonst 0 -> max. 5x)
    experimental_high_leverage: bool = False  # V4: Hochhebel (75-125x) standardmäßig AUS; nur mit aggressive_paper-Profil sinnvoll
    # ---- Aggregation / Lernen
    shadow_min_conf: float = 0.5
    neutral_weight: float = 0.35
    conflict_thr: float = 0.4
    corr_gamma: float = 1.0
    learn_every: int = 96              # Gewichte alle 96 Kerzen (24 h) aktualisieren
    n_min: int = 20                    # Mindeststichprobe, bevor ein Agent vom Neutralwert abweicht
    shrink_k: float = 20.0
    z_conf: float = 1.28
    half_life_bars: int = 1344         # ~14 Tage
    w_min: float = 0.1
    w_max: float = 2.0
    weight_smooth: float = 0.3
    disable_hours: int = 48
    deact_n: int = 30
    # ---- Optimierung / Validierung
    opt_trials: int = 30
    opt_segments: int = 3
    opt_light: bool = False            # V4: Standard = volle Produktionslogik (mit Schatten-Konten) auch in der Optimierung. True = nur Screening.
    min_trades_segment: int = 5
    wf_train_bars: int = 2400
    wf_test_bars: int = 800
    wf_step_bars: int = 800
    # ---- Champion/Challenger
    promo_min_oos_pf: float = 1.2
    promo_max_oos_mdd: float = 0.15
    promo_min_oos_trades: int = 30
    promo_min_pos_folds: float = 0.6
    promo_min_fwd_trades: int = 30
    promo_min_fwd_pf: float = 1.1
    promo_max_fwd_mdd: float = 0.12
    promo_min_regimes: int = 2
    promo_margin: float = 1.10
    rollback_min_trades: int = 20
    rollback_min_pf: float = 0.9
    rollback_max_mdd: float = 0.12
    # ---- V4: Profil, Nutzersteuerung, Taktung
    risk_profile: str = "safe"         # safe | aggressive_paper. NICHT über Konfigdatei/API änderbar (nur Startparameter).
    activity: int = 3                  # Handelsaktivität 1 (selten) .. 5 (viel): lockert NUR Signalfilter, nie Risiko-/Kostenprüfungen
    ui_push_ms: int = 400              # Dashboard-Push-Intervall (WebSocket)
    price_poll_sec: float = 2.0        # Live-Kurse für die Dashboard-Bewertung offener Positionen
    # ---- V4: Trade Quality Gate (nur im Trainingsfenster optimierbar, versioniert über gate_version)
    gate_enabled: bool = True
    gate_version: int = 1
    gate_z: float = 1.0                # Unsicherheitsabschlag in Standardfehlern
    gate_min_margin: float = 0.0002    # konservative Netto-Edge muss mindestens so weit über 0 liegen (Bruchteil des Preises)
    gate_impact_coef: float = 0.0004   # Market-Impact-Schätzung (Bruchteil) bei Liquidität 0
    # ---- V4: Portfolio Guardian
    guard_enabled: bool = True
    guard_corr_thr: float = 0.7        # ab dieser Korrelation zählen Positionen als gemeinsames Risiko
    guard_max_cluster: float = 2.0     # max. korrelationsgewichtete Anzahl gleichgerichteter Positionen
    guard_beta_limit: float = 3.0      # max. Netto-Beta-Exposure (Summe Side*Beta) in Positionseinheiten
    # ---- V4: Validierung / Promotion
    opt_screening: bool = False        # True = schneller Screening-Modus (ohne Schattenkonten); darf NIE befördern
    v4_gates: bool = True              # Promotion nur bei "conclusive" (genug OOS-Trades) und ohne Screening
    v4_min_oos_trades: int = 300       # darunter: Status "inconclusive"
    v4_purge_embargo: int = 4          # zusätzliche Embargo-Kerzen nach dem Label-Horizont
    # ---- System
    db_path: str = "arena_v3.db"
    port: int = 8000
    host: str = "127.0.0.1"
    seed: int = 42

    @staticmethod
    def load(path: str | None) -> "Config":
        cfg = Config()
        if path:
            with open(path) as f:
                raw = json.load(f)
            names = {f_.name for f_ in fields(Config)}
            for k, v in raw.items():
                if k in names and not k.startswith("_") and k != "risk_profile":   # Profil nur per Startparameter (Locker-Schutz)
                    setattr(cfg, k, tuple(v) if k == "symbols" else v)
        return cfg

    def to_dict(self) -> dict:
        d = asdict(self)
        d["symbols"] = list(self.symbols)
        return d


# --------------------------- Parameterraum für die Optimierung ---------------------------
# name: (min, max, typ). Die Grenzen sind selbst durch HARD begrenzt (z. B. risk_frac <= HARD.max_risk_per_trade, Hebel <= HARD.max_leverage).
PARAM_SPACE = {
    "mom.ema_fast": (5, 30, "i"), "mom.ema_slow": (30, 120, "i"), "mom.roc_n": (4, 48, "i"), "mom.min_gap": (0.1, 2.0, "f"),
    "mr.rsi_low": (15.0, 40.0, "f"), "mr.rsi_high": (60.0, 85.0, "f"), "mr.bb_n": (10, 40, "i"), "mr.bb_k": (1.5, 3.0, "f"),
    "bo.lookback": (20, 120, "i"), "bo.vol_mult": (1.0, 2.5, "f"),
    "tf.fast": (40, 120, "i"), "tf.slow": (120, 320, "i"), "tf.min_gap": (0.2, 2.5, "f"),
    "sc.roc_n": (2, 8, "i"), "sc.vol_mult": (1.0, 3.0, "f"),
    "co.roc_n": (8, 48, "i"), "co.k": (1.5, 6.0, "f"),
    "ca.rsi_min": (30.0, 48.0, "f"), "ca.rsi_max": (55.0, 72.0, "f"), "ca.max_vol_pct": (0.4, 0.9, "f"),
    "team.consensus": (0.15, 0.7, "f"), "team.agreement": (0.55, 0.9, "f"), "team.min_conf": (0.25, 0.7, "f"),
    "team.stop_atr": (1.0, 4.0, "f"), "team.tp_atr": (1.5, 8.0, "f"), "team.trail_atr": (0.0, 4.0, "f"),
    "team.risk_frac": (0.001, HARD.max_risk_per_trade, "f"), "team.vol_filter": (0.5, 1.0, "f"),
    "team.skip_block": (0, 6, "i"),            # 4-Stunden-Block (UTC) ohne neue Einstiege; 6 = kein Zeitfilter
    "lev.cap": (2, HARD.max_leverage, "i"),    # vom Optimierer wählbare Hebel-Obergrenze (<= HARD.max_leverage)
}
DEFAULT_PARAMS = {
    "mom.ema_fast": 8, "mom.ema_slow": 48, "mom.roc_n": 16, "mom.min_gap": 0.5,
    "mr.rsi_low": 30.0, "mr.rsi_high": 70.0, "mr.bb_n": 20, "mr.bb_k": 2.0,
    "bo.lookback": 48, "bo.vol_mult": 1.3,
    "tf.fast": 80, "tf.slow": 200, "tf.min_gap": 0.8,
    "sc.roc_n": 3, "sc.vol_mult": 1.5,
    "co.roc_n": 16, "co.k": 3.0,
    "ca.rsi_min": 40.0, "ca.rsi_max": 65.0, "ca.max_vol_pct": 0.7,
    "team.consensus": 0.35, "team.agreement": 0.65, "team.min_conf": 0.4,
    "team.stop_atr": 2.0, "team.tp_atr": 3.0, "team.trail_atr": 0.0,
    "team.risk_frac": 0.03, "team.vol_filter": 0.9, "team.skip_block": 6,
    "lev.cap": 125,
}


def clamp_params(p: dict | None) -> dict:
    """Füllt fehlende Parameter auf, begrenzt alle Werte auf den erlaubten Bereich und korrigiert Typen."""
    out = dict(DEFAULT_PARAMS)
    for k, v in (p or {}).items():
        if k in PARAM_SPACE:
            lo, hi, kind = PARAM_SPACE[k]
            try:
                v = float(v)
            except (TypeError, ValueError):
                continue
            v = max(lo, min(hi, v))
            out[k] = int(round(v)) if kind == "i" else v
    if out["mom.ema_fast"] >= out["mom.ema_slow"]:
        out["mom.ema_fast"] = max(5, out["mom.ema_slow"] - 5)
    if out["tf.fast"] >= out["tf.slow"]:
        out["tf.fast"] = max(40, out["tf.slow"] - 20)
    if out["team.tp_atr"] < out["team.stop_atr"]:
        out["team.tp_atr"] = out["team.stop_atr"]
    return out
