"""
ArenaApp: Live-Paper-/Demo-Betrieb. Holt Kerzen, lässt Champion (und ggf. Challenger) jede neue abgeschlossene Kerze verarbeiten,
speichert alles in SQLite (Neustart-fest) und startet Optimierung/Beförderung/Rollback als Hintergrundjobs.
ES WERDEN KEINE ECHTEN ORDERS GESENDET.
"""
from __future__ import annotations

import dataclasses
import json
import threading
import time
from bisect import bisect_right
from concurrent.futures import ThreadPoolExecutor

from .agents import MarketCtx
from .analytics import compute_metrics, by_regime
from .backtest import walk_forward, leverage_study
from .champion import ChampionChallenger
from .config import Config, HARD, clamp_params
from .data import BinanceClient, Series, Candle, validate_rows, generate_synthetic, INTERVAL_MS
from .db import DB
from .extras import ExtraFetcher, synthetic_extras
from .optimizer import optimize
from .system import TradingSystem

WINDOW = 1000


def align(data: dict) -> dict:
    """
    Bringt alle Symbole auf dieselbe Zeitachse (Pflicht für das Mehr-Symbol-System): die des ersten Symbols (BTCUSDT).
    Fehlt bei einem anderen Paar eine Kerze (Binance lässt Kerzen ohne Handel weg), wird sie als flache Kerze mit Volumen 0
    ergänzt, statt die Daten ALLER Paare zu kürzen. Die Achse beginnt erst, wenn alle Paare Daten haben.
    """
    if not data:
        return {}
    syms = list(data)
    ref = data[syms[0]]
    if not ref.ts or any(not s.ts for s in data.values()):
        return {k: Series(k, funding=v.funding) for k, v in data.items()}
    t0 = max(s.ts[0] for s in data.values())
    timeline = [t for t in ref.ts if t >= t0]
    out = {}
    for sym, s in data.items():
        if s.ts == ref.ts and t0 == ref.ts[0]:
            out[sym] = s
            continue
        pos = {t: i for i, t in enumerate(s.ts)}
        n = Series(sym, funding=s.funding)
        last = None
        for t in timeline:
            i = pos.get(t)
            if i is not None:
                n.append(s.candle(i))
                last = s.c[i]
            else:
                if last is None:
                    j = bisect_right(s.ts, t) - 1
                    last = s.c[j]
                n.append(Candle(t, last, last, last, last, 0.0))
        out[sym] = n
    return out


class ArenaApp:
    def __init__(self, cfg: Config, demo=False, use_llm=False, cheap=True, llm_fn=None, db_path=None):
        self.cfg, self.demo = cfg, demo
        self.db = DB(db_path or (cfg.db_path if not demo else "arena_v3_demo.db"))
        self.cc = ChampionChallenger(cfg, self.db)
        saved = self.db.kv_get("cc")
        if saved:
            self.cc.load_dict(saved)
        self.lock = threading.RLock()
        self.use_llm, self.cheap, self.llm_fn = use_llm, cheap, llm_fn
        self.systems: dict = {}
        self.client = None if demo else BinanceClient()
        self.demo_data = generate_synthetic(list(cfg.symbols), 12000, seed=cfg.seed) if demo else None
        self.demo_pos = WINDOW
        self.extra_fetcher = ExtraFetcher(lambda: self.client)         # Orderbuch/Derivate (live); im Demo synthetisch
        self.window: dict = {}
        self.market_regime = {}
        self.log: list = []
        self.cycle = 0
        self.trading_enabled = True
        self.bench0 = self.db.kv_get("bench0")
        self.last_opt = self.db.kv_get("last_opt", 0)
        self.opt_running = False
        self.fng = None
        self._learn_saved = {}
        self._llm_err = {}
        self._stale_logged, self._last_problem, self.data_status = [], "", {}
        self.raw_lengths, self.raw_starts = {}, {}
        self._make_system("champion")
        if self.cc.challenger:
            self._make_system("challenger")

    # ------------------------------------------------------------------
    def _log(self, msg):
        rec = {"t": time.strftime("%H:%M:%S"), "msg": msg}
        self.log = (self.log + [rec])[-80:]
        print(f"[{rec['t']}] {msg}", flush=True)

    def _llm_agents(self):
        if not self.use_llm:
            return []
        from .llm_agents import LLMSignalAgent
        fast = "claude-haiku-5-5"
        strong = fast if self.cheap else "claude-sonnet-5-5"
        defs = [("KI Trend-Analyst", strong, "Trend- und Momentum-Analyse über mehrere Zeitfenster"),
                ("KI Contrarian", fast, "Sucht Übertreibungen und Gegenbewegungen"),
                ("KI Risiko-Wächter", fast, "Konservativ: nur klare Setups mit gutem Chance-Risiko-Verhältnis")]
        return [LLMSignalAgent(n, m, st, self.llm_fn) for n, m, st in defs]

    def _make_system(self, role):
        entry = self.cc.champion if role == "champion" else self.cc.challenger
        name = f"v{entry['version']}"
        sysm = TradingSystem(name, self.cfg, entry["params"], shadow=True,
                             extra_agents=self._llm_agents() if role == "champion" else [])
        saved = self.db.kv_get(f"sys:{name}")
        if saved:
            try:
                sysm.load_dict(saved)
            except Exception as e:
                self._log(f"Zustand {name} konnte nicht geladen werden ({e}); starte neu")
        self.systems[role] = sysm
        return sysm

    # ------------------------------------------------------------------
    def fetch_window(self):
        if self.demo:
            return align({s: self.demo_data[s].slice(self.demo_pos - WINDOW, self.demo_pos) for s in self.cfg.symbols})
        syms = list(self.cfg.symbols)

        def one(sym):
            err = None
            for _ in range(2):
                try:
                    return sym, validate_rows(self.client.klines(sym, "15m", WINDOW), drop_last_open=True), None
                except Exception as e:
                    err = e
                    time.sleep(1)
            return sym, None, err

        with ThreadPoolExecutor(max_workers=8) as ex:
            results = list(ex.map(one, syms))
        data, stale = {}, []
        for sym, rows, err in results:
            if rows is not None:
                data[sym] = Series.from_rows(sym, rows)
                self.db.save_candles(sym, rows[-50:])
            elif sym in self.window and sym != syms[0]:
                data[sym] = self.window[sym]                      # einzelner Abruf gescheitert: alte Daten, Lücke wird aufgefüllt
                stale.append(sym)
            else:
                raise RuntimeError(f"{sym}: Kerzen nicht abrufbar ({err})")
        if stale and stale != self._stale_logged:
            self._log("Abruf gescheitert, verwende vorherige Daten für: " + ", ".join(stale))
        self._stale_logged = stale
        for sym in syms:                                           # Funding-Daten gelegentlich auffrischen (Fehler sind unkritisch)
            if self.cycle % 32 == 0:
                f = self.client.funding_history(sym)
                if f:
                    data[sym].funding = f
                    continue
            data[sym].funding = self.window.get(sym, Series(sym)).funding
        self.raw_lengths = {s: len(v) for s, v in data.items()}
        self.raw_starts = {s: v.ts[0] for s, v in data.items() if v.ts}
        return align(data)

    def fetch_extras(self, data, ref):
        """Orderbuch-/Derivate-Daten für die Agenten 11-13. Fehler dürfen den Durchlauf nie stoppen: dann bleiben diese Agenten neutral."""
        try:
            if self.demo:
                ex = synthetic_extras(data)
                self.data_status["extras"] = {"orderbook": len(ex), "derivate": len(ex), "paare": len(ex), "synthetisch": True}
            else:
                ex = self.extra_fetcher.refresh(list(data), ref.ts[-1] // INTERVAL_MS)
                self.data_status["extras"] = dict(self.extra_fetcher.stats)
            return ex
        except Exception as e:
            self._log(f"Zusatzdaten (Orderbuch/Derivate) nicht verfügbar: {e}")
            return {}

    def data_problem(self, ref_len):
        """Verständliche Begründung, warum zu wenige Kerzen vorliegen."""
        need = self.cfg.warmup_bars + 5
        if getattr(self, "raw_starts", None):
            worst = max(self.raw_starts, key=lambda k: self.raw_starts[k])
            have = self.raw_lengths.get(worst, 0)
            if have < need:
                return f"zu wenige Kerzen: {worst} hat nur {have} (benötigt {need}); Paar aus der Liste entfernen (--symbols)"
        return f"zu wenige Kerzen: {ref_len} gemeinsame Kerzen, benötigt {need}"

    def tick(self):
        """Ein Durchlauf: neue abgeschlossene Kerzen holen und verarbeiten. Fehler brechen die Schleife nicht ab."""
        with self.lock:
            try:
                if self.demo:
                    self.demo_pos += 1
                data = self.fetch_window()
                self.window = data
                ref = data[self.cfg.symbols[0]]
                self.data_status = {"candles": len(ref), "need": self.cfg.warmup_bars + 5}
                if len(ref) < self.cfg.warmup_bars + 5:
                    msg = self.data_problem(len(ref))
                    self.data_status["problem"] = msg
                    if msg != self._last_problem:
                        self._log(msg)
                    self._last_problem = msg
                    return
                self._last_problem = ""
                self.data_status.pop("problem", None)
                ctx = MarketCtx(data, self.fetch_extras(data, ref))
                self.market_regime = {s: ctx.regime[s][-1] for s in data}
                if self.bench0 is None:
                    self.bench0 = data["BTCUSDT"].c[-1]
                    self.db.kv_set("bench0", self.bench0)
                for role, sysm in list(self.systems.items()):
                    last = sysm.last_ts
                    idxs = [i for i, t in enumerate(ref.ts) if last is None or t > last]
                    if last is None:                               # Erststart: erst ab der nächsten Kerze handeln
                        sysm.last_ts = ref.ts[-1]
                        idxs = []
                    for i in idxs[-50:]:
                        sysm.step(ctx, i)
                self.cycle += 1
                for a in self.systems["champion"].agents:               # KI-Fehler nicht verschweigen
                    err = getattr(a, "last_error", "")
                    if err and err != self._llm_err.get(a.name):
                        self._llm_err[a.name] = err
                        self._log(f"KI-Agent {a.name}: Fehler - {err}")
                self._persist(ref.ts[-1], data["BTCUSDT"].c[-1])
            except Exception as e:
                self._log(f"Fehler im Durchlauf: {e}")

    def _persist(self, ts, btc):
        bench = self.cfg.start_equity * btc / self.bench0
        for role, sysm in self.systems.items():
            trades, events = sysm.pop_new()
            for t in trades:
                self.db.save_trade(t)
            for e in events:
                self.db.add_event(e["ts"], sysm.name, e["account"], e["kind"], e["detail"])
                self._log(f"{sysm.name}: {e['kind']} {e['account']} {e['detail']}")
            if sysm.curve:
                self.db.save_equity(sysm.name, ts, sysm.curve[-1][1], bench)
            if sysm.learn_log and self._learn_saved.get(sysm.name) != sysm.learn_log[-1]["bar"]:
                self.db.add_learning(sysm.name, ts, sysm.learn_log[-1])
                self._learn_saved[sysm.name] = sysm.learn_log[-1]["bar"]
            self.db.kv_set(f"sys:{sysm.name}", sysm.to_dict())
        self.db.kv_set("cc", self.cc.to_dict())

    # ------------------------------------------------------------------
    # Hintergrundjobs: Optimierung, Beförderung, Rollback
    # ------------------------------------------------------------------
    def load_history(self, bars):
        """Historie aus Datenbank-Cache + API (live) bzw. synthetische Daten (demo)."""
        if self.demo:
            n = self.demo_pos
            return align({s: self.demo_data[s].slice(max(0, n - bars), n) for s in self.cfg.symbols})
        end = int(time.time() * 1000)
        start = end - bars * INTERVAL_MS
        out = {}
        for sym in self.cfg.symbols:
            have = self.db.load_candles(sym, start, end)
            if len(have) < bars * 0.95:
                rows = self.client.history(sym, start, end)
                self.db.save_candles(sym, rows)
                have = rows
            out[sym] = Series.from_rows(sym, have)
        return align(out)

    def optimize_job(self, force=False, trials=None, wf_cfg=None):
        if self.opt_running:
            return {"started": False, "reason": "läuft bereits"}
        self.opt_running = True
        try:
            cfg = wf_cfg or self.cfg
            bars = cfg.wf_train_bars + 3 * cfg.wf_test_bars + cfg.warmup_bars
            data = self.load_history(bars)
            n = len(data[cfg.symbols[0]])
            self._log(f"Optimierung gestartet ({n} Kerzen je Paar)")
            wf = walk_forward(data, cfg, n_trials=trials if trials is not None else cfg.opt_trials,
                              params=self.cc.champion["params"])
            ctx = MarketCtx(data)
            final = optimize(ctx, cfg, n - cfg.wf_train_bars, n, trials if trials is not None else cfg.opt_trials,
                             cfg.seed + 999)
            res = self.cc.propose(final["params"], wf, int(time.time() * 1000))
            self.db.add_optimization("walkforward", {
                "folds": [{k: v for k, v in f.items() if k != "oos"} | {"oos_net": f["oos"]["net_return"], "oos_trades": f["oos"]["trades"],
                                                                      "oos_pf": f["oos"]["profit_factor"]} for f in wf["folds"]],
                "oos": {k: wf["metrics"][k] for k in ("net_return", "profit_factor", "sharpe", "sortino", "max_drawdown", "trades")},
                "robust": wf["robust"], "checks": wf["checks"], "regimes": wf["regimes"], "final_score": final["score"],
                "baseline_score": final["baseline_score"], "backend": final["backend"], "proposal": res})
            if res.get("accepted"):
                with self.lock:
                    self._make_system("challenger")
            self.last_opt = int(time.time())
            self.db.kv_set("last_opt", self.last_opt)
            self._log(f"Optimierung fertig: robust={wf['robust']}, Challenger akzeptiert={res.get('accepted')}")
            return {"started": True, "robust": wf["robust"], "proposal": res}
        except Exception as e:
            self._log(f"Optimierung fehlgeschlagen: {e}")
            return {"started": False, "reason": str(e)}
        finally:
            self.opt_running = False

    def leverage_job(self, cfg=None):
        cfg = cfg or self.cfg
        data = self.load_history(cfg.wf_train_bars + 3 * cfg.wf_test_bars + cfg.warmup_bars)
        res = leverage_study(data, cfg, self.cc.champion["params"])
        slim = {"selected": res["selected"], "highest_return_level": res["highest_return_level"], "note": res["note"],
                "rows": [{"level": r["level"], "net_return": r["metrics"]["net_return"], "pf": r["metrics"]["profit_factor"],
                          "sharpe": r["metrics"]["sharpe"], "sortino": r["metrics"]["sortino"], "mdd": r["metrics"]["max_drawdown"],
                          "trades": r["metrics"]["trades"], "liq": r["metrics"]["liquidations"], "fees": r["metrics"]["fees"],
                          "funding": r["metrics"]["funding"], "util": r["metrics"]["avg_margin_share"], "score": r["score"],
                          "rejected_unsafe": r["rejected_unsafe"], "robust": r["robust"], "pos_folds": r["pos_folds"]} for r in res["rows"]]}
        self.db.add_optimization("leverage", slim)
        return slim

    def evaluate_job(self):
        """Beförderung des Challengers bzw. Rollback des Champions prüfen."""
        with self.lock:
            now = int(time.time() * 1000)
            ch = self.systems.get("challenger")
            champ = self.systems["champion"]
            if ch is not None and self.cc.challenger:
                since = self.cc.challenger["since"] or (ch.curve[0][0] if ch.curve else 0)
                m_ch = compute_metrics(ch.curve, ch.team_closed, self.cfg.start_equity, self.cfg.interval_sec)
                m_cp = compute_metrics(champ.curve, champ.team_closed, self.cfg.start_equity, self.cfg.interval_sec,
                                       from_ts=ch.curve[0][0] if ch.curve else None)
                dec = self.cc.evaluate_promotion(m_ch, by_regime(ch.team_closed), m_cp, now)
                if dec.get("promote"):
                    self.systems["champion"] = ch
                    self.systems.pop("challenger", None)
                    self._log(f"Challenger befördert: neuer Champion v{self.cc.champion['version']}")
            elif self.cc.history:
                since = self.cc.champion.get("since", 0)
                tr = [t for t in champ.team_closed if t.open_ts >= since] if since else champ.team_closed
                m = compute_metrics([(t, e) for t, e in champ.curve if t >= since], tr, self.cfg.start_equity, self.cfg.interval_sec)
                dec = self.cc.check_rollback(m, now)
                if dec.get("rollback"):
                    self._make_system("champion")
                    self._log(f"Rollback auf Champion v{self.cc.champion['version']}")

    def background_loop(self, optimize_every_hours=24, eval_every=96):
        def run():
            while True:
                time.sleep(60 if not self.demo else 5)
                try:
                    if self.cycle and self.cycle % eval_every == 0:
                        self.evaluate_job()
                    if (time.time() - self.last_opt) > optimize_every_hours * 3600 and not self.opt_running and self.cycle > 0 \
                            and self.cc.challenger is None:
                        self.optimize_job()
                except Exception as e:
                    self._log(f"Hintergrundjob-Fehler: {e}")
        threading.Thread(target=run, daemon=True).start()

    # ------------------------------------------------------------------
    def stop(self):
        self.db.close()
