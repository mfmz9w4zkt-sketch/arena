"""
TradingSystem: verbindet Agenten, Aggregator, Meta-Learner, Risiko-Engine und Execution Simulator.
Derselbe Code läuft im Live-Paper-Betrieb UND im Backtest (reproduzierbar, ohne Look-ahead):

  Ablauf je abgeschlossener Kerze i:
   1. Aufträge der VORHERIGEN Kerze werden zum Eröffnungskurs von Kerze i ausgeführt (Slippage, Gebühren, Risiko-Freigabe)
   2. Kerze i wird verarbeitet: Funding, Kurslücken, Stop-Loss, Liquidation, Take-Profit, Trailing
   3. Tages-/Wochen-/Gesamt-Limits werden geprüft (Notfallabschaltung)
   4. Agenten-Signale auf Basis der Daten bis einschließlich Kerze i
   5. Schatten-Konten der Agenten und zentrale Team-Entscheidung erzeugen neue Aufträge (Ausführung erst bei Kerze i+1)
   6. Lernzyklus (Gewichte) im festen Takt
"""
from __future__ import annotations

from .agents import MarketCtx, build_agents, NEUTRAL
from .config import Config, HARD, clamp_params
from .learning import MetaLearner, SignalAggregator
from .regime import label as regime_label
from .risk import RiskEngine, OrderRequest
from .sim import Account, ExecutionSimulator, Candle, Position


class TradingSystem:
    def __init__(self, name, cfg: Config, params=None, shadow=True, extra_agents=None):
        self.name, self.cfg = name, cfg
        self.params = clamp_params(params)
        self.ex = ExecutionSimulator(cfg)
        self.risk = RiskEngine(cfg, self.ex)
        self.agents = build_agents(self.params, cfg.seed) + list(extra_agents or [])
        self.am = {a.name: a for a in self.agents}
        self.use_shadow = shadow
        self.learner = MetaLearner(cfg, self.am)
        self.agg = SignalAggregator(cfg, self.params, self.agents)
        self.team = Account(f"{name}:Team", cfg.start_equity, cfg.start_equity)
        self.shadow = {a.name: Account(f"{name}:{a.name}", cfg.start_equity, cfg.start_equity) for a in self.agents} if shadow else {}
        self.pend_team: dict = {}
        self.pend_shadow = {a: {} for a in self.shadow}
        self.team_closed: list = []
        self.shadow_closed: dict = {a: [] for a in self.shadow}
        self.curve: list = []
        self.shadow_equity: dict = {}
        self.shadow_curves: dict = {a.name: [] for a in self.agents} if shadow else {}
        self.last_signals: dict = {}
        self.last_decisions: dict = {}
        self.last_regime: dict = {}
        self.last_lev_info: dict = {}
        self.last_ts = None
        self.last_learn_bar = None
        self.learn_log: list = []
        self.order_ids: set = set()
        self.shadow_resume: dict = {}
        self.dead: dict = {}                # {agent: {ts, equity}} - gestorbene KI-Agenten (dauerhaft)
        self.team_dead: dict | None = None
        self.new_closed: list = []          # seit dem letzten Abholen (für Datenbank)
        self.new_events: list = []
        self.interval_ms = cfg.interval_sec * 1000

    # ------------------------------------------------------------------
    def _account_list(self):
        yield self.team, self.pend_team, True
        for a, acct in self.shadow.items():
            yield acct, self.pend_shadow[a], False

    def _corr_sum(self, m, acct, sym, side, i):
        tot = 0.0
        for s, p in acct.positions.items():
            if p.side == side and s != sym:
                tot += max(0.0, m.corr(sym, s, i - 1))
        return tot

    def _liquidity(self, m, sym, i):
        ca, s = m.cache[sym], m.s(sym)
        vr = s.v[i - 1] / max(ca.vol_sma_prev(48)[i - 1], 1e-9)
        spread_f = max(0.2, min(1.0, 1.0 - 2 * self.cfg.half_spread / 0.002))
        return max(0.2, min(spread_f, 0.4 + 0.6 * min(1.0, vr)))

    def _record_closed(self, acct, is_team, trades, bar):
        for t in trades:
            if is_team:
                self.team_closed.append(t)
            else:
                agent = t.agent
                self.shadow_closed[agent].append(t)
                if len(self.shadow_closed[agent]) > 3000:
                    del self.shadow_closed[agent][:500]
                self.learner.record(agent, t.close_ts // self.interval_ms, (t.regime or "range").split("/")[0], t.r_multiple)
            self.new_closed.append(t)

    # ------------------------------------------------------------------
    def step(self, m: MarketCtx, i: int):
        cfg, ex = self.cfg, self.ex
        syms = m.syms
        ref = m.s(m.ref)
        ts = ref.ts[i]
        prev_ts = ref.ts[i - 1] if i > 0 else ts - self.interval_ms
        bar = ts // self.interval_ms
        cndl = {s: m.s(s).candle(i) for s in syms}
        opens = {s: cndl[s].o for s in syms}
        closes = {s: cndl[s].c for s in syms}
        atr_prev = {s: m.cache[s].atr_pct_arr()[i - 1] if i > 0 else 0.004 for s in syms}

        # 1) Aufträge der Vorkerze zum Eröffnungskurs ausführen
        for acct, pend, is_team in self._account_list():
            if (is_team and self.team_dead) or (not is_team and acct.name.split(':', 1)[1] in self.dead):
                pend.clear()
                continue
            for sym, o in list(pend.items()):
                pend.pop(sym)
                if o["kind"] == "close":
                    if sym in acct.positions:
                        t = ex.close_market(acct, sym, opens[sym], ts, o.get("reason", "Signal-Umkehr"), atr_prev[sym], self.name)
                        self._record_closed(acct, is_team, [t], bar)
                    continue
                oid = f"{acct.name}|{sym}|{o['decision_ts']}|{o['side']}"
                if oid in self.order_ids:                      # Schutz vor doppelten Trades
                    continue
                req = OrderRequest(
                    sym=sym, side=o["side"], ref_price=opens[sym], atr_pct=o["atr_pct"], vol_pct=o["vol_pct"], conf=o["conf"],
                    agreement=o["agreement"], exp_ret=o["exp_ret"], stop_dist=o["stop_dist"], tp_dist=o["tp_dist"],
                    trail_atr=o["trail_atr"], reliability=o["reliability"], ts=ts, regime_trend=o["trend"],
                    unusual=o["unusual"], vol_label=o["vol_label"], liquidity=o["liquidity"],
                    corr_sum=self._corr_sum(m, acct, sym, o["side"], i), fund_rate=o.get("fund_rate"), agent=o["agent"],
                    regime_label=o["regime"])
                ap = self.risk.approve(acct, opens, req, self.params, bar, atr_prev)
                if not ap.ok:
                    continue
                pos = ex.open_position(acct, sym, o["side"], ap.notional, ap.lev, ap.sl_dist, ap.tp_dist, ap.trail_atr_pct,
                                       opens[sym], o["atr_pct"], ts, ap.risk_amount, o["conf"], o["agent"], o["regime"], ap.info, oid)
                if pos is None:
                    continue
                self.order_ids.add(oid)
                if is_team:
                    self.last_lev_info[sym] = ap.info
        if len(self.order_ids) > 6000:
            self.order_ids = set(list(self.order_ids)[-3000:])

        # 2) Kerze verarbeiten
        for acct, pend, is_team in self._account_list():
            if not acct.positions:
                continue
            for sym in list(acct.positions):
                trades = ex.process_candle(acct, sym, cndl[sym], atr_prev[sym], prev_ts, m.s(sym).funding or None, self.name, bar)
                if trades:
                    self._record_closed(acct, is_team, trades, bar)

        # 3) Risiko-Limits
        for acct, pend, is_team in self._account_list():
            eq = acct.equity(closes)
            action = self.risk.update(acct, eq, ts)
            if action in ("close_all", "halt", "close_losers"):
                for sym in list(acct.positions):
                    if action == "close_losers" and acct.positions[sym].unreal(closes[sym]) >= 0:
                        continue
                    t = ex.close_market(acct, sym, closes[sym], ts, f"Risikolimit ({action})", atr_prev[sym], self.name)
                    self._record_closed(acct, is_team, [t], bar)
                pend.clear()
                if action == "close_all" and not is_team and self.risk.state(acct.name).status == "EMERGENCY":
                    self.shadow_resume[acct.name] = bar + cfg.disable_hours * 3600 // cfg.interval_sec
            st = self.risk.state(acct.name)
            if (not is_team and st.status == "EMERGENCY" and bar >= self.shadow_resume.get(acct.name, 1 << 60)):
                self.risk.reset_emergency(acct.name, ts)
        self._check_death(closes, atr_prev, ts, bar)
        self.new_events.extend(self.risk.events)
        self.risk.events = []

        eq_team = self.team.equity(closes)
        self.curve.append((ts, eq_team))
        self.shadow_equity = {a: acct.equity(closes) for a, acct in self.shadow.items()}
        for a, e in self.shadow_equity.items():
            sc = self.shadow_curves[a]
            sc.append((ts, e))
            if len(sc) > 12000:
                del sc[:2000]
        self.last_ts = ts

        # 4) Signale (nur nach Einschwingphase)
        if i < cfg.warmup_bars:
            return
        sigs = {a.name: {} for a in self.agents}
        for a in self.agents:
            for s in syms:
                if a.name in self.dead:
                    sigs[a.name][s] = NEUTRAL
                    continue
                try:
                    sigs[a.name][s] = a.signal(m, s, i) if not a.batch else NEUTRAL
                except Exception:
                    sigs[a.name][s] = NEUTRAL
        for a in self.agents:
            if a.batch and a.name not in self.dead:
                try:
                    for s, sg in a.signals(m, i).items():
                        sigs[a.name][s] = sg
                except Exception:
                    pass
        self.last_signals = sigs
        self.last_regime = {s: m.regime[s][i] for s in syms}
        self.agg.record({a: sum(sg.dir * sg.conf for sg in d.values()) / len(syms) for a, d in sigs.items()})

        p = self.params
        # 5a) Schatten-Konten: jeder Agent handelt für sich (Messung der echten Netto-Performance)
        for aname, acct in self.shadow.items():
            pend = self.pend_shadow[aname]
            if aname in self.dead or self.risk.state(acct.name).status != "OK":
                continue
            rel = self.learner.reliability(aname, bar)
            for s in syms:
                sg = sigs[aname][s]
                pos = acct.positions.get(s)
                if pos and sg.dir == -pos.side and sg.conf >= cfg.shadow_min_conf:
                    pend[s] = {"kind": "close", "reason": "Agent-Umkehr"}
                elif not pos and sg.dir != 0 and sg.conf >= cfg.shadow_min_conf and s not in pend:
                    pend[s] = self._order(m, s, i, ts, sg.dir, sg.conf, 1.0, sg.exp_ret, rel, aname)

        # 5b) Team: zentrale Entscheidung
        team_ok = self.risk.state(self.team.name).status == "OK" and not self.team_dead
        cands = []
        for s in syms:
            r = m.regime[s][i]
            dec = self.agg.decide(s, {a: sigs[a][s] for a in sigs}, self.learner, r, bar, ts,
                                  None if team_ok else "Risiko-Status")
            self.last_decisions[s] = dec
            pos = self.team.positions.get(s)
            if pos:
                if (dec.dir == -pos.side and abs(dec.score) >= 0.7 * p["team.consensus"] and dec.agreement >= 0.6):
                    self.pend_team[s] = {"kind": "close", "reason": "Konsens gegen Position"}
            elif not dec.blocked and dec.dir != 0 and s not in self.pend_team and not self.team_dead:
                cands.append((abs(dec.score) * dec.conf, s, dec))
        cands.sort(reverse=True)
        free = self.risk.limits(p).max_open - len(self.team.positions)
        rel_map = {a: self.learner.reliability(a, bar) for a in self.agents_in_team()}
        for _, s, dec in cands[:max(0, free)]:
            rel = (sum(rel_map[x["agent"]] * x["w"] for x in dec.parts if x["dir"] == dec.dir) /
                   max(1e-9, sum(x["w"] for x in dec.parts if x["dir"] == dec.dir)))
            self.pend_team[s] = self._order(m, s, i, ts, dec.dir, dec.conf, dec.agreement, dec.exp_ret, rel, "team", dec)

        # 6) Lernzyklus
        if self.use_shadow and (self.last_learn_bar is None or bar - self.last_learn_bar >= cfg.learn_every):
            if self.last_learn_bar is not None:
                self.learn_log.append(self.learner.update(bar, ts))
                self.learn_log = self.learn_log[-100:]
                self.agg.refresh_corr()
            self.last_learn_bar = bar

    def death_threshold(self):
        # Praktisch "Geld bei 0": unter min_notional / max. Hebel (0,50 USDT) kann keine einzige Position mehr eröffnet werden
        return max(self.cfg.death_equity, self.cfg.min_notional / HARD.max_leverage)

    def _check_death(self, closes, atr_prev, ts, bar):
        thr = self.death_threshold()
        for aname, acct in self.shadow.items():
            if aname in self.dead or acct.equity(closes) > thr:
                continue
            for sym in list(acct.positions):
                t = self.ex.close_market(acct, sym, closes[sym], ts, "Tod (Geld aufgebraucht)", atr_prev[sym], self.name)
                self._record_closed(acct, False, [t], bar)
            self.pend_shadow[aname].clear()
            eq = acct.equity(closes)
            self.dead[aname] = {"ts": ts, "equity": eq}
            self.learner.disabled_until[aname] = 1 << 60          # dauerhaft deaktiviert, keine Wiederbelebung
            self.risk.events.append({"ts": ts, "account": acct.name, "kind": "KI_GESTORBEN",
                                     "detail": f"{aname}: Geld aufgebraucht (Equity {eq:.2f} USDT)"})
        if not self.team_dead and self.team.equity(closes) <= thr:
            for sym in list(self.team.positions):
                t = self.ex.close_market(self.team, sym, closes[sym], ts, "Tod (Geld aufgebraucht)", atr_prev[sym], self.name)
                self._record_closed(self.team, True, [t], bar)
            self.pend_team.clear()
            self.team_dead = {"ts": ts, "equity": self.team.equity(closes)}
            self.risk.events.append({"ts": ts, "account": self.team.name, "kind": "TEAM_GESTORBEN",
                                     "detail": f"Team-Konto aufgebraucht (Equity {self.team_dead['equity']:.2f} USDT)"})

    def agents_in_team(self):
        return [a.name for a in self.agents if a.in_team]

    def _order(self, m, sym, i, ts, side, conf, agreement, exp_ret, rel, agent, dec=None):
        p = self.params
        ap = max(m.cache[sym].atr_pct_arr()[i], 1e-6)
        r = m.regime[sym][i]
        fund = None
        fm = m.s(sym).funding
        if fm:
            ks = [k for k in fm if k <= ts]
            fund = fm[max(ks)] if ks else None
        return {"kind": "open", "side": side, "conf": conf, "agreement": agreement, "exp_ret": exp_ret,
                "stop_dist": p["team.stop_atr"] * ap, "tp_dist": p["team.tp_atr"] * ap, "trail_atr": p["team.trail_atr"],
                "reliability": rel, "trend": r.trend, "unusual": r.unusual, "vol_label": r.vol, "vol_pct": r.vol_pct,
                "atr_pct": ap, "liquidity": self._liquidity(m, sym, i), "agent": agent, "regime": regime_label(r),
                "decision_ts": ts, "fund_rate": fund}

    # ------------------------------------------------------------------
    def pop_new(self):
        c, e = self.new_closed, self.new_events
        self.new_closed, self.new_events = [], []
        return c, e

    def to_dict(self):
        return {
            "team": self.team.to_dict(), "shadow": {a: x.to_dict() for a, x in self.shadow.items()},
            "risk": {k: v.to_dict() for k, v in self.risk.states.items()},
            "pend_team": self.pend_team, "pend_shadow": self.pend_shadow,
            "learner": {"weights": self.learner.weights, "disabled": self.learner.disabled_until,
                        "probation": sorted(self.learner.probation), "reset_bar": self.learner.reset_bar,
                        "trades": {a: [list(x) for x in v[-1500:]] for a, v in self.learner.trades.items()},
                        "log": self.learner.log[-50:]},
            "agg": {"hist": {a: h[-300:] for a, h in self.agg.hist.items()}, "div": self.agg.div},
            "evolution": {a.name: a.state_dict() for a in self.agents if hasattr(a, "state_dict")},
            "last_ts": self.last_ts, "last_learn_bar": self.last_learn_bar, "order_ids": sorted(self.order_ids)[-2000:],
            "shadow_resume": self.shadow_resume, "dead": self.dead, "team_dead": self.team_dead, "params": self.params, "learn_log": self.learn_log[-50:],
            "curve": self.curve[-6000:], "shadow_curves": {a: c[-3000:] for a, c in self.shadow_curves.items()},
            "team_closed": [t.to_dict() for t in self.team_closed[-500:]],
        }

    def load_dict(self, d):
        from .risk import RiskState
        self.team = Account.from_dict(d["team"])
        for a, x in d.get("shadow", {}).items():
            if a in self.shadow:
                self.shadow[a] = Account.from_dict(x)
        for k, v in d.get("risk", {}).items():
            self.risk.states[k] = RiskState(**v)
        self.pend_team = d.get("pend_team", {})
        for a, v in d.get("pend_shadow", {}).items():
            if a in self.pend_shadow:
                self.pend_shadow[a] = v
        L = d.get("learner", {})
        for a, w in L.get("weights", {}).items():
            if a in self.learner.weights:
                self.learner.weights[a] = w
        self.learner.disabled_until = L.get("disabled", {})
        self.learner.probation = set(L.get("probation", []))
        self.learner.reset_bar.update(L.get("reset_bar", {}))
        for a, v in L.get("trades", {}).items():
            if a in self.learner.trades:
                self.learner.trades[a] = [tuple(x) for x in v]
        self.learner.log = L.get("log", [])
        for a in self.agents:                                        # in einem alten Speicherstand neu hinzugekommene Agenten
            if getattr(a, "experimental", False) and not self.learner.trades.get(a.name) and a.name not in self.dead:
                self.learner.probation.add(a.name)
        G = d.get("agg", {})
        for a, h in G.get("hist", {}).items():
            if a in self.agg.hist:
                self.agg.hist[a] = h
        self.agg.div.update(G.get("div", {}))
        for a in self.agents:
            if hasattr(a, "load_state_dict") and a.name in d.get("evolution", {}):
                a.load_state_dict(d["evolution"][a.name])
        self.last_ts, self.last_learn_bar = d.get("last_ts"), d.get("last_learn_bar")
        self.order_ids = set(d.get("order_ids", []))
        self.shadow_resume = d.get("shadow_resume", {})
        self.dead = d.get("dead", {})
        self.team_dead = d.get("team_dead")
        self.learn_log = d.get("learn_log", [])
        self.curve = [tuple(x) for x in d.get("curve", [])]
        for a, c in d.get("shadow_curves", {}).items():
            if a in self.shadow_curves:
                self.shadow_curves[a] = [tuple(x) for x in c]
        from .sim import ClosedTrade
        self.team_closed = [ClosedTrade(**t) for t in d.get("team_closed", [])]
