# KI-Trading-Arena V3 (nur Paper Trading / Spielgeld)

Kooperatives, selbstlernendes Multi-Agent-Trading-System mit Risiko-Engine, adaptivem Hebel-Manager (max. 20x),
Backtesting, Walk-forward-Validierung, Optimierer, Champion/Challenger und Dashboard.

**Es gibt keinen Live-Trading-Code. Es werden keine echten Orders gesendet. Es gibt keine Garantie auf Gewinne.**
Alle Beispielergebnisse stammen aus Zufallsdaten und belegen keine Profitabilität.

## Installation
```
python3 -m venv venv && source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt                          # Pflicht: requests. Optional: anthropic (KI-Agenten), optuna
```
Python 3.9 oder neuer (3.10+ empfohlen).

## Start
| Befehl | Zweck |
|---|---|
| `python start_v3.py demo` | Demo mit synthetischen Kursen (kostenlos, zeigt alle Funktionen) |
| `python start_v3.py live` | Paper Trading mit echten Binance-Kursen (öffentliche Daten, kein Key) |
| `python start_v3.py live --llm --cheap` | zusätzlich 3 KI-Agenten (Claude Haiku, kostet API-Guthaben, `ANTHROPIC_API_KEY` nötig) |
| `python start_v3.py backtest --synthetic` oder `--days 60` | Backtest |
| `python start_v3.py walkforward --days 90 --trials 20` | Walk-forward (Training/Test getrennt) |
| `python start_v3.py levstudy --days 90` | Hebel-Studie 1/2/3/5/10/15/20x |
| `python start_v3.py optimize` | einmal optimieren, ggf. Challenger anlegen |
| `python start_v3.py test` | alle Tests + `TESTREPORT.md` |
Dashboard: `http://localhost:8000`. Von außen: `--host 0.0.0.0` und `DASHBOARD_PASSWORD="..."` (Benutzer `arena`).
Neustart-fest: Stand liegt in `arena_v3.db` (SQLite). Neu anfangen: `--reset`.

## Konfiguration
`config.example.json` kopieren, anpassen und mit `--config config.json` laden. Jeder Parameter ist in `arena_v3/config.py` dokumentiert.
**Hard Limits** (im Code fest, per Konfiguration/Optimierer/Agent NICHT änderbar): Hebel 20x, Risiko 1 % je Trade, Tagesverlust 3 %,
Wochenverlust 6 %, Gesamt-Drawdown 10 % (Notfallabschaltung), Exposure 3x, Portfoliorisiko 3 %, max. 5 Positionen.

## Wie der Hebel entschieden wird (wichtig)
Die Positionsgröße kommt aus dem erlaubten Verlust bei Stop-Loss (inkl. Gebühren, Spread, Slippage, Funding) - nicht aus dem Hebel.
Der Hebel ist der **kleinste Hebel, der die Position finanzieren kann** (`lev_policy = min_feasible`), begrenzt durch:
Stufen-Obergrenze (Signalqualität, statistische Zuverlässigkeit, Volatilität, Marktphase, Liquidität, Kosten, Auslastung,
Korrelation, Drawdown, Verlustserie) und Liquidations-Sicherheitsabstand (Stop-Loss + Puffer immer vor der Liquidation).
Daher sind 20x erlaubt, kommen aber nur bei sehr starken, belegten Signalen und engem Stop zum Einsatz. Oft liegt der Hebel bei 1-3x.
Wer höhere Hebel erzwingen will: `lev_policy: "tier_pref"` (nur Paper!) - das senkt den Liquidationsabstand, ohne das Risiko je Trade zu erhöhen.

## KI stirbt bei Geld = 0
Jeder Agent hat ein eigenes Schatten-Konto. Fällt dessen Equity auf 0 (praktisch: unter 0,50 USDT, `death_equity`), stirbt der Agent
dauerhaft: Positionen werden geschlossen, er gibt keine Signale mehr ab, hat kein Stimmrecht im Team, das Ereignis `KI_GESTORBEN`
wird gespeichert und bleibt auch nach Neustart bestehen (Wiederbelebung nur mit `--reset`). Das gilt auch für das Team-Konto
(`TEAM_GESTORBEN`). Hinweis: Wegen der 1 %-Regel und der Limits dauert es bei schlechten Agenten lange, bis das Konto 0 erreicht.
Wer es früher will, setzt `death_equity` höher (z. B. 500 = Tod bei -50 %).

## Änderungen/Bugfixes während der Entwicklung
Sharpe-Berechnung (Startwert fehlte), Aggregator-Qualitätsfaktor (schlechte Agenten dürfen das Team nicht antreiben), Funding-Vorzeichen,
Gap-Ausführung, mehrere Testannahmen. Details: Git-freie Historie siehe TESTREPORT.md.
