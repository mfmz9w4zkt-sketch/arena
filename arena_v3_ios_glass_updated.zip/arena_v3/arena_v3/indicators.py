"""
Technische Indikatoren. ALLE Funktionen sind kausal: der Wert an Index i benutzt nur Daten bis einschließlich i.
(Das wird in tests/test_v3.py per Look-ahead-Test geprüft.)
"""
from __future__ import annotations

import bisect
import math
from collections import deque


def ema(x, n):
    k = 2.0 / (n + 1)
    out, e = [0.0] * len(x), 0.0
    for i, v in enumerate(x):
        e = v if i == 0 else e + k * (v - e)
        out[i] = e
    return out


def sma(x, n):
    out, s = [0.0] * len(x), 0.0
    for i, v in enumerate(x):
        s += v
        if i >= n:
            s -= x[i - n]
        out[i] = s / min(i + 1, n)
    return out


def rolling_std(x, n):
    out, s, s2 = [0.0] * len(x), 0.0, 0.0
    for i, v in enumerate(x):
        s += v
        s2 += v * v
        if i >= n:
            old = x[i - n]
            s -= old
            s2 -= old * old
        m = min(i + 1, n)
        var = max(0.0, s2 / m - (s / m) ** 2)
        out[i] = math.sqrt(var)
    return out


def rsi(c, n=14):
    out = [50.0] * len(c)
    if len(c) <= n:
        return out
    gain = sum(max(0.0, c[i] - c[i - 1]) for i in range(1, n + 1)) / n
    loss = sum(max(0.0, c[i - 1] - c[i]) for i in range(1, n + 1)) / n
    for i in range(n, len(c)):
        if i > n:
            d = c[i] - c[i - 1]
            gain = (gain * (n - 1) + max(0.0, d)) / n
            loss = (loss * (n - 1) + max(0.0, -d)) / n
        out[i] = 100.0 if loss == 0 else 100.0 - 100.0 / (1.0 + gain / loss)
    return out


def atr(h, l, c, n=14):
    out, a = [0.0] * len(c), 0.0
    for i in range(len(c)):
        tr = (h[i] - l[i]) if i == 0 else max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
        a = tr if i == 0 else (a * (n - 1) + tr) / n
        out[i] = a
    return out


def roc(x, n):
    return [0.0 if i < n or x[i - n] == 0 else x[i] / x[i - n] - 1.0 for i in range(len(x))]


def rolling_max_prev(x, n):
    """Maximum der VORHERIGEN n Werte (ohne aktuellen) - für Ausbrüche."""
    out, dq = [0.0] * len(x), deque()
    for i, v in enumerate(x):
        out[i] = x[dq[0]] if dq else v
        while dq and x[dq[-1]] <= v:
            dq.pop()
        dq.append(i)
        while dq and dq[0] <= i - n:
            dq.popleft()
    return out


def rolling_min_prev(x, n):
    out, dq = [0.0] * len(x), deque()
    for i, v in enumerate(x):
        out[i] = x[dq[0]] if dq else v
        while dq and x[dq[-1]] >= v:
            dq.pop()
        dq.append(i)
        while dq and dq[0] <= i - n:
            dq.popleft()
    return out


def rolling_percentile(x, window):
    """Perzentil-Rang von x[i] innerhalb der vorherigen `window` Werte (0..1). Kausal."""
    out, buf, srt = [0.5] * len(x), deque(), []
    for i, v in enumerate(x):
        if srt:
            out[i] = bisect.bisect_left(srt, v) / len(srt)
        buf.append(v)
        bisect.insort(srt, v)
        if len(buf) > window:
            old = buf.popleft()
            del srt[bisect.bisect_left(srt, old)]
    return out


def macd_hist(c, fast=12, slow=26, sig=9):
    ef, es = ema(c, fast), ema(c, slow)
    line = [a - b for a, b in zip(ef, es)]
    s = ema(line, sig)
    return [a - b for a, b in zip(line, s)]


class Cache:
    """Memoisiert Indikator-Arrays für eine Series (nach Name + Parametern)."""

    def __init__(self, series):
        self.s = series
        self._m = {}

    def _get(self, key, fn):
        if key not in self._m:
            self._m[key] = fn()
        return self._m[key]

    def ema(self, n): return self._get(("ema", n), lambda: ema(self.s.c, n))
    def sma(self, n): return self._get(("sma", n), lambda: sma(self.s.c, n))
    def std(self, n): return self._get(("std", n), lambda: rolling_std(self.s.c, n))
    def rsi(self, n=14): return self._get(("rsi", n), lambda: rsi(self.s.c, n))
    def atr(self, n=14): return self._get(("atr", n), lambda: atr(self.s.h, self.s.l, self.s.c, n))
    def roc(self, n): return self._get(("roc", n), lambda: roc(self.s.c, n))
    def hi_prev(self, n): return self._get(("hi", n), lambda: rolling_max_prev(self.s.h, n))
    def lo_prev(self, n): return self._get(("lo", n), lambda: rolling_min_prev(self.s.l, n))
    def vol_sma_prev(self, n):
        def f():
            m = sma(self.s.v, n)
            return [m[0]] + m[:-1]
        return self._get(("vsma", n), f)
    def macd(self): return self._get(("macd",), lambda: macd_hist(self.s.c))

    def atr_pct(self, i, n=14):
        c = self.s.c[i]
        return self.atr(n)[i] / c if c else 0.0

    def atr_pct_arr(self, n=14):
        return self._get(("atrp", n), lambda: [a / c if c else 0.0 for a, c in zip(self.atr(n), self.s.c)])

    def vol_pct(self, window=1000):
        return self._get(("volpct", window), lambda: rolling_percentile(self.atr_pct_arr(), window))
