"""
Performance Analytics: Nettorendite, Profit Factor, Sharpe, Sortino, Max-Drawdown u. a.
Alle Ergebnisse sind NETTO (nach Gebühren, Slippage, Funding), weil sie aus dem simulierten Konto stammen.
Sharpe/Sortino werden aus Tages-Endständen berechnet (ab 10 Tagen), sonst aus Kerzen-Renditen (mit Warnhinweis).
"""
from __future__ import annotations

import math
import statistics


def max_drawdown(values):
    peak, mdd = -1e18, 0.0
    for v in values:
        peak = max(peak, v)
        if peak > 0:
            mdd = max(mdd, (peak - v) / peak)
    return mdd


def _ratios(curve, interval_sec):
    if len(curve) < 3:
        return None, None, "zu wenig Daten"
    days = {}
    for ts, eq in curve:
        days[ts // 86_400_000] = eq
    series = [curve[0][1]] + [days[k] for k in sorted(days)]      # Startwert als Ausgangspunkt (kein Verlust der ersten Tagesbewegung)
    if len(series) >= 10:
        rets = [series[i] / series[i - 1] - 1 for i in range(1, len(series)) if series[i - 1] > 0]
        ppy, note = 365.0, "Tageswerte"
    else:
        vals = [e for _, e in curve]
        rets = [vals[i] / vals[i - 1] - 1 for i in range(1, len(vals)) if vals[i - 1] > 0]
        ppy, note = 365 * 86400 / interval_sec, "Kerzenwerte (kurze Laufzeit, wenig aussagekräftig)"
    if len(rets) < 3:
        return None, None, "zu wenig Daten"
    mu, sd = statistics.mean(rets), statistics.pstdev(rets)
    down = [min(0.0, r) for r in rets]
    dd = math.sqrt(sum(d * d for d in down) / len(down))
    sharpe = mu / sd * math.sqrt(ppy) if sd > 0 else None
    sortino = mu / dd * math.sqrt(ppy) if dd > 0 else None
    return sharpe, sortino, note


def compute_metrics(curve, trades, start_equity, interval_sec=900, from_ts=None):
    """curve: [(ts, equity)], trades: Liste von ClosedTrade oder dict."""
    if from_ts is not None:
        curve = [(t, e) for t, e in curve if t >= from_ts]
    td = [t if isinstance(t, dict) else t.to_dict() for t in trades]
    if from_ts is not None:
        td = [t for t in td if t["open_ts"] >= from_ts]
    base = curve[0][1] if curve else start_equity
    last = curve[-1][1] if curve else start_equity
    wins = [t["net_pnl"] for t in td if t["net_pnl"] > 0]
    losses = [-t["net_pnl"] for t in td if t["net_pnl"] <= 0]
    gp, gl = sum(wins), sum(losses)
    pf = (gp / gl) if gl > 0 else (float("inf") if gp > 0 else 0.0)
    sharpe, sortino, note = _ratios(curve, interval_sec)
    mdd = max_drawdown([e for _, e in curve])
    n = len(td)
    out = {
        "net_return": last / base - 1 if base else 0.0,
        "net_pnl": last - base, "trades": n,
        "win_rate": len(wins) / n if n else None,
        "profit_factor": pf if n else None,
        "avg_r": statistics.mean(t["r_multiple"] for t in td) if n else None,
        "expectancy": (gp - gl) / n if n else None,
        "sharpe": sharpe, "sortino": sortino, "ratio_basis": note,
        "max_drawdown": mdd,
        "fees": sum(t["fees"] for t in td), "slippage": sum(t["slippage"] for t in td),
        "funding": sum(t["funding"] for t in td), "gross_pnl": sum(t["gross_pnl"] for t in td),
        "liquidations": sum(1 for t in td if t["liquidated"]),
        "avg_leverage": statistics.mean(t["lev"] for t in td) if n else None,
        "avg_margin_share": statistics.mean(t["notional"] / t["lev"] for t in td) / start_equity if n else None,
        "avg_hold_bars": statistics.mean(t["hold_bars"] for t in td) if n else None,
        "calmar": (last / base - 1) / mdd if mdd > 0 else None,
    }
    return out


def by_regime(trades):
    """Netto-Ergebnis je Marktphase (Kategorie aus dem Regime-Label beim Einstieg)."""
    from .regime import tags, Regime
    res = {}
    for t in trades:
        td = t if isinstance(t, dict) else t.to_dict()
        parts = (td.get("regime") or "range/normal").split("/")
        trend, vol = parts[0], parts[1] if len(parts) > 1 else "normal"
        cats = {"up": "Bull", "down": "Bear", "range": "Seitwaerts"}.get(trend, "Seitwaerts")
        keys = [cats]
        if vol in ("high", "extreme"):
            keys.append("Hohe Volatilitaet")
        if vol == "low":
            keys.append("Niedrige Volatilitaet")
        for k in keys:
            r = res.setdefault(k, {"trades": 0, "net_pnl": 0.0, "gp": 0.0, "gl": 0.0})
            r["trades"] += 1
            r["net_pnl"] += td["net_pnl"]
            if td["net_pnl"] > 0:
                r["gp"] += td["net_pnl"]
            else:
                r["gl"] -= td["net_pnl"]
    for r in res.values():
        r["profit_factor"] = (r["gp"] / r["gl"]) if r["gl"] > 0 else (float("inf") if r["gp"] > 0 else 0.0)
    return res


def fmt(v, d=2, pct=False):
    if v is None:
        return "-"
    if v == float("inf"):
        return "inf"
    return f"{v * 100:.{d}f}%" if pct else f"{v:.{d}f}"
