"""
KI-Agenten (LLM) für den Live-/Demo-Betrieb. Sie liefern wie alle Agenten nur SIGNALE (Richtung, Confidence, erwarteter Gewinn,
Risiko, Begründung). Eröffnen können sie keine Trades; das macht ausschließlich die zentrale Entscheidungsinstanz über den
Risiko-Manager. LLM-Agenten werden im Backtest NICHT verwendet (nicht reproduzierbar, Look-ahead durch Modellwissen möglich).
Fehler, Timeouts und ungültige Antworten führen zu "neutral" (kein Signal).
"""
from __future__ import annotations

import json

from .agents import Agent, Signal, NEUTRAL
from .regime import label


def parse_json(text):
    text = text.replace("```json", "").replace("```", "")
    return json.loads(text[text.find("{"): text.rfind("}") + 1])


class LLMSignalAgent(Agent):
    family = "llm"
    batch = True

    def __init__(self, name, model, style, llm_fn, in_team=True, params=None):
        super().__init__(params)
        self.name, self.model, self.style, self.llm_fn, self.in_team = name, model, style, llm_fn, in_team
        self.affinity = {"up": 1.0, "down": 1.0, "range": 1.0}
        self._cache = (None, {})
        self.tokens_in = self.tokens_out = self.errors = 0
        self.last_error = ""

    def signal(self, m, sym, i):
        return NEUTRAL

    def _view(self, m, i):
        out = {}
        for s in m.syms:
            ca, c = m.cache[s], m.s(s).c[i]
            r = m.regime[s][i]
            out[s] = {"preis": c, "roc_1h_pct": round(ca.roc(4)[i] * 100, 2), "roc_4h_pct": round(ca.roc(16)[i] * 100, 2),
                      "roc_24h_pct": round(ca.roc(96)[i] * 100, 2), "rsi14": round(ca.rsi(14)[i], 1),
                      "atr_pct": round(ca.atr_pct_arr()[i] * 100, 3), "marktphase": label(r),
                      "vol_perzentil": round(r.vol_pct, 2), "trend_staerke_atr": round(r.strength, 2)}
        return out

    def signals(self, m, i) -> dict:
        ts = m.s(m.ref).ts[i]
        if self._cache[0] == ts:
            return self._cache[1]
        prompt = (f'Du bist der Analyse-Agent "{self.name}". Strategie: {self.style}\n'
                  "Gib für jedes Symbol ein Signal ab. Du eröffnest keine Trades; eine zentrale Instanz entscheidet.\n"
                  f"Daten (15-Minuten-Kerzen): {json.dumps(self._view(m, i))}\n"
                  'Antworte NUR mit JSON: {"signals": {"BTCUSDT": {"dir": 1, "conf": 0.6, "exp_move_pct": 1.2, '
                  '"risk_pct": 0.8, "reason": "kurz auf Deutsch"}}}\n'
                  "dir: 1 long, -1 short, 0 neutral. conf 0..1. Im Zweifel dir=0.")
        out = {}
        try:
            text, tin, tout = self.llm_fn(self.model, prompt)
            self.tokens_in += tin
            self.tokens_out += tout
            for s, d in parse_json(text).get("signals", {}).items():
                if s not in m.syms:
                    continue
                dr = int(d.get("dir", 0))
                dr = 1 if dr > 0 else -1 if dr < 0 else 0
                conf = max(0.0, min(1.0, float(d.get("conf", 0))))
                exp = max(0.0, min(0.05, float(d.get("exp_move_pct", 0)) / 100))
                risk = max(0.0, min(0.08, float(d.get("risk_pct", 1)) / 100))
                out[s] = Signal(dr, conf, exp, risk, str(d.get("reason", ""))[:200]) if dr else NEUTRAL
        except Exception as e:
            self.errors += 1
            self.last_error = f"{type(e).__name__}: {e}"[:300]
        self._cache = (ts, out)
        return out
