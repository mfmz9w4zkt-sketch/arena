"""
Persistente Datenbank (SQLite): Kerzen-Cache, abgeschlossene Trades, Aufträge (Idempotenz), Equity-Verlauf,
Ereignisse (Risiko, Notfall, Promotion, Rollback), Lernzyklen, Optimierungsläufe, Parameter-Versionen und Zustands-Snapshots.
"""
from __future__ import annotations

import json
import sqlite3
import threading
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS candles (symbol TEXT, ts INTEGER, o REAL, h REAL, l REAL, c REAL, v REAL, PRIMARY KEY(symbol, ts));
CREATE TABLE IF NOT EXISTS trades (id TEXT PRIMARY KEY, system TEXT, account TEXT, agent TEXT, symbol TEXT, side INTEGER,
    regime TEXT, open_ts INTEGER, close_ts INTEGER, data TEXT);
CREATE INDEX IF NOT EXISTS idx_trades_sys ON trades(system, account, close_ts);
CREATE TABLE IF NOT EXISTS orders (oid TEXT PRIMARY KEY, ts INTEGER);
CREATE TABLE IF NOT EXISTS equity (system TEXT, ts INTEGER, team REAL, benchmark REAL, PRIMARY KEY(system, ts));
CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, system TEXT, account TEXT, kind TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS learning (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, system TEXT, data TEXT);
CREATE TABLE IF NOT EXISTS optimization (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, kind TEXT, data TEXT);
CREATE TABLE IF NOT EXISTS params (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, role TEXT, version INTEGER, params TEXT, meta TEXT);
CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT);
"""


class DB:
    def __init__(self, path=":memory:"):
        self.path = path
        self.lock = threading.RLock()
        self.con = sqlite3.connect(path, check_same_thread=False, timeout=30)
        with self.lock:
            if path != ":memory:":
                self.con.execute("PRAGMA journal_mode=WAL")
            self.con.executescript(SCHEMA)
            self.con.commit()

    def close(self):
        with self.lock:
            self.con.close()

    def _x(self, sql, args=(), commit=True):
        with self.lock:
            cur = self.con.execute(sql, args)
            if commit:
                self.con.commit()
            return cur

    # ---------------- Zustand ----------------
    def kv_set(self, k, v):
        self._x("INSERT OR REPLACE INTO kv(k, v) VALUES (?, ?)", (k, json.dumps(v)))

    def kv_get(self, k, default=None):
        r = self._x("SELECT v FROM kv WHERE k=?", (k,), False).fetchone()
        return json.loads(r[0]) if r else default

    # ---------------- Kerzen ----------------
    def save_candles(self, symbol, rows):
        with self.lock:
            self.con.executemany("INSERT OR REPLACE INTO candles VALUES (?,?,?,?,?,?,?)",
                                 [(symbol, int(r[0]), r[1], r[2], r[3], r[4], r[5]) for r in rows])
            self.con.commit()

    def load_candles(self, symbol, start=None, end=None):
        q, a = "SELECT ts,o,h,l,c,v FROM candles WHERE symbol=?", [symbol]
        if start is not None:
            q += " AND ts>=?"; a.append(int(start))
        if end is not None:
            q += " AND ts<=?"; a.append(int(end))
        return [list(r) for r in self._x(q + " ORDER BY ts", a, False).fetchall()]

    # ---------------- Trades ----------------
    def save_trade(self, t):
        d = t if isinstance(t, dict) else t.to_dict()
        self._x("INSERT OR IGNORE INTO trades VALUES (?,?,?,?,?,?,?,?,?,?)",
                (d["id"] + f"@{d['close_ts']}", d["system"], d["account"], d["agent"], d["symbol"], d["side"], d["regime"],
                 d["open_ts"], d["close_ts"], json.dumps(d)))

    def load_trades(self, system=None, account=None, limit=None, since_ts=None):
        q, a = "SELECT data FROM trades WHERE 1=1", []
        if system:
            q += " AND system=?"; a.append(system)
        if account:
            q += " AND account=?"; a.append(account)
        if since_ts:
            q += " AND close_ts>=?"; a.append(since_ts)
        q += " ORDER BY close_ts"
        rows = [json.loads(r[0]) for r in self._x(q, a, False).fetchall()]
        return rows[-limit:] if limit else rows

    # ---------------- Aufträge (Schutz vor doppelten Trades) ----------------
    def register_order(self, oid, ts=0) -> bool:
        cur = self._x("INSERT OR IGNORE INTO orders VALUES (?,?)", (oid, ts))
        return cur.rowcount == 1

    # ---------------- Verlauf / Ereignisse ----------------
    def save_equity(self, system, ts, team, benchmark):
        self._x("INSERT OR REPLACE INTO equity VALUES (?,?,?,?)", (system, ts, team, benchmark))

    def load_equity(self, system, limit=5000):
        rows = self._x("SELECT ts,team,benchmark FROM equity WHERE system=? ORDER BY ts DESC LIMIT ?", (system, limit), False).fetchall()
        return [list(r) for r in reversed(rows)]

    def add_event(self, ts, system, account, kind, detail):
        self._x("INSERT INTO events(ts,system,account,kind,detail) VALUES (?,?,?,?,?)", (ts, system, account, kind, str(detail)))

    def events(self, limit=100):
        return [dict(zip(("ts", "system", "account", "kind", "detail"), r)) for r in
                self._x("SELECT ts,system,account,kind,detail FROM events ORDER BY id DESC LIMIT ?", (limit,), False).fetchall()]

    def add_learning(self, system, ts, data):
        self._x("INSERT INTO learning(ts,system,data) VALUES (?,?,?)", (ts, system, json.dumps(data)))

    def learning(self, limit=30):
        return [json.loads(r[0]) for r in self._x("SELECT data FROM learning ORDER BY id DESC LIMIT ?", (limit,), False).fetchall()]

    def add_optimization(self, kind, data):
        self._x("INSERT INTO optimization(ts,kind,data) VALUES (?,?,?)", (int(time.time()), kind, json.dumps(data)))

    def optimizations(self, kind=None, limit=20):
        q, a = "SELECT ts,kind,data FROM optimization", []
        if kind:
            q += " WHERE kind=?"; a.append(kind)
        q += " ORDER BY id DESC LIMIT ?"; a.append(limit)
        return [{"ts": r[0], "kind": r[1], "data": json.loads(r[2])} for r in self._x(q, a, False).fetchall()]

    # ---------------- Parameter-Versionen ----------------
    def save_params(self, role, version, params, meta=None):
        self._x("INSERT INTO params(ts,role,version,params,meta) VALUES (?,?,?,?,?)",
                (int(time.time()), role, version, json.dumps(params), json.dumps(meta or {})))

    def params_history(self, limit=30):
        return [{"ts": r[0], "role": r[1], "version": r[2], "params": json.loads(r[3]), "meta": json.loads(r[4])} for r in
                self._x("SELECT ts,role,version,params,meta FROM params ORDER BY id DESC LIMIT ?", (limit,), False).fetchall()]
