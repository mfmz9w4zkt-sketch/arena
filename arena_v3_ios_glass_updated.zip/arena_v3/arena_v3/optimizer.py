"""
Strategy Optimizer. Nutzt Optuna (TPE), falls installiert, sonst eine eingebaute Zufalls-/Mutationssuche (keine Abhängigkeit).

Die Zielfunktion maximiert NICHT nur die Rendite, sondern kombiniert Nettorendite, Profit Factor, Sharpe, Sortino,
Drawdown-Strafe, Liquidationsstrafe, Mindest-Tradezahl und Stabilität über mehrere Teilfenster des Trainingszeitraums
(Mittelwert minus 0,5 x Standardabweichung der Teilfenster-Scores).
Die Suchgrenzen (PARAM_SPACE) liegen innerhalb der HARD-Limits; außerdem wird jeder Parametersatz durch clamp_params begrenzt.
"""
from __future__ import annotations

import math
import random

from .config import Config, PARAM_SPACE, DEFAULT_PARAMS, clamp_params


def score_metrics(m: dict, cfg: Config, min_trades=None) -> float:
    min_trades = cfg.min_trades_segment if min_trades is None else min_trades
    n = m["trades"]
    if n < min_trades:
        return -1.0 + 0.5 * n / max(1, min_trades)
    pf = m["profit_factor"]
    pf = 5.0 if pf is None or pf == float("inf") else min(pf, 5.0)
    ret = m["net_return"] * 100
    sh = m["sharpe"] or 0.0
    so = m["sortino"] or 0.0
    mdd = m["max_drawdown"]
    s = (0.30 * math.tanh(ret / 5.0) + 0.20 * math.tanh(pf - 1.0) + 0.15 * math.tanh(sh / 2.0)
         + 0.15 * math.tanh(so / 3.0) - 0.25 * max(0.0, mdd - 0.05) / 0.05 - 0.15 * m["liquidations"])
    return s


def objective(ctx, cfg: Config, params, a, b, burn=400):
    """Stabilitätsorientierter Score über cfg.opt_segments Teilfenster von [a, b)."""
    from .backtest import run_backtest
    k = max(1, cfg.opt_segments)
    edges = [a + (b - a) * j // k for j in range(k + 1)]
    scores = []
    for j in range(k):
        r = run_backtest(None, cfg, params, start=edges[j], end=edges[j + 1], burn_in=min(burn, edges[j] - 1),
                         shadow=not getattr(cfg, "opt_light", True), ctx=ctx)
        scores.append(score_metrics(r["metrics"], cfg))
    mean = sum(scores) / len(scores)
    sd = (sum((x - mean) ** 2 for x in scores) / len(scores)) ** 0.5
    return mean - 0.5 * sd, scores


def sample(rng: random.Random, base=None, scale=0.25):
    p = {}
    for k, (lo, hi, kind) in PARAM_SPACE.items():
        if base is not None and rng.random() > 0.35:
            v = base[k] + rng.gauss(0, scale * (hi - lo))          # Mutation um einen guten Punkt
        else:
            v = rng.uniform(lo, hi)
        p[k] = v
    return clamp_params(p)


def optimize(ctx, cfg: Config, a: int, b: int, n_trials: int, seed: int, backend="auto"):
    """Sucht Parameter auf dem Trainingsfenster [a, b). Gibt beste Parameter, Score und alle Versuche zurück."""
    base_score, base_scores = objective(ctx, cfg, DEFAULT_PARAMS, a, b)
    trials = [{"params": dict(DEFAULT_PARAMS), "score": base_score, "segments": base_scores}]
    used = "random"
    if backend in ("auto", "optuna"):
        try:
            import optuna
            optuna.logging.set_verbosity(optuna.logging.WARNING)

            def obj(trial):
                p = {}
                for k, (lo, hi, kind) in PARAM_SPACE.items():
                    p[k] = trial.suggest_int(k, int(lo), int(hi)) if kind == "i" else trial.suggest_float(k, lo, hi)
                p = clamp_params(p)
                sc, segs = objective(ctx, cfg, p, a, b)
                trials.append({"params": p, "score": sc, "segments": segs})
                return sc

            study = optuna.create_study(direction="maximize", sampler=optuna.samplers.TPESampler(seed=seed))
            study.enqueue_trial({k: DEFAULT_PARAMS[k] for k in PARAM_SPACE})
            study.optimize(obj, n_trials=n_trials)
            used = "optuna"
        except ImportError:
            if backend == "optuna":
                raise
    if used == "random":
        rng = random.Random(seed)
        for t in range(n_trials):
            top = sorted(trials, key=lambda x: -x["score"])[:3]
            p = sample(rng) if t < n_trials * 0.5 or rng.random() < 0.3 else sample(rng, rng.choice(top)["params"], 0.15)
            sc, segs = objective(ctx, cfg, p, a, b)
            trials.append({"params": p, "score": sc, "segments": segs})
    best = max(trials, key=lambda x: x["score"])
    return {"params": best["params"], "score": best["score"], "baseline_score": base_score, "backend": used,
            "n_trials": len(trials), "top": sorted(trials, key=lambda x: -x["score"])[:5]}
