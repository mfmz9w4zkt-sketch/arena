"""
Agent Intelligence Layer.

Jeder Agent gibt je Handelspaar ein Signal ab: Richtung (+1 long, -1 short, 0 neutral), Confidence (0..1),
erwartete Bewegung (exp_ret, Bruchteil des Preises), geschätztes Risiko (risk, Stop-Abstand als Bruchteil) und eine Begründung.
Agenten eröffnen NICHT selbst Trades für das Team: eine zentrale Instanz (learning.SignalAggregator) wertet alle Signale aus.
Zusätzlich führt jeder Agent ein Schatten-Konto (system.py), damit seine echte Netto-Performance gemessen werden kann.
"""
from __future__ import annotations

import random
from collections import namedtuple

from .config import clamp_params
from .indicators import Cache
from .regime import compute_regimes

Signal = namedtuple("Signal", "dir conf exp_ret risk reason")
NEUTRAL = Signal(0, 0.0, 0.0, 0.0, "neutral")


class MarketCtx:
    """Alle Daten + Indikator-Caches + Regime-Arrays. Index i = zuletzt abgeschlossene Kerze."""

    def __init__(self, data: dict):
        self.data = data
        self.syms = list(data)
        self.cache = {s: Cache(data[s]) for s in self.syms}
        self.regime = {s: compute_regimes(self.cache[s]) for s in self.syms}
        self.ref = "BTCUSDT" if "BTCUSDT" in data else self.syms[0]
        self._ret = {}

    def s(self, sym):
        return self.data[sym]

    def n(self):
        return len(self.data[self.ref])

    def returns(self, sym):
        if sym not in self._ret:
            c = self.data[sym].c
            self._ret[sym] = [0.0] + [c[i] / c[i - 1] - 1 for i in range(1, len(c))]
        return self._ret[sym]

    def corr(self, a, b, i, w=96):
        if a == b:
            return 1.0
        ra, rb = self.returns(a)[max(1, i - w + 1): i + 1], self.returns(b)[max(1, i - w + 1): i + 1]
        return pearson(ra, rb)

    def rel_rank(self, sym, i, n=96):
        vals = sorted(self.cache[x].roc(n)[i] for x in self.syms)
        r = self.cache[sym].roc(n)[i]
        return vals.index(r) / max(1, len(vals) - 1)


def pearson(x, y):
    n = min(len(x), len(y))
    if n < 5:
        return 0.0
    mx, my = sum(x[:n]) / n, sum(y[:n]) / n
    sxx = sum((a - mx) ** 2 for a in x[:n])
    syy = sum((b - my) ** 2 for b in y[:n])
    if sxx <= 0 or syy <= 0:
        return 0.0
    return sum((a - mx) * (b - my) for a, b in zip(x[:n], y[:n])) / (sxx * syy) ** 0.5


class Agent:
    name = "Agent"
    family = "generic"
    in_team = True
    batch = False
    # Vorwissen, wie gut eine Strategie-Familie zu einer Marktphase passt (nur Startwert, wird durch Lernen überstimmt)
    affinity = {"up": 1.0, "down": 1.0, "range": 1.0}
    style = ""

    def __init__(self, params=None):
        self.p = clamp_params(params)

    def signal(self, m: MarketCtx, sym: str, i: int) -> Signal:
        raise NotImplementedError

    @staticmethod
    def _basic(m, sym, i):
        ca = m.cache[sym]
        return ca, m.s(sym).c[i], max(ca.atr_pct_arr()[i], 1e-6)


class MomentumAgent(Agent):
    name, family = "Momentum", "trend"
    affinity = {"up": 1.2, "down": 1.2, "range": 0.6}
    style = "Trendhandel mit EMA-Abstand, ROC und MACD"

    def signal(self, m, sym, i):
        if i < 130:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        gap = (ca.ema(p["mom.ema_fast"])[i] - ca.ema(p["mom.ema_slow"])[i]) / c / ap
        r = ca.roc(p["mom.roc_n"])[i] / ap
        mh = ca.macd()[i]
        d = 1 if gap > p["mom.min_gap"] and r > 0 and mh > 0 else -1 if gap < -p["mom.min_gap"] and r < 0 and mh < 0 else 0
        if not d:
            return NEUTRAL
        conf = min(1.0, 0.4 + 0.2 * min(abs(gap), 2.0) + 0.08 * min(abs(r), 3.0))
        return Signal(d, conf, ap * (1.0 + 2.0 * conf), 2 * ap, f"EMA-Abstand {gap:.2f} ATR, ROC {r:.2f} ATR")


class MeanReversionAgent(Agent):
    name, family = "Mean Reversion", "meanrev"
    affinity = {"up": 0.7, "down": 0.7, "range": 1.3}
    style = "Gegenbewegung bei RSI-Extremen und Bollinger-Rand"

    def signal(self, m, sym, i):
        if i < 130:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        n = p["mr.bb_n"]
        mid, sd = ca.sma(n)[i], ca.std(n)[i]
        if sd <= 0:
            return NEUTRAL
        z, rs = (c - mid) / sd, ca.rsi(14)[i]
        d = 1 if rs < p["mr.rsi_low"] and z < -p["mr.bb_k"] else -1 if rs > p["mr.rsi_high"] and z > p["mr.bb_k"] else 0
        if not d:
            return NEUTRAL
        conf = min(1.0, 0.4 + 0.15 * (abs(z) - p["mr.bb_k"]) + 0.01 * abs(rs - 50))
        return Signal(d, conf, max(abs(mid - c) / c * 0.6, ap * 0.8), 1.5 * ap, f"z={z:.2f}, RSI {rs:.0f}")


class BreakoutAgent(Agent):
    name, family = "Breakout", "breakout"
    affinity = {"up": 1.1, "down": 1.1, "range": 0.8}
    style = "Ausbruch aus der Donchian-Spanne mit Volumenbestätigung"

    def signal(self, m, sym, i):
        if i < 130:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        s = m.s(sym)
        vr = s.v[i] / max(ca.vol_sma_prev(48)[i], 1e-9)
        hi, lo = ca.hi_prev(p["bo.lookback"])[i], ca.lo_prev(p["bo.lookback"])[i]
        d = 1 if c > hi and vr > p["bo.vol_mult"] else -1 if c < lo and vr > p["bo.vol_mult"] else 0
        if not d:
            return NEUTRAL
        conf = min(1.0, 0.45 + 0.2 * (vr - p["bo.vol_mult"]))
        return Signal(d, conf, ap * (1.5 + conf * 2), 2 * ap, f"Ausbruch, Volumen x{vr:.1f}")


class TrendFollowerAgent(Agent):
    name, family = "Trendfolger", "trend"
    affinity = {"up": 1.3, "down": 1.3, "range": 0.5}
    style = "Langsamer Trend (EMA 80/200 auf 15m ~ 20/50 auf 1h)"

    def signal(self, m, sym, i):
        if i < 210:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        gap = (ca.ema(p["tf.fast"])[i] - ca.ema(p["tf.slow"])[i]) / c / ap
        if abs(gap) < p["tf.min_gap"]:
            return NEUTRAL
        d = 1 if gap > 0 else -1
        conf = min(1.0, 0.4 + 0.2 * abs(gap))
        return Signal(d, conf, ap * 2.5, 2.5 * ap, f"Trend-Abstand {gap:.2f} ATR")


class ScalperAgent(Agent):
    name, family = "Scalper", "scalp"
    affinity = {"up": 1.0, "down": 1.0, "range": 1.0}
    style = "Kurzfristige Bewegung mit Volumenspitze (hohe Kostenbelastung)"

    def signal(self, m, sym, i):
        if i < 130:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        r = ca.roc(p["sc.roc_n"])[i] / ap
        vr = m.s(sym).v[i] / max(ca.vol_sma_prev(48)[i], 1e-9)
        if abs(r) < 1.2 or vr < p["sc.vol_mult"]:
            return NEUTRAL
        d = 1 if r > 0 else -1
        return Signal(d, min(0.7, 0.45 + 0.05 * abs(r)), ap * 0.9, ap, f"ROC {r:.1f} ATR, Vol x{vr:.1f}")


class ContrarianAgent(Agent):
    name, family = "Contrarian", "meanrev"
    affinity = {"up": 0.8, "down": 0.8, "range": 1.2}
    style = "Gegen extreme Bewegungen"

    def signal(self, m, sym, i):
        if i < 130:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        r = ca.roc(p["co.roc_n"])[i] / ap
        if abs(r) < p["co.k"] * 1.5:
            return NEUTRAL
        d = -1 if r > 0 else 1
        return Signal(d, min(0.85, 0.4 + 0.05 * (abs(r) - p["co.k"] * 1.5)), ap * 1.5, 1.5 * ap, f"Extrem {r:.1f} ATR")


class CautiousAgent(Agent):
    name, family = "Vorsichtig", "trend"
    affinity = {"up": 1.1, "down": 1.0, "range": 0.8}
    style = "Nur Setups mit Trend + Momentum + neutralem RSI + ruhiger Volatilität"

    def signal(self, m, sym, i):
        if i < 210:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        e48, e200 = ca.ema(48)[i], ca.ema(200)[i]
        rs, mh = ca.rsi(14)[i], ca.macd()[i]
        if m.regime[sym][i].vol_pct > p["ca.max_vol_pct"]:
            return NEUTRAL
        if c > e48 > e200 and mh > 0 and p["ca.rsi_min"] <= rs <= p["ca.rsi_max"]:
            return Signal(1, 0.8, ap * 2.2, 2 * ap, "Trend, MACD, RSI neutral, ruhig")
        if c < e48 < e200 and mh < 0 and 100 - p["ca.rsi_max"] <= rs <= 100 - p["ca.rsi_min"]:
            return Signal(-1, 0.8, ap * 2.2, 2 * ap, "Trend, MACD, RSI neutral, ruhig")
        return NEUTRAL


class DiversifierAgent(Agent):
    name, family = "Diversifizierer", "relstrength"
    affinity = {"up": 1.1, "down": 1.0, "range": 0.8}
    style = "Relative Stärke: stärkster Coin long, schwächster short (mit Trendfilter)"

    def signal(self, m, sym, i):
        if i < 210 or len(m.syms) < 3:
            return NEUTRAL
        ca, c, ap = self._basic(m, sym, i)
        rk, e96 = m.rel_rank(sym, i, 96), ca.ema(96)[i]
        if rk >= 0.8 and c > e96:
            return Signal(1, 0.55 + 0.2 * (rk - 0.8) * 5, ap * 1.8, 2 * ap, f"relative Stärke {rk:.2f}")
        if rk <= 0.2 and c < e96:
            return Signal(-1, 0.55 + 0.2 * (0.2 - rk) * 5, ap * 1.8, 2 * ap, f"relative Schwäche {rk:.2f}")
        return NEUTRAL


class RuleEMAAgent(Agent):
    name, family = "Regelbot EMA", "trend"
    style = "Einfacher Vergleichsbot (feste Parameter, keine Optimierung)"

    def signal(self, m, sym, i):
        if i < 210:
            return NEUTRAL
        ca, c, ap = self._basic(m, sym, i)
        gap = (ca.ema(80)[i] - ca.ema(200)[i]) / c
        if abs(gap) < 0.0015:
            return NEUTRAL
        return Signal(1 if gap > 0 else -1, 0.5, ap * 2.0, 2 * ap, f"EMA80/200-Abstand {gap * 100:.2f}%")


class RandomAgent(Agent):
    """Zufalls-Baseline (deterministisch). Zählt NICHT zum Team, läuft aber als Schatten-Konto zum Vergleich."""
    name, family, in_team = "Zufall", "random", False
    style = "Würfelt - wer das nicht schlägt, hat keinen Vorteil"

    def __init__(self, params=None, seed=42):
        super().__init__(params)
        self.seed = seed

    def signal(self, m, sym, i):
        rng = random.Random(self.seed * 1_000_003 + i * 97 + sum(map(ord, sym)))
        x = rng.random()
        if x > 0.03:
            return NEUTRAL
        ap = max(m.cache[sym].atr_pct_arr()[i], 1e-6)
        return Signal(1 if rng.random() < 0.5 else -1, 0.5, ap * 1.5, 2 * ap, "Würfel")


AGENT_CLASSES = [MomentumAgent, MeanReversionAgent, BreakoutAgent, TrendFollowerAgent, ScalperAgent,
                 ContrarianAgent, CautiousAgent, DiversifierAgent, RuleEMAAgent, RandomAgent]


def build_agents(params=None, seed=42):
    out = []
    for cls in AGENT_CLASSES:
        out.append(cls(params, seed) if cls is RandomAgent else cls(params))
    return out
