"""
Risk Management Engine + adaptiver Hebel-Manager.

Grundsätze (technisch erzwungen, NICHT nur im Prompt):
  * Alle Grenzen = min(Konfiguration/Parameter, HARD). Agenten, Meta-Learner und Optimierer können HARD nicht überschreiten.
  * Positionsgröße kommt aus dem erlaubten Verlust bei Stop-Loss (inkl. Gebühren, Spread, Slippage, Funding) - NICHT aus dem Hebel.
  * Hebel = kleinster Hebel, der die Position finanzieren kann (Policy min_feasible), begrenzt durch Stufen-Obergrenze
    (Signalqualität, statistische Zuverlässigkeit, Volatilität, Marktphase, Drawdown ...) und Liquidations-Sicherheitsabstand.
  * Kein Martingale, keine Hebelerhöhung nach Verlusten, kein Nachschuss.
"""
from __future__ import annotations

import math
from collections import Counter, namedtuple
from dataclasses import dataclass, field, asdict

from .config import HARD, Config
from .sim import liq_price, maintenance_margin, ExecutionSimulator, Account

MIN_SL, MAX_SL = 0.003, 0.08
TIER_LIST = [2, 5, 10, 15, 20]
TIER_PREF = {2: 1, 5: 3, 10: 6, 15: 11, 20: 16}


@dataclass
class RiskState:
    day_key: int = -1
    week_key: int = -1
    day_start: float = 0.0
    week_start: float = 0.0
    peak: float = 0.0
    status: str = "OK"          # OK | DAILY_LOCK | WEEKLY_LOCK | EMERGENCY
    reason: str = ""

    def to_dict(self):
        return asdict(self)


@dataclass
class OrderRequest:
    sym: str
    side: int
    ref_price: float
    atr_pct: float
    vol_pct: float
    conf: float
    agreement: float
    exp_ret: float
    stop_dist: float
    tp_dist: float
    trail_atr: float
    reliability: float
    ts: int
    regime_trend: str = "range"
    unusual: bool = False
    vol_label: str = "normal"
    liquidity: float = 0.8
    corr_sum: float = 0.0
    fund_rate: float | None = None
    agent: str = "team"
    regime_label: str = ""


@dataclass
class Approval:
    ok: bool
    reason: str
    notional: float = 0.0
    lev: int = 0
    margin: float = 0.0
    sl_dist: float = 0.0
    tp_dist: float = 0.0
    trail_atr_pct: float = 0.0
    risk_amount: float = 0.0
    info: dict = field(default_factory=dict)


Limits = namedtuple("Limits", "max_lev risk_trade daily weekly total exposure port_risk sym_risk max_open safety")


class LeverageManager:
    W = {"signal": .15, "reliability": .20, "vol": .12, "regime": .12, "liquidity": .08, "cost": .08,
         "util": .07, "corr": .06, "drawdown": .12}

    def decide(self, f: dict, cfg: Config, lim: Limits, consec_losses: int):
        mean = sum(self.W[k] * f[k] for k in self.W)
        critical = min(f["reliability"], f["drawdown"], f["vol"], f["signal"])
        score = 0.65 * mean + 0.35 * critical
        agr, rel, dd, vol = f["agreement"], f["reliability"], f["drawdown"], f["vol"]
        unusual = f["unusual"]
        cap = 2
        if score >= .35:
            cap = 5
        if score >= .55 and rel >= .4 and agr >= .65 and dd >= .6:
            cap = 10                                  # 6-10x nur mit statistisch validierter Zuverlässigkeit
        if score >= .70 and rel >= .55 and agr >= .75 and dd >= .7 and vol >= .4 and not unusual:
            cap = 15
        if (cfg.experimental_high_leverage and score >= .85 and rel >= .7 and agr >= .8 and dd >= .8 and vol >= .5
                and not unusual and f["util"] >= .5):
            cap = 20                                  # 16-20x: nur experimentell, strengste Prüfung
        idx = max(0, TIER_LIST.index(cap) - consec_losses // 2)   # nach Verlusten niemals höher, eher niedriger
        cap = min(TIER_LIST[idx], lim.max_lev)
        return score, cap


class RiskEngine:
    def __init__(self, cfg: Config, execsim: ExecutionSimulator):
        self.cfg, self.ex = cfg, execsim
        self.states: dict[str, RiskState] = {}
        self.events: list[dict] = []
        self.rejects = Counter()
        self.lm = LeverageManager()
        self.lev_study_cap: int | None = None

    # ------------------------- Grenzen -------------------------
    def limits(self, params: dict) -> Limits:
        cap = int(min(HARD.max_leverage, params.get("lev.cap", HARD.max_leverage)))
        if self.lev_study_cap:
            cap = min(cap, int(self.lev_study_cap))
        return Limits(
            max_lev=max(1, cap),
            risk_trade=min(params.get("team.risk_frac", self.cfg.risk_frac), self.cfg.risk_frac * 2, HARD.max_risk_per_trade),
            daily=HARD.max_daily_loss, weekly=HARD.max_weekly_loss, total=HARD.max_total_drawdown,
            exposure=HARD.max_portfolio_exposure_x, port_risk=HARD.max_portfolio_risk,
            sym_risk=HARD.max_risk_per_symbol, max_open=HARD.max_open_positions,
            safety=max(self.cfg.liq_safety_mult, HARD.min_liq_safety_mult))

    def state(self, name) -> RiskState:
        return self.states.setdefault(name, RiskState())

    def _event(self, ts, account, kind, detail):
        self.events.append({"ts": ts, "account": account, "kind": kind, "detail": detail})

    def drawdown_ratio(self, st: RiskState, equity: float) -> float:
        if st.peak <= 0:
            return 0.0
        day = max(0.0, (st.day_start - equity) / st.day_start) / HARD.max_daily_loss if st.day_start else 0
        week = max(0.0, (st.week_start - equity) / st.week_start) / HARD.max_weekly_loss if st.week_start else 0
        tot = max(0.0, (st.peak - equity) / st.peak) / HARD.max_total_drawdown
        return max(0.0, min(1.0, max(day, week, tot)))

    # ------------------------- Tages-/Wochen-/Gesamtlimits -------------------------
    def update(self, acct: Account, equity: float, ts: int):
        """Aktualisiert Perioden und prüft Limits. Rückgabe: None | 'close_losers' | 'close_all' | 'halt'."""
        st = self.state(acct.name)
        dk, wk = ts // 86_400_000, (ts // 86_400_000 + 3) // 7
        if st.peak <= 0:
            st.peak = st.day_start = st.week_start = equity
            st.day_key, st.week_key = dk, wk
        if dk != st.day_key:
            st.day_key, st.day_start = dk, equity
            if st.status == "DAILY_LOCK":
                st.status, st.reason = "OK", ""
        if wk != st.week_key:
            st.week_key, st.week_start = wk, equity
            if st.status in ("DAILY_LOCK", "WEEKLY_LOCK"):
                st.status, st.reason = "OK", ""
        if st.status == "EMERGENCY":
            return "halt"
        st.peak = max(st.peak, equity)
        day = (st.day_start - equity) / st.day_start / HARD.max_daily_loss
        week = (st.week_start - equity) / st.week_start / HARD.max_weekly_loss
        dd = (st.peak - equity) / st.peak
        if dd >= HARD.max_total_drawdown:
            st.status, st.reason = "EMERGENCY", f"Gesamt-Drawdown {dd:.1%} >= {HARD.max_total_drawdown:.0%}"
            self._event(ts, acct.name, "NOTFALL", st.reason)
            return "close_all"
        sev = max(day, week)
        if sev >= 1.0:
            new = "WEEKLY_LOCK" if week >= day else "DAILY_LOCK"
            if st.status != new:
                st.status = new
                st.reason = f"{'Wochen' if new == 'WEEKLY_LOCK' else 'Tages'}verlustlimit erreicht"
                self._event(ts, acct.name, new, st.reason)
            return "close_all" if sev >= 1.5 else "close_losers"
        return None

    def reset_emergency(self, name, ts=0):
        st = self.state(name)
        st.status, st.reason = "OK", ""
        st.peak = 0.0
        self._event(ts, name, "NOTFALL_ZURUECKGESETZT", "manuell")

    # ------------------------- Portfolio-Kennzahlen -------------------------
    def portfolio_risk(self, acct: Account, prices: dict, atr_by_sym=None) -> float:
        """Summe der möglichen Verluste bis zum Stop (inkl. Ausstiegskosten) aller offenen Positionen."""
        tot = 0.0
        for s, p in acct.positions.items():
            px = prices.get(s, p.entry)
            atrp = (atr_by_sym or {}).get(s, 0.004)
            tot += max(0.0, p.side * (px - p.sl)) * p.qty
            tot += p.qty * px * (self.cfg.fee_taker + self.ex.stop_slip(atrp))
        return tot

    def liq_dist(self, side, notional, lev):
        p = liq_price(side, notional, 1.0, notional / lev, self.cfg.liq_fee_rate + self.cfg.fee_taker)
        return abs(1.0 - p)

    # ------------------------- Genehmigung und Größenberechnung -------------------------
    def approve(self, acct: Account, prices: dict, req: OrderRequest, params: dict, bar_idx: int,
                atr_by_sym=None) -> Approval:
        cfg, ex = self.cfg, self.ex
        lim = self.limits(params)
        st = self.state(acct.name)
        eq = acct.equity(prices)

        def rej(reason, **info):
            self.rejects[reason.split(":")[0]] += 1
            return Approval(False, reason, info=info)

        if st.status != "OK":
            return rej(f"Risiko-Status {st.status}")
        if eq <= 0:
            return rej("Kein Kapital")
        if req.sym in acct.positions:
            return rej("Position existiert bereits")
        if len(acct.positions) >= lim.max_open:
            return rej("Maximale Positionszahl erreicht")
        if acct.cooldown.get(req.sym, 0) > bar_idx:
            return rej("Cooldown nach Stop-Loss")
        sl = max(MIN_SL, min(MAX_SL, req.stop_dist))
        tp = max(MIN_SL, min(0.30, req.tp_dist))
        atr = max(req.atr_pct, 1e-6)

        fee = cfg.fee_taker
        entry_c = ex.entry_cost_rate(atr)
        stop_s = ex.stop_slip(atr)
        fr = abs(req.fund_rate if req.fund_rate is not None else cfg.funding_const_8h)
        fund_exp = fr * cfg.expected_hold_bars * cfg.interval_sec / 28800.0
        rt_cost = 2 * fee + 2 * entry_c + fund_exp
        loss_unit = sl + 2 * fee + entry_c + stop_s + fund_exp          # Verlust je Notional bei Stop-Loss, alle Kosten

        # --- Kosten-/Nutzen-Prüfung (erwarteter Nettogewinn nach Kosten) ---
        gross = max(req.exp_ret, 0.0)
        net_edge = gross - rt_cost
        cost_ratio = rt_cost / gross if gross > 0 else 9.9
        if tp <= rt_cost * 1.5:
            return rej("Take-Profit kleiner als Kosten")
        if net_edge < cfg.min_net_edge:
            return rej("Erwarteter Nettogewinn nach Kosten zu gering")
        if cost_ratio > cfg.max_cost_ratio:
            return rej("Kostenquote zu hoch")

        # --- Risikobudget (dynamisch, nur Reduktion, nie Erhöhung) ---
        ddr = self.drawdown_ratio(st, eq)
        s_dd = max(0.25, 1.0 - 0.75 * ddr)
        s_vol = max(0.35, min(1.0, cfg.target_atr_pct / atr))
        s_reg = 0.5 if req.unusual else 0.7 if req.vol_label in ("high", "extreme") else 1.0
        s_loss = 0.5 if acct.consec_losses >= 3 else 1.0
        s_corr = max(0.35, 1.0 / (1.0 + 0.7 * req.corr_sum))
        scale = s_dd * s_vol * s_reg * s_loss * s_corr
        risk_target = min(eq * lim.risk_trade * scale, eq * HARD.max_risk_per_trade)
        n_risk = risk_target / loss_unit

        cur_exp = acct.exposure(prices)
        rem_exp = lim.exposure * eq - cur_exp
        rem_risk = lim.port_risk * eq - self.portfolio_risk(acct, prices, atr_by_sym)
        n_caps = min(n_risk, rem_exp, rem_risk / loss_unit, lim.sym_risk * eq / loss_unit)
        if n_caps < cfg.min_notional:
            return rej("Risikobudget erschöpft (Position zu klein)")

        # --- Hebel ---
        f = {"signal": max(0.0, min(1.0, req.conf * req.agreement)), "reliability": req.reliability,
             "vol": max(0.0, 1.0 - req.vol_pct),
             "regime": 0.1 if req.unusual else (1.0 if (req.regime_trend == "up" and req.side > 0) or (req.regime_trend == "down" and req.side < 0)
                                                 else 0.7 if req.regime_trend == "range" else 0.4),
             "liquidity": req.liquidity, "cost": max(0.0, 1.0 - cost_ratio / cfg.max_cost_ratio),
             "util": max(0.0, 1.0 - cur_exp / (lim.exposure * eq)), "corr": max(0.0, 1.0 - req.corr_sum),
             "drawdown": 1.0 - ddr, "agreement": req.agreement, "unusual": req.unusual}
        score, tier_cap = self.lm.decide(f, cfg, lim, acct.consec_losses)
        min_dist = lim.safety * (sl + stop_s) + cfg.gap_atr_mult * atr

        def safe_max(cap):
            for lv in range(int(cap), 0, -1):
                if self.liq_dist(req.side, n_caps, lv) >= min_dist:
                    return lv
            return 0

        def budget(lv):
            return min(eq * cfg.max_margin_share, acct.cash * 0.98 / (1.0 + fee * lv))

        if cfg.lev_mode == "fixed":
            lev = int(min(cfg.fixed_lev, lim.max_lev))
            lsm = safe_max(lev)
            if lsm < lev:
                return rej(f"Liquidationsabstand zu gering bei {lev}x (Stop-Loss zu weit)", min_dist=min_dist)
            rec = lev
        else:
            lsm = safe_max(tier_cap)
            rec = min(tier_cap, lsm)
            if rec < 1:
                return rej("Liquidationsabstand zu gering (Stop-Loss zu weit)", min_dist=min_dist)
            need = max(1, math.ceil(n_caps / max(1e-9, min(eq * cfg.max_margin_share, acct.cash * 0.97))))
            lev = need if cfg.lev_policy == "min_feasible" else max(need, TIER_PREF.get(tier_cap, 1))
            lev = min(lev, rec)
        notional = min(n_caps, budget(lev) * lev)
        if notional < cfg.min_notional:
            return rej("Position nach Margin-Prüfung zu klein")
        margin = notional / lev
        risk_amount = notional * loss_unit
        qty_ref = notional / req.ref_price
        liq = liq_price(req.side, qty_ref, req.ref_price, margin, cfg.liq_fee_rate + fee)
        info = {
            "score": round(score, 3), "tier_cap": tier_cap, "recommended_lev": rec, "lev": lev, "lev_safe_max": lsm,
            "factors": {k: (round(v, 3) if isinstance(v, float) else v) for k, v in f.items()},
            "scales": {"drawdown": round(s_dd, 2), "vol": round(s_vol, 2), "regime": round(s_reg, 2),
                       "losses": s_loss, "corr": round(s_corr, 2)},
            "liq_price": liq, "liq_distance": abs(1 - liq / req.ref_price), "sl_distance": sl,
            "min_liq_distance": min_dist, "initial_margin": margin, "maintenance_margin": maintenance_margin(notional),
            "fee_est": fee * notional * 2, "slippage_est": (entry_c + stop_s) * notional, "funding_est": fund_exp * notional,
            "breakeven_move": rt_cost, "cost_ratio": cost_ratio, "expected_gross": notional * gross,
            "expected_net": notional * net_edge, "loss_at_stop": risk_amount,
            "max_loss_sim": margin + fee * notional, "risk_pct": risk_amount / eq,
            "reason": (f"Hebel {lev}x (empfohlene Obergrenze {rec}x, Score {score:.2f}); Größe aus Risiko {risk_amount:.2f} USDT "
                       f"({risk_amount / eq:.2%} der Equity)"),
        }
        return Approval(True, "ok", notional, lev, margin, sl, tp, req.trail_atr * atr, risk_amount, info)
