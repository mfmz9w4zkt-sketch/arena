"""
Market Regime Detector (kausal, ohne Look-ahead).

Pro Kerze und Handelspaar:
  trend : "up" | "down" | "range"          (EMA50 vs. EMA200 relativ zur ATR + Steigung)
  vol   : "low" | "normal" | "high" | "extreme"   (Perzentil der ATR% im Verhältnis zu den letzten 1000 Kerzen)
  unusual: ungewöhnlich (Kurssprung > 5 Sigma, extreme Volatilität oder Volumen-Ausreißer)
  fast  : schnelle Bewegung (1h-Bewegung > 3 ATR%)
"""
from __future__ import annotations

from collections import namedtuple

from .indicators import rolling_std

Regime = namedtuple("Regime", "trend vol unusual fast strength vol_pct")

TREND_THR = 1.2


def compute_regimes(cache) -> list:
    s = cache.s
    n = len(s)
    c = s.c
    e50, e200 = cache.ema(50), cache.ema(200)
    atrp = cache.atr_pct_arr()
    volpct = cache.vol_pct(1000)
    rets = [0.0] + [c[i] / c[i - 1] - 1 for i in range(1, n)]
    sd = rolling_std(rets, 200)
    vsma = cache.vol_sma_prev(48)
    out = []
    for i in range(n):
        ap = atrp[i] or 1e-9
        gap = (e50[i] - e200[i]) / c[i]
        strength = gap / ap
        slope = (e50[i] - e50[i - 20]) / c[i] if i >= 20 else 0.0
        if i < 200:
            trend = "range"
        elif strength > TREND_THR and slope > 0:
            trend = "up"
        elif strength < -TREND_THR and slope < 0:
            trend = "down"
        else:
            trend = "range"
        vp = volpct[i] if i >= 100 else 0.5
        vol = "extreme" if vp >= 0.97 else "high" if vp >= 0.8 else "low" if vp <= 0.2 else "normal"
        sigma_ok = i > 200 and sd[i - 1] > 0
        jump = sigma_ok and abs(rets[i]) > 5 * sd[i - 1]
        vol_out = vsma[i] > 0 and s.v[i] > 6 * vsma[i]
        unusual = bool(jump or vol_out or vol == "extreme")
        fast = bool(i >= 4 and abs(c[i] / c[i - 4] - 1) > 3 * ap)
        out.append(Regime(trend, vol, unusual, fast, strength, vp))
    return out


def tags(r: Regime) -> list:
    """Kategorien für die Auswertung nach Marktphasen (ein Trade kann mehrere haben)."""
    t = {"up": "Bull", "down": "Bear", "range": "Seitwaerts"}[r.trend]
    out = [t]
    if r.vol in ("high", "extreme"):
        out.append("Hohe Volatilitaet")
    if r.vol == "low":
        out.append("Niedrige Volatilitaet")
    if r.fast:
        out.append("Schnelle Bewegung")
    return out


def label(r: Regime) -> str:
    return f"{r.trend}/{r.vol}" + ("/ungewoehnlich" if r.unusual else "")
