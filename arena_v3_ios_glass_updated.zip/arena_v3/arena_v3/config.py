"""
Zentrale Konfiguration der KI-Trading-Arena V3.

WICHTIG: HARD (HardLimits) ist unveränderlich (frozen dataclass). Die Risk Engine nimmt immer min(Konfiguration, HARD).
Weder Konfigurationsdatei, noch Optimierer, Meta-Learner oder Agenten können diese Grenzen überschreiten.
Alles läuft ausschließlich als Paper Trading (Spielgeld). Live-Trading ist NICHT implementiert.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict, fields

LIVE_TRADING_IMPLEMENTED = False  # bewusst fest: es gibt keinen Code, der echte Orders sendet


@dataclass(frozen=True)
class HardLimits:
    max_leverage: int = 20             # absolute Hebel-Obergrenze
    max_risk_per_trade: float = 0.01   # max. 1 % der Kontoequity Verlust pro Trade (bei Stop-Loss, inkl. Kosten)
    max_daily_loss: float = 0.03       # 3 % Tagesverlust -> keine neuen Positionen
    max_weekly_loss: float = 0.06      # 6 % Wochenverlust -> keine neuen Positionen
    max_total_drawdown: float = 0.10   # 10 % Drawdown vom Höchststand -> Notfallabschaltung
    max_portfolio_exposure_x: float = 3.0   # Summe aller Positionsgrößen <= 3x Equity
    max_portfolio_risk: float = 0.03   # Summe der Stop-Loss-Risiken aller Positionen <= 3 % Equity
    max_risk_per_symbol: float = 0.01  # max. Risiko pro Handelspaar
    max_open_positions: int = 5
    min_liq_safety_mult: float = 1.5   # Liquidationsabstand >= 1,5 x Stop-Abstand (plus Lücken-Puffer)


HARD = HardLimits()


@dataclass
class Config:
    # ---- Märkte & Takt
    symbols: tuple = ("BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "LINKUSDT", "ADAUSDT")
    interval_sec: int = 900            # 15-Minuten-Kerzen
    start_equity: float = 1000.0
    warmup_bars: int = 320             # Kerzen, bevor gehandelt wird (Indikator-Einschwingen)
    # ---- Ausführungsmodell
    fee_taker: float = 0.0005
    fee_maker: float = 0.0002
    half_spread: float = 0.0001        # halber Spread pro Ausführung
    slip_base: float = 0.0002
    slip_vol_mult: float = 0.05        # zusätzlich: 5 % der ATR% (als Bruchteil)
    stop_slip_mult: float = 2.5        # Stops werden schlechter ausgeführt als normale Orders
    liq_fee_rate: float = 0.005        # Liquidationsgebühr (Reserve bei der Liquidationsberechnung)
    funding_const_8h: float = 0.0001   # nur wenn keine echten Funding-Daten vorliegen
    funding_conservative: bool = True  # bei konstantem Funding zahlen Long UND Short (kein Vorteil für Shorts)
    expected_hold_bars: int = 24
    # ---- Risiko / Sizing (alles wird auf HARD begrenzt)
    risk_frac: float = 0.005
    target_atr_pct: float = 0.004
    max_margin_share: float = 0.35     # max. Anteil der Equity als Margin pro Position
    min_notional: float = 10.0
    cooldown_bars: int = 4
    death_equity: float = 0.0          # Tod: Equity <= max(death_equity, min_notional/20 = 0,50 USDT) -> KI stirbt dauerhaft
    liq_safety_mult: float = 1.5
    gap_atr_mult: float = 2.0          # Kurslücken-Puffer in ATR
    max_cost_ratio: float = 0.5        # Kosten dürfen höchstens 50 % des erwarteten Bruttogewinns sein
    min_net_edge: float = 0.0005       # erwarteter Nettogewinn je Notional mindestens 0,05 %
    lev_policy: str = "min_feasible"   # min_feasible | tier_pref  (siehe README)
    lev_mode: str = "adaptive"         # adaptive | fixed (fixed nur für die Hebel-Studie)
    fixed_lev: int = 1
    experimental_high_leverage: bool = True   # 16-20x nur unter strengsten Prüfungen (nur Paper)
    # ---- Aggregation / Lernen
    shadow_min_conf: float = 0.5
    neutral_weight: float = 0.35
    conflict_thr: float = 0.4
    corr_gamma: float = 1.0
    learn_every: int = 96              # Gewichte alle 96 Kerzen (24 h) aktualisieren
    n_min: int = 20                    # Mindeststichprobe, bevor ein Agent vom Neutralwert abweicht
    shrink_k: float = 20.0
    z_conf: float = 1.28
    half_life_bars: int = 1344         # ~14 Tage
    w_min: float = 0.1
    w_max: float = 2.0
    weight_smooth: float = 0.3
    disable_hours: int = 48
    deact_n: int = 30
    # ---- Optimierung / Validierung
    opt_trials: int = 30
    opt_segments: int = 3
    opt_light: bool = True             # Optimierung ohne Schatten-Konten (schneller; Gewichte gleich)
    min_trades_segment: int = 5
    wf_train_bars: int = 2400
    wf_test_bars: int = 800
    wf_step_bars: int = 800
    # ---- Champion/Challenger
    promo_min_oos_pf: float = 1.2
    promo_max_oos_mdd: float = 0.15
    promo_min_oos_trades: int = 30
    promo_min_pos_folds: float = 0.6
    promo_min_fwd_trades: int = 30
    promo_min_fwd_pf: float = 1.1
    promo_max_fwd_mdd: float = 0.12
    promo_min_regimes: int = 2
    promo_margin: float = 1.10
    rollback_min_trades: int = 20
    rollback_min_pf: float = 0.9
    rollback_max_mdd: float = 0.12
    # ---- System
    db_path: str = "arena_v3.db"
    port: int = 8000
    host: str = "127.0.0.1"
    seed: int = 42

    @staticmethod
    def load(path: str | None) -> "Config":
        cfg = Config()
        if path:
            with open(path) as f:
                raw = json.load(f)
            names = {f_.name for f_ in fields(Config)}
            for k, v in raw.items():
                if k in names and not k.startswith("_"):
                    setattr(cfg, k, tuple(v) if k == "symbols" else v)
        return cfg

    def to_dict(self) -> dict:
        d = asdict(self)
        d["symbols"] = list(self.symbols)
        return d


# --------------------------- Parameterraum für die Optimierung ---------------------------
# name: (min, max, typ). Die Grenzen sind selbst durch HARD begrenzt (z. B. risk_frac <= 1 %, Hebel <= 20).
PARAM_SPACE = {
    "mom.ema_fast": (5, 30, "i"), "mom.ema_slow": (30, 120, "i"), "mom.roc_n": (4, 48, "i"), "mom.min_gap": (0.1, 2.0, "f"),
    "mr.rsi_low": (15.0, 40.0, "f"), "mr.rsi_high": (60.0, 85.0, "f"), "mr.bb_n": (10, 40, "i"), "mr.bb_k": (1.5, 3.0, "f"),
    "bo.lookback": (20, 120, "i"), "bo.vol_mult": (1.0, 2.5, "f"),
    "tf.fast": (40, 120, "i"), "tf.slow": (120, 320, "i"), "tf.min_gap": (0.2, 2.5, "f"),
    "sc.roc_n": (2, 8, "i"), "sc.vol_mult": (1.0, 3.0, "f"),
    "co.roc_n": (8, 48, "i"), "co.k": (1.5, 6.0, "f"),
    "ca.rsi_min": (30.0, 48.0, "f"), "ca.rsi_max": (55.0, 72.0, "f"), "ca.max_vol_pct": (0.4, 0.9, "f"),
    "team.consensus": (0.15, 0.7, "f"), "team.agreement": (0.55, 0.9, "f"), "team.min_conf": (0.25, 0.7, "f"),
    "team.stop_atr": (1.0, 4.0, "f"), "team.tp_atr": (1.5, 8.0, "f"), "team.trail_atr": (0.0, 4.0, "f"),
    "team.risk_frac": (0.001, HARD.max_risk_per_trade, "f"), "team.vol_filter": (0.5, 1.0, "f"),
    "team.skip_block": (0, 6, "i"),            # 4-Stunden-Block (UTC) ohne neue Einstiege; 6 = kein Zeitfilter
    "lev.cap": (2, HARD.max_leverage, "i"),    # vom Optimierer wählbare Hebel-Obergrenze (<= 20)
}
DEFAULT_PARAMS = {
    "mom.ema_fast": 8, "mom.ema_slow": 48, "mom.roc_n": 16, "mom.min_gap": 0.5,
    "mr.rsi_low": 30.0, "mr.rsi_high": 70.0, "mr.bb_n": 20, "mr.bb_k": 2.0,
    "bo.lookback": 48, "bo.vol_mult": 1.3,
    "tf.fast": 80, "tf.slow": 200, "tf.min_gap": 0.8,
    "sc.roc_n": 3, "sc.vol_mult": 1.5,
    "co.roc_n": 16, "co.k": 3.0,
    "ca.rsi_min": 40.0, "ca.rsi_max": 65.0, "ca.max_vol_pct": 0.7,
    "team.consensus": 0.35, "team.agreement": 0.65, "team.min_conf": 0.4,
    "team.stop_atr": 2.0, "team.tp_atr": 3.0, "team.trail_atr": 0.0,
    "team.risk_frac": 0.005, "team.vol_filter": 0.9, "team.skip_block": 6,
    "lev.cap": 20,
}


def clamp_params(p: dict | None) -> dict:
    """Füllt fehlende Parameter auf, begrenzt alle Werte auf den erlaubten Bereich und korrigiert Typen."""
    out = dict(DEFAULT_PARAMS)
    for k, v in (p or {}).items():
        if k in PARAM_SPACE:
            lo, hi, kind = PARAM_SPACE[k]
            try:
                v = float(v)
            except (TypeError, ValueError):
                continue
            v = max(lo, min(hi, v))
            out[k] = int(round(v)) if kind == "i" else v
    if out["mom.ema_fast"] >= out["mom.ema_slow"]:
        out["mom.ema_fast"] = max(5, out["mom.ema_slow"] - 5)
    if out["tf.fast"] >= out["tf.slow"]:
        out["tf.fast"] = max(40, out["tf.slow"] - 20)
    if out["team.tp_atr"] < out["team.stop_atr"]:
        out["team.tp_atr"] = out["team.stop_atr"]
    return out
