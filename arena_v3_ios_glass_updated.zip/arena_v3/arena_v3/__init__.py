"""KI-Trading-Arena V3 - kooperatives, selbstlernendes Multi-Agent-Paper-Trading-System (nur Spielgeld)."""
__version__ = "3.0.0"
