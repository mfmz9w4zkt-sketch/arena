"""
Execution Simulator (Paper Trading, Isolated Margin, lineare USDT-Perpetuals).

Es werden KEINE echten Orders gesendet. Modelliert werden:
  * Gebühren (Taker/Maker), Spread, Slippage (volatilitätsabhängig), Stop-Slippage (schlechter als normal)
  * Funding (echte Raten, falls vorhanden; sonst konstante, konservative Schätzung)
  * Maintenance-Margin-Stufen (angelehnt an Binance-BTC-Stufen, vereinfacht) und Liquidationspreis (laufend neu berechnet)
  * Kurslücken: öffnet eine Kerze jenseits des Stops, wird zum (schlechteren) Eröffnungskurs ausgeführt
  * Liquidation: isolierte Margin wird komplett verbucht (kein Nachschuss, kein negatives Konto)
"""
from __future__ import annotations

import itertools
import uuid
from dataclasses import dataclass, field, asdict

from .config import Config
from .data import Candle

FUND_MS = 8 * 3600 * 1000
# (ab Notional, Maintenance-Rate, kumulierter Abzug)
TIERS = [(0, 0.004, 0.0), (50_000, 0.005, 50.0), (250_000, 0.01, 1_300.0),
         (1_000_000, 0.025, 16_300.0), (10_000_000, 0.05, 266_300.0)]


def mm_tier(notional: float):
    rate, cum = TIERS[0][1], TIERS[0][2]
    for lo, r, c in TIERS:
        if notional >= lo:
            rate, cum = r, c
    return rate, cum


def maintenance_margin(notional: float) -> float:
    rate, cum = mm_tier(notional)
    return max(0.0, notional * rate - cum)


def liq_price(side: int, qty: float, entry: float, margin: float, fee_reserve_rate: float = 0.0) -> float:
    """
    Liquidationspreis für Isolated Margin. Gleichsetzen von Equity und Maintenance Margin:
      Long : M + Q(P-E) = Q P r - c  ->  P = (QE - M - c) / (Q (1 - r))
      Short: M + Q(E-P) = Q P r - c  ->  P = (M + QE + c) / (Q (1 + r))
    M ist die Margin abzüglich einer Reserve für Schließ- und Liquidationsgebühren (konservativ).
    """
    n = qty * entry
    rate, cum = mm_tier(n)
    m = margin - fee_reserve_rate * n
    if side > 0:
        return max(0.0, (qty * entry - m - cum) / (qty * (1 - rate)))
    return (m + qty * entry + cum) / (qty * (1 + rate))


@dataclass
class Position:
    sym: str
    side: int                  # +1 long, -1 short
    qty: float
    entry: float
    lev: int
    margin0: float             # ursprüngliche Initial Margin
    margin: float              # aktuelle isolierte Margin (nach Funding)
    sl: float
    tp: float
    trail_dist: float          # absoluter Preisabstand, 0 = aus
    open_ts: int
    open_fee: float
    ref_entry: float           # Referenzpreis ohne Slippage
    risk_amount: float         # geplanter Verlust bei Stop (inkl. Kosten)
    conf: float = 0.0
    agent: str = "team"
    regime: str = ""
    lev_info: dict = field(default_factory=dict)
    funding_paid: float = 0.0
    slip_cost: float = 0.0
    best: float = 0.0
    min_unreal: float = 0.0
    bars: int = 0
    oid: str = ""

    def unreal(self, price):
        return self.side * (price - self.entry) * self.qty


@dataclass
class ClosedTrade:
    id: str
    system: str
    account: str
    agent: str
    symbol: str
    side: int
    regime: str
    open_ts: int
    close_ts: int
    entry: float
    exit: float
    qty: float
    notional: float
    lev: int
    gross_pnl: float
    fees: float
    slippage: float
    funding: float
    net_pnl: float
    r_multiple: float
    hold_bars: int
    max_adverse_pct: float     # größter Rückgang während des Trades relativ zur Margin
    conf: float
    reason: str
    liquidated: bool
    lev_info: dict = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)


@dataclass
class Account:
    name: str
    cash: float
    start_equity: float
    positions: dict = field(default_factory=dict)
    fees: float = 0.0
    funding: float = 0.0
    slippage: float = 0.0
    liquidations: int = 0
    n_trades: int = 0
    cooldown: dict = field(default_factory=dict)   # {sym: bis Bar-Index}
    consec_losses: int = 0

    def equity(self, prices: dict) -> float:
        e = self.cash
        for s, p in self.positions.items():
            e += p.margin + p.unreal(prices.get(s, p.entry))
        return e

    def exposure(self, prices: dict) -> float:
        return sum(p.qty * prices.get(s, p.entry) for s, p in self.positions.items())

    def to_dict(self):
        return {"name": self.name, "cash": self.cash, "start_equity": self.start_equity,
                "positions": {s: asdict(p) for s, p in self.positions.items()},
                "fees": self.fees, "funding": self.funding, "slippage": self.slippage,
                "liquidations": self.liquidations, "n_trades": self.n_trades, "cooldown": self.cooldown,
                "consec_losses": self.consec_losses}

    @staticmethod
    def from_dict(d):
        a = Account(d["name"], d["cash"], d["start_equity"])
        a.positions = {s: Position(**p) for s, p in d.get("positions", {}).items()}
        for k in ("fees", "funding", "slippage", "liquidations", "n_trades", "cooldown", "consec_losses"):
            setattr(a, k, d.get(k, getattr(a, k)))
        return a


class ExecutionSimulator:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self._ids = itertools.count(1)

    # ------------------------- Kostenmodell -------------------------
    def slip(self, atr_pct: float) -> float:
        return self.cfg.slip_base + self.cfg.slip_vol_mult * atr_pct

    def stop_slip(self, atr_pct: float) -> float:
        return self.slip(atr_pct) * self.cfg.stop_slip_mult

    def entry_cost_rate(self, atr_pct: float) -> float:
        """Spread + Slippage pro Ausführung (Bruchteil des Notionals)."""
        return self.cfg.half_spread + self.slip(atr_pct)

    def round_trip_cost_rate(self, atr_pct: float, fund_rate: float | None = None) -> float:
        fr = abs(fund_rate if fund_rate is not None else self.cfg.funding_const_8h)
        fund = fr * self.cfg.expected_hold_bars * self.cfg.interval_sec / 28800.0
        return 2 * self.cfg.fee_taker + 2 * self.entry_cost_rate(atr_pct) + fund

    def liq_for(self, p: Position) -> float:
        return liq_price(p.side, p.qty, p.entry, p.margin, self.cfg.liq_fee_rate + self.cfg.fee_taker)

    # ------------------------- Eröffnen -------------------------
    def open_position(self, acct: Account, sym, side, notional, lev, sl_dist, tp_dist, trail_atr_pct, ref_price,
                      atr_pct, ts, risk_amount, conf=0.0, agent="team", regime="", lev_info=None, oid=None):
        fill = ref_price * (1 + side * self.entry_cost_rate(atr_pct))
        qty = notional / fill
        margin = qty * fill / lev
        fee = self.cfg.fee_taker * qty * fill
        if margin + fee > acct.cash + 1e-9:
            return None
        acct.cash -= margin + fee
        acct.fees += fee
        slip_cost = qty * abs(fill - ref_price)
        acct.slippage += slip_cost
        acct.n_trades += 1
        pos = Position(sym=sym, side=side, qty=qty, entry=fill, lev=lev, margin0=margin, margin=margin,
                       sl=fill * (1 - side * sl_dist), tp=fill * (1 + side * tp_dist),
                       trail_dist=trail_atr_pct * fill if trail_atr_pct > 0 else 0.0, open_ts=ts, open_fee=fee,
                       ref_entry=ref_price, risk_amount=risk_amount, conf=conf, agent=agent, regime=regime,
                       lev_info=lev_info or {}, slip_cost=slip_cost, best=fill, oid=oid or f"{acct.name}-{next(self._ids)}")
        acct.positions[sym] = pos
        return pos

    # ------------------------- Schließen -------------------------
    def _finish(self, acct: Account, pos: Position, fill, ref, ts, reason, fee_rate, system, liquidated=False):
        sym = pos.sym
        gross = pos.side * (fill - pos.entry) * pos.qty
        slip_exit = pos.qty * abs(fill - ref)
        acct.slippage += slip_exit
        if liquidated:
            net = -(pos.margin0 + pos.open_fee)          # gesamte Margin + Eröffnungsgebühr verloren
            fees = gross - pos.funding_paid - net         # Rest (Liquidationsstrafe) als Gebühren verbucht
            acct.fees += max(0.0, fees - pos.open_fee)
            exit_fee = 0.0
        else:
            exit_fee = fee_rate * pos.qty * fill
            acct.cash += pos.margin + gross - exit_fee
            acct.fees += exit_fee
            net = gross - pos.open_fee - exit_fee - pos.funding_paid
            fees = pos.open_fee + exit_fee
        acct.positions.pop(sym, None)
        acct.funding += pos.funding_paid
        if liquidated:
            acct.liquidations += 1
        acct.consec_losses = acct.consec_losses + 1 if net < 0 else 0
        risk = pos.risk_amount if pos.risk_amount > 0 else 1.0
        return ClosedTrade(
            id=pos.oid, system=system, account=acct.name, agent=pos.agent, symbol=sym, side=pos.side, regime=pos.regime,
            open_ts=pos.open_ts, close_ts=ts, entry=pos.entry, exit=fill, qty=pos.qty, notional=pos.qty * pos.entry,
            lev=pos.lev, gross_pnl=gross, fees=fees, slippage=pos.slip_cost + slip_exit, funding=pos.funding_paid,
            net_pnl=net, r_multiple=net / risk, hold_bars=pos.bars,
            max_adverse_pct=min(0.0, pos.min_unreal) / pos.margin0 if pos.margin0 else 0.0, conf=pos.conf,
            reason=reason, liquidated=liquidated, lev_info=pos.lev_info)

    def close_market(self, acct, sym, ref_price, ts, reason, atr_pct, system="sys"):
        pos = acct.positions[sym]
        fill = ref_price * (1 - pos.side * self.entry_cost_rate(atr_pct))
        return self._finish(acct, pos, fill, ref_price, ts, reason, self.cfg.fee_taker, system)

    # ------------------------- Funding -------------------------
    def apply_funding(self, acct, pos: Position, candle: Candle, prev_ts, series_funding=None):
        """Belastet Funding für alle Funding-Zeitpunkte f mit prev_ts < f <= candle.ts (isolierte Margin)."""
        f = (prev_ts // FUND_MS + 1) * FUND_MS
        total = 0.0
        while f <= candle.ts:
            notional = pos.qty * candle.o
            if series_funding and f in series_funding:
                cost = pos.side * series_funding[f] * notional          # Long zahlt bei positiver Rate
            else:
                r = self.cfg.funding_const_8h
                cost = (abs(r) if self.cfg.funding_conservative else pos.side * r) * notional
            total += cost
            f += FUND_MS
        if total:
            pos.margin -= total
            pos.funding_paid += total
        return total

    # ------------------------- Kerzen-Verarbeitung -------------------------
    def process_candle(self, acct: Account, sym, c: Candle, atr_pct, prev_ts, series_funding=None, system="sys",
                       bar_index=0):
        """Funding, Lücken, Stop-Loss, Liquidation, Take-Profit, Trailing. Gibt Liste abgeschlossener Trades zurück."""
        pos = acct.positions.get(sym)
        if pos is None:
            return []
        pos.bars += 1
        self.apply_funding(acct, pos, c, prev_ts, series_funding)
        s = pos.side
        liq = self.liq_for(pos)
        ss = self.stop_slip(atr_pct)
        out = []
        beyond = (lambda x, lvl: x <= lvl) if s > 0 else (lambda x, lvl: x >= lvl)
        worst = c.l if s > 0 else c.h
        best = c.h if s > 0 else c.l
        if pos.margin <= 0 or beyond(c.o, liq):
            out.append(self._finish(acct, pos, c.o if pos.margin > 0 else liq, liq, c.ts, "Liquidation", 0, system, True))
        elif beyond(c.o, pos.sl):                                  # Kurslücke durch den Stop
            fill = c.o * (1 - s * ss)
            if beyond(fill, liq):
                out.append(self._finish(acct, pos, liq, liq, c.ts, "Liquidation (Gap)", 0, system, True))
            else:
                out.append(self._finish(acct, pos, fill, pos.sl, c.ts, "Stop-Loss (Gap)", self.cfg.fee_taker, system))
        elif beyond(worst, pos.sl):                                # Stop wird intra-Kerze erreicht
            fill = pos.sl * (1 - s * ss)
            if beyond(fill, liq):
                out.append(self._finish(acct, pos, liq, liq, c.ts, "Liquidation", 0, system, True))
            else:
                out.append(self._finish(acct, pos, fill, pos.sl, c.ts, "Stop-Loss", self.cfg.fee_taker, system))
        elif beyond(worst, liq):
            out.append(self._finish(acct, pos, liq, liq, c.ts, "Liquidation", 0, system, True))
        elif (best >= pos.tp) if s > 0 else (best <= pos.tp):      # Take-Profit (Limit, Maker, keine Slippage)
            out.append(self._finish(acct, pos, pos.tp, pos.tp, c.ts, "Take-Profit", self.cfg.fee_maker, system))
        else:
            adverse = s * ((worst - pos.entry) * pos.qty)
            pos.min_unreal = min(pos.min_unreal, adverse)
            pos.best = max(pos.best, best) if s > 0 else min(pos.best, best)
            if pos.trail_dist > 0:                                  # Trailing erst NACH der Prüfung (kein Look-ahead)
                new_sl = pos.best - s * pos.trail_dist
                if (s > 0 and new_sl > pos.sl and new_sl < c.c) or (s < 0 and new_sl < pos.sl and new_sl > c.c):
                    pos.sl = new_sl
        if out:
            acct.cooldown[sym] = bar_index + self.cfg.cooldown_bars if out[0].net_pnl < 0 else acct.cooldown.get(sym, 0)
        return out
