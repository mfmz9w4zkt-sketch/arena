"""
Champion-Challenger-Manager.

Champion   = aktuell produktive Paper-Trading-Parameter (bewährt, kontrolliertes Risiko).
Challenger = neue/optimierte Parameter. Läuft zunächst NUR isoliert im Paper Trading (eigenes Konto, eigene Lerndaten).

Ein Challenger wird nur ZUGELASSEN, wenn der Walk-forward-Test (Out-of-sample) robust ist, und ersetzt den Champion erst,
wenn er zusätzlich im Vorwärts-Paper-Trading überzeugt (genug Trades, netto profitabel, Drawdown, Profit Factor,
mehrere Marktphasen, besser als der Champion). Bei Verschlechterung des Champions ist ein automatischer Rollback möglich.
"""
from __future__ import annotations

import time

from .config import DEFAULT_PARAMS, Config, clamp_params
from .optimizer import score_metrics


class ChampionChallenger:
    def __init__(self, cfg: Config, db=None):
        self.cfg, self.db = cfg, db
        self.champion = {"version": 1, "params": dict(DEFAULT_PARAMS), "since": 0, "note": "Standardparameter"}
        self.challenger = None
        self.history = []          # frühere Champions (für Rollback)
        self.log = []

    # ------------------------------------------------------------------
    def _log(self, ts, kind, detail):
        rec = {"ts": ts, "kind": kind, "detail": detail}
        self.log.append(rec)
        self.log = self.log[-100:]
        if self.db:
            self.db.add_event(ts, "champion-challenger", "-", kind, detail)

    def next_version(self):
        v = self.champion["version"]
        if self.challenger:
            v = max(v, self.challenger["version"])
        for h in self.history:
            v = max(v, h["version"])
        return v + 1

    def propose(self, params, wf_report, ts=0):
        """Registriert einen Challenger, wenn der Walk-forward-Test robust war."""
        checks = wf_report["checks"]
        if not wf_report["robust"]:
            failed = [k for k, v in checks.items() if not v]
            self._log(ts, "CHALLENGER_ABGELEHNT", f"Walk-forward nicht robust: {failed}")
            return {"accepted": False, "failed": failed}
        if self.challenger and self.challenger["params"] == clamp_params(params):
            return {"accepted": False, "failed": ["identisch mit aktuellem Challenger"]}
        v = self.next_version()
        self.challenger = {"version": v, "params": clamp_params(params), "since": ts,
                           "wf": {"metrics": {k: wf_report["metrics"][k] for k in
                                              ("net_return", "profit_factor", "sharpe", "sortino", "max_drawdown", "trades")},
                                  "folds_positive": wf_report["positive_fold_fraction"]}}
        self._log(ts, "CHALLENGER_REGISTRIERT", f"Version {v} (Walk-forward robust), startet im isolierten Paper Trading")
        if self.db:
            self.db.save_params("challenger", v, self.challenger["params"], self.challenger["wf"])
        return {"accepted": True, "version": v}

    def evaluate_promotion(self, challenger_metrics, challenger_regimes, champion_metrics, ts=0):
        cfg = self.cfg
        if not self.challenger:
            return {"promote": False, "reason": "kein Challenger"}
        m = challenger_metrics
        pf = m["profit_factor"] if m["profit_factor"] is not None else 0.0
        reg_ok = sum(1 for v in challenger_regimes.values() if v["trades"] >= 5 and v["net_pnl"] >= 0)
        s_ch = score_metrics(m, cfg, cfg.promo_min_fwd_trades)
        s_cp = score_metrics(champion_metrics, cfg, 1)
        better = s_ch > (s_cp * cfg.promo_margin if s_cp > 0 else s_cp + 0.05)
        checks = {
            "trades": m["trades"] >= cfg.promo_min_fwd_trades,
            "net_positiv": m["net_return"] > 0,
            "profit_factor": pf >= cfg.promo_min_fwd_pf,
            "drawdown": m["max_drawdown"] <= cfg.promo_max_fwd_mdd,
            "marktphasen": reg_ok >= cfg.promo_min_regimes,
            "besser_als_champion": better,
        }
        if all(checks.values()):
            self.history.append(self.champion)
            old = self.champion["version"]
            self.champion = {"version": self.challenger["version"], "params": self.challenger["params"], "since": ts,
                             "note": f"befördert aus Challenger (löst v{old} ab)"}
            self.challenger = None
            self._log(ts, "PROMOTION", f"Challenger v{self.champion['version']} ersetzt Champion v{old}: {checks}")
            if self.db:
                self.db.save_params("champion", self.champion["version"], self.champion["params"], {"checks": checks})
            return {"promote": True, "checks": checks}
        return {"promote": False, "checks": checks}

    def check_rollback(self, recent_metrics, ts=0):
        """Prüft, ob der Champion seit seiner Beförderung deutlich schlechter läuft -> Rollback auf die vorherige Version."""
        cfg = self.cfg
        if not self.history or recent_metrics["trades"] < cfg.rollback_min_trades:
            return {"rollback": False}
        pf = recent_metrics["profit_factor"] or 0.0
        bad = pf < cfg.rollback_min_pf or recent_metrics["max_drawdown"] > cfg.rollback_max_mdd
        if bad:
            old = self.champion["version"]
            self.champion = self.history.pop()
            self.champion["since"] = ts
            self._log(ts, "ROLLBACK", f"Champion v{old} verschlechtert (PF {pf:.2f}, MDD {recent_metrics['max_drawdown']:.1%}); "
                                      f"zurück zu v{self.champion['version']}")
            if self.db:
                self.db.save_params("champion", self.champion["version"], self.champion["params"], {"rollback_from": old})
            return {"rollback": True, "to": self.champion["version"]}
        return {"rollback": False}

    def to_dict(self):
        return {"champion": self.champion, "challenger": self.challenger, "history": self.history, "log": self.log}

    def load_dict(self, d):
        self.champion = d.get("champion", self.champion)
        self.challenger = d.get("challenger")
        self.history = d.get("history", [])
        self.log = d.get("log", [])
