#!/usr/bin/env python3
"""Führt alle Tests aus und schreibt TESTREPORT.md (Bestanden/Nicht bestanden, Fehler, offene Punkte, Einschränkungen, Beispiel-Backtests)."""
import dataclasses, sys, time, unittest, os, io, datetime
ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)
os.chdir(ROOT)

class Rec(unittest.TextTestResult):
    def __init__(s, *a, **k):
        super().__init__(*a, **k); s.rows = []; s._t = 0
    def startTest(s, t): s._t = time.time(); super().startTest(t)
    def _add(s, t, st, msg=""): s.rows.append((t.id().split("tests.test_v3.")[-1], st, round(time.time() - s._t, 2), msg))
    def addSuccess(s, t): super().addSuccess(t); s._add(t, "bestanden")
    def addFailure(s, t, e): super().addFailure(t, e); s._add(t, "NICHT bestanden", s._exc_info_to_string(e, t)[-600:])
    def addError(s, t, e): super().addError(t, e); s._add(t, "FEHLER", s._exc_info_to_string(e, t)[-600:])

def main():
    import warnings; warnings.simplefilter("ignore")
    suite = unittest.defaultTestLoader.discover(os.path.join(ROOT, "tests"), pattern="test_v3.py", top_level_dir=ROOT)
    stream = io.StringIO()
    res = unittest.TextTestRunner(stream=stream, resultclass=Rec, verbosity=0).run(suite)
    ok = sum(1 for r in res.rows if r[1] == "bestanden"); bad = len(res.rows) - ok
    print(f"{ok}/{len(res.rows)} Tests bestanden")
    from arena_v3.config import Config
    from arena_v3.data import generate_synthetic
    from arena_v3.backtest import run_backtest, walk_forward, leverage_study
    from arena_v3.analytics import fmt
    cfg = dataclasses.replace(Config(), wf_train_bars=1200, wf_test_bars=500, wf_step_bars=500, opt_trials=4, opt_segments=2)
    data = generate_synthetic(list(cfg.symbols), 3500, seed=11)
    ex = []
    t0 = time.time(); bt = run_backtest(data, cfg, None, start=400, end=3500); m = bt["metrics"]
    ex.append(("Backtest (Standardparameter, Kerzen 400-3500, seed 11)", m, bt["regimes"], round(time.time() - t0, 1)))
    wf = walk_forward(data, cfg, n_trials=4)
    lv = leverage_study(data, cfg, None, levels=(1, 2, 3, 5, 10, 15, 20))
    L = []
    w = L.append
    w("# Testbericht KI-Trading-Arena V3\n")
    w(f"Erstellt: {datetime.datetime.now():%Y-%m-%d %H:%M}  |  Python {sys.version.split()[0]}  |  Alle Tests laufen offline (synthetische Daten).\n")
    w(f"## Ergebnis: **{ok} von {len(res.rows)} Tests bestanden**" + ("" if not bad else f", **{bad} nicht bestanden**") + "\n")
    w("| Test | Ergebnis | Dauer (s) |\n|---|---|---|")
    for n, st, d, msg in res.rows: w(f"| {n} | {st} | {d} |")
    errs = [r for r in res.rows if r[1] != "bestanden"]
    w("\n## Aufgetretene Fehler\n")
    if errs:
        for n, st, d, msg in errs: w(f"**{n}** ({st})\n```\n{msg}\n```")
    else: w("Im finalen Lauf keine. (Während der Entwicklung gefundene und behobene Fehler: siehe README, Abschnitt Änderungen/Bugfixes.)")
    w("\n## Beispielhafte Backtesting-Ergebnisse (SYNTHETISCHE Daten!)\n")
    w("Zufallsdaten mit eingebauten Marktphasen. Bei so wenigen Trades sind Sharpe/Profit Factor statistisch wertlos (Zahlen wie Sharpe 5 sind Zufall). **Das sagt nichts über Profitabilität an echten Märkten.** Es belegt nur, dass die Pipeline funktioniert.\n")
    for name, m, reg, secs in ex:
        w(f"**{name}** ({secs}s): Netto {fmt(m['net_return'],2,True)}, Profit Factor {fmt(m['profit_factor'])}, Sharpe {fmt(m['sharpe'])}, Sortino {fmt(m['sortino'])}, Max-Drawdown {fmt(m['max_drawdown'],1,True)}, Trades {m['trades']}, Gebühren {fmt(m['fees'])}, Slippage {fmt(m['slippage'])}, Funding {fmt(m['funding'])}, Liquidationen {m['liquidations']}\n")
        w("| Marktphase | Trades | Netto (USDT) | Profit Factor |\n|---|---|---|---|")
        for k, v in reg.items(): w(f"| {k} | {v['trades']} | {v['net_pnl']:.2f} | {fmt(v['profit_factor'])} |")
    mo = wf["metrics"]
    w(f"\n**Walk-forward (Out-of-sample, {wf['n_folds']} Folds, 4 Versuche je Fold):** Netto {fmt(mo['net_return'],2,True)}, PF {fmt(mo['profit_factor'])}, Sharpe {fmt(mo['sharpe'])}, MaxDD {fmt(mo['max_drawdown'],1,True)}, Trades {mo['trades']}. Robust: **{wf['robust']}** (Prüfungen: {wf['checks']})\n")
    w("| Fold | Training | Test | Train-Score | Basis-Score | OOS Netto | OOS Trades |\n|---|---|---|---|---|---|---|")
    for f in wf["folds"]: w(f"| {f['fold']} | {f['train']} | {f['test']} | {f['train_score']:.2f} | {f['baseline_score']:.2f} | {fmt(f['oos']['net_return'],2,True)} | {f['oos']['trades']} |")
    w(f"\n**Hebel-Studie (feste Stufen, Out-of-sample, Parameter fix):** gewählt **{lv['selected']}x** (höchste Rendite hatte {lv['highest_return_level']}x). {lv['note']}\n")
    w("| Hebel | Netto | PF | Sharpe | Sortino | MaxDD | Trades | Liq. | Gebühren | Funding | Margin-Anteil | unsicher abgelehnt | Score |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for r in lv["rows"]:
        m = r["metrics"]; w(f"| {r['level']}x | {fmt(m['net_return'],2,True)} | {fmt(m['profit_factor'])} | {fmt(m['sharpe'])} | {fmt(m['sortino'])} | {fmt(m['max_drawdown'],1,True)} | {m['trades']} | {m['liquidations']} | {fmt(m['fees'])} | {fmt(m['funding'])} | {fmt(m['avg_margin_share'],1,True)} | {r['rejected_unsafe']} | {r['score']:.2f} |")
    w("""
## Vollständig implementiert UND getestet
Execution Simulator (Gebühren, Slippage, Spread, Funding, Gaps, Stop-Loss, Take-Profit, Trailing, Isolated Margin, Maintenance-Margin-Stufen, Liquidation) · Risk Engine (1 %-Risiko je Trade, Tages-/Wochen-/Gesamtlimits, Notfallabschaltung, Exposure, Portfoliorisiko, Cooldown) · adaptiver Hebel-Manager bis 20x mit Stufen-Gates · Signal Aggregator mit Konsens, Konflikterkennung, Korrelationsabzug · Meta-Learner (Shrinkage, Konfidenzgrenzen, Halbwertszeit, Deaktivierung, Bewährung) · Marktphasen-Erkennung · Regel-Agenten (10) · Schatten-Konten · KI-Tod bei Geld = 0 · Backtesting (reproduzierbar, ohne Look-ahead) · Walk-forward · Hebel-Studie · eingebauter Optimierer · Champion/Challenger inkl. Rollback · SQLite-Persistenz und Neustart (identisches Ergebnis) · Schutz vor doppelten Orders · Dashboard-Daten, Login, Seite · Demo-Modus.

## Implementiert, aber NICHT automatisch getestet (kein Netzwerk in der Testumgebung)
- Echte Binance-Kursabfrage, Historien-Download, Funding-Historie (Code mit Timeout/Retry/Validierung vorhanden; Validierung getestet, API selbst nicht).
- KI-Agenten (LLM) über die Claude-API (`--llm`): Parsing/Fehlerbehandlung vorhanden, echte Aufrufe ungetestet.
- Optuna-Backend (optional, nicht installiert getestet; Fallback-Suche ist getestet).
- Dauerbetrieb (24/7), Hintergrundoptimierung auf echten Daten, Browser-Darstellung des Dashboards (nur Daten und HTTP getestet, nicht visuell).

## Offene Punkte
- Die Meta-Learner-Gewichte lernen nur aus Schatten-Konten; LLM-Agenten brauchen daher Wochen, bis sie Gewicht bekommen.
- Funding im Backtest ist ohne echte Historie eine konstante, konservative Schätzung.
- Optimierung läuft standardmäßig ohne Schatten-Konten (schneller); die Walk-forward-Auswertung nutzt die volle Pipeline.

## Bekannte Einschränkungen
- Nur Simulation: Spread, Slippage und Liquidität sind Modelle; echte Märkte (Orderbuch, Ausfälle, Liquidationsmotor der Börse) können schlechter sein.
- Kerzen-Auflösung 15 Minuten: Reihenfolge von Stop und Ziel innerhalb einer Kerze ist unbekannt (es wird pessimistisch Stop zuerst angenommen).
- **Es gibt keinen Beleg für Profitabilität.** Alle Beispiel-Ergebnisse stammen aus Zufallsdaten.
""")
    open(os.path.join(ROOT, "TESTREPORT.md"), "w", encoding="utf-8").write("\n".join(L))
    print("TESTREPORT.md geschrieben")
    sys.exit(0 if bad == 0 else 1)

if __name__ == "__main__":
    main()
