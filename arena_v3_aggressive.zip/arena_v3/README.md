# KI-Trading-Arena V3 (nur Paper Trading / Spielgeld)

Kooperatives, selbstlernendes Multi-Agent-Trading-System mit Risiko-Engine, adaptivem Hebel-Manager (max. 125x, aggressives Profil),
Backtesting, Walk-forward-Validierung, Optimierer, Champion/Challenger und Dashboard.

**Es gibt keinen Live-Trading-Code. Es werden keine echten Orders gesendet. Es gibt keine Garantie auf Gewinne.**
Alle Beispielergebnisse stammen aus Zufallsdaten und belegen keine Profitabilität.

## Installation
```
python3 -m venv venv && source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt                          # Pflicht: requests. Optional: anthropic (KI-Agenten), optuna
```
Python 3.9 oder neuer (3.10+ empfohlen).

## Start
| Befehl | Zweck |
|---|---|
| `python start_v3.py demo` | Demo mit synthetischen Kursen (kostenlos, zeigt alle Funktionen) |
| `python start_v3.py live` | Paper Trading mit echten Binance-Kursen (öffentliche Daten, kein Key) |
| `python start_v3.py live --llm --cheap` | zusätzlich 3 KI-Agenten (Claude Haiku, kostet API-Guthaben, `ANTHROPIC_API_KEY` nötig) |
| `python start_v3.py backtest --synthetic` oder `--days 60` | Backtest |
| `python start_v3.py walkforward --days 90 --trials 20` | Walk-forward (Training/Test getrennt) |
| `python start_v3.py levstudy --days 90` | Hebel-Studie 1/2/5/10/20/35/50/75/100/125x |
| `python start_v3.py optimize` | einmal optimieren, ggf. Challenger anlegen |
| `python start_v3.py test` | alle Tests + `TESTREPORT.md` |
Dashboard: `http://localhost:8000`. Von außen: `--host 0.0.0.0` und `DASHBOARD_PASSWORD="..."` (Benutzer `arena`).
Neustart-fest: Stand liegt in `arena_v3.db` (SQLite). Neu anfangen: `--reset`.

## Konfiguration
`config.example.json` kopieren, anpassen und mit `--config config.json` laden. Jeder Parameter ist in `arena_v3/config.py` dokumentiert.
**Hard Limits (aggressives Profil, nur Paper!)** - im Code fest, per Konfiguration/Optimierer/Agent NICHT änderbar:
Hebel 125x, Risiko 5 % je Trade, Tagesverlust 15 %, Wochenverlust 30 %, Gesamt-Drawdown 50 % (Notfallabschaltung),
Exposure 40x, Portfoliorisiko 15 %, max. 50 Positionen (pro Coin höchstens eine, real begrenzt durch die Anzahl der Coins und das Portfoliorisiko), Stop-Loss liegt immer vor der Liquidation (Sicherheitsfaktor 1,2).
Das frühere konservative Profil (20x, 1 %, 3 %, 6 %, 10 %) steht als `SAFE_LIMITS` in `config.py` zum Vergleich.
**Märkte:** 50 USDT-Paare (u. a. BTC, ETH, SOL, XRP, BNB, ADA, DOGE, AVAX, LINK, DOT, LTC, TRX, ATOM, NEAR, UNI, AAVE, SUI, APT, ARB, OP, INJ, TON, PEPE; vollständige Liste: `DEFAULT_SYMBOLS` in `config.py`).
Eigene Liste: `--symbols BTCUSDT,ETHUSDT,...` oder `symbols` in der Config (BTCUSDT ist Referenzmarkt). Nicht abrufbare Paare (z. B. delistet) werden beim Start übersprungen. Neuere Coins haben kürzere Historie; Daten werden auf den gemeinsamen Zeitraum gekürzt.

## Wie der Hebel entschieden wird (wichtig)
Die Positionsgröße kommt aus dem erlaubten Verlust bei Stop-Loss (inkl. Gebühren, Spread, Slippage, Funding) - nicht aus dem Hebel.
Der Hebel folgt einer Stufenleiter 2 / 5 / 10 / 20 / 35 / 50 / 75 / 100 / 125x. Die Stufen-Obergrenze hängt ab von Signalqualität,
Zuverlässigkeit, Volatilität, Marktphase, Liquidität, Kosten, Auslastung, Korrelation, Drawdown und Verlustserie; 75-125x nur mit
`experimental_high_leverage` und sehr strengen Prüfungen. Standard ist `lev_policy: "tier_pref"` (Hebel passend zur Stufe);
`"min_feasible"` nimmt stattdessen den kleinsten Hebel, der die Position finanziert. Zusätzlich begrenzt der Liquidations-Sicherheitsabstand
den Hebel: je weiter der Stop und je höher die Volatilität, desto niedriger der maximal mögliche Hebel (hohe Hebel gehen nur bei engem Stop).
`lev_rel_floor` (Standard 0.5) setzt eine Mindest-Zuverlässigkeit für die Hebelstufe; mit 0 wird streng statistisch entschieden
(ohne Schatten-Konten, z. B. im Backtest, bleibt der Hebel dann bei max. 5x).
**Achtung:** Diese Einstellungen sind für Spielgeld gedacht. Mit echtem Geld wären 5 % Risiko je Trade und 50 % Drawdown-Limit extrem gefährlich.

## KI stirbt bei Geld = 0
Jeder Agent hat ein eigenes Schatten-Konto. Fällt dessen Equity auf 0 (praktisch: unter 0,08 USDT, `death_equity`), stirbt der Agent
dauerhaft: Positionen werden geschlossen, er gibt keine Signale mehr ab, hat kein Stimmrecht im Team, das Ereignis `KI_GESTORBEN`
wird gespeichert und bleibt auch nach Neustart bestehen (Wiederbelebung nur mit `--reset`). Das gilt auch für das Team-Konto
(`TEAM_GESTORBEN`). Hinweis: Wegen der 1 %-Regel und der Limits dauert es bei schlechten Agenten lange, bis das Konto 0 erreicht.
Wer es früher will, setzt `death_equity` höher (z. B. 500 = Tod bei -50 %).

## Änderungen/Bugfixes während der Entwicklung
Sharpe-Berechnung (Startwert fehlte), Aggregator-Qualitätsfaktor (schlechte Agenten dürfen das Team nicht antreiben), Funding-Vorzeichen,
Gap-Ausführung, mehrere Testannahmen. Details: Git-freie Historie siehe TESTREPORT.md.
