# Testbericht KI-Trading-Arena V4

Erstellt: 2026-11-12 06:33  |  Python 3.12.3  |  Alle Tests laufen offline (synthetische Daten).

## Ergebnis: **149 von 149 Tests bestanden**

| Test | Ergebnis | Dauer (s) |
|---|---|---|
| test_v3.S_Hebel_und_Risiko.test_S_hebelgrenze_technisch_erzwungen | bestanden | 0.0 |
| test_v3.S_Hebel_und_Risiko.test_S_hohe_confidence_allein_loest_keinen_hohen_hebel_aus | bestanden | 0.0 |
| test_v3.S_Hebel_und_Risiko.test_S_kein_martingale_risiko_sinkt_nach_verlustserie | bestanden | 0.0 |
| test_v3.S_Hebel_und_Risiko.test_S_keine_hebelerhoehung_nach_verlusten_und_drawdown | bestanden | 0.0 |
| test_v3.S_Hebel_und_Risiko.test_S_keine_umgehung_der_grenzen_durch_agenten_optimierer_konfiguration | bestanden | 1.24 |
| test_v3.S_Hebel_und_Risiko.test_S_portfolio_exposure_und_gesamtrisiko_begrenzt | bestanden | 2.84 |
| test_v3.S_Hebel_und_Risiko.test_S_positionsgroesse_aus_risiko_nicht_aus_hebel | bestanden | 0.0 |
| test_v3.S_Hebel_und_Risiko.test_S_stop_loss_immer_vor_liquidation_mit_sicherheitsabstand | bestanden | 0.0 |
| test_v3.S_Hebel_und_Risiko.test_S_tages_wochen_gesamt_limits | bestanden | 0.0 |
| test_v3.S_Hebel_und_Risiko.test_S_zu_riskante_trades_werden_abgelehnt | bestanden | 0.0 |
| test_v3.T01_Syntax_Import.test_S_nur_paper_trading_keine_echten_orders | bestanden | 0.0 |
| test_v3.T01_Syntax_Import.test_T01_syntax_aller_python_dateien | bestanden | 0.11 |
| test_v3.T01_Syntax_Import.test_T02_importpruefung | bestanden | 0.0 |
| test_v3.T03_Demo_und_Zyklen.test_T03_demo_modus_und_dashboarddaten | bestanden | 0.64 |
| test_v3.T03_Demo_und_Zyklen.test_T04_ein_vollstaendiger_zyklus | bestanden | 0.19 |
| test_v3.T03_Demo_und_Zyklen.test_T05_mehrere_aufeinanderfolgende_zyklen | bestanden | 2.92 |
| test_v3.T06_Kooperation.test_T06_agenten_kooperation_gemeinsame_entscheidung | bestanden | 0.0 |
| test_v3.T06_Kooperation.test_T06b_ein_einzelner_agent_loest_keinen_trade_aus | bestanden | 0.0 |
| test_v3.T06_Kooperation.test_T06c_zufalls_baseline_zaehlt_nicht_zum_team | bestanden | 0.0 |
| test_v3.T06_Kooperation.test_T07_widerspruechliche_signale | bestanden | 0.0 |
| test_v3.T06_Kooperation.test_T07b_gegensignal_schliesst_position | bestanden | 0.86 |
| test_v3.T08_Gewichtung.test_T08_gute_agenten_mehr_gewicht_schlechte_weniger | bestanden | 0.0 |
| test_v3.T08_Gewichtung.test_T08b_kurzfristiges_glueck_wird_nicht_belohnt | bestanden | 0.0 |
| test_v3.T08_Gewichtung.test_T08c_statistisch_schlechter_agent_wird_deaktiviert_und_bewaehrung | bestanden | 0.0 |
| test_v3.T08_Gewichtung.test_T08d_gewichte_bleiben_begrenzt | bestanden | 0.02 |
| test_v3.T09_Kosten.test_T09_gebuehrenberechnung | bestanden | 0.0 |
| test_v3.T09_Kosten.test_T10_funding_konstant_konservativ_beide_seiten_zahlen | bestanden | 0.0 |
| test_v3.T09_Kosten.test_T10b_funding_echte_raten_mit_vorzeichen_und_genau_ein_intervall | bestanden | 0.0 |
| test_v3.T11_Stops_Liquidation.test_S_maintenance_margin_stufen | bestanden | 0.0 |
| test_v3.T11_Stops_Liquidation.test_T11_stop_loss_ausfuehrung_mit_slippage | bestanden | 0.0 |
| test_v3.T11_Stops_Liquidation.test_T11b_kurzluecke_wird_zum_schlechteren_eroeffnungskurs_ausgefuehrt | bestanden | 0.0 |
| test_v3.T11_Stops_Liquidation.test_T11c_stop_slippage_groesser_als_normale_slippage | bestanden | 0.0 |
| test_v3.T11_Stops_Liquidation.test_T12_liquidationspreis_formel_und_buchung | bestanden | 0.0 |
| test_v3.T13_DB.test_T13_datenbankpersistenz | bestanden | 1.64 |
| test_v3.T13_DB.test_T13b_datei_datenbank_ueberlebt_neuoeffnen | bestanden | 0.01 |
| test_v3.T14_Neustart.test_T14_neustart_gleiches_ergebnis_wie_durchlauf | bestanden | 4.8 |
| test_v3.T14_Neustart.test_T14b_schutz_vor_doppelten_trades | bestanden | 0.41 |
| test_v3.T15_Backtest.test_T15_backtest_reproduzierbar_mit_kosten | bestanden | 7.87 |
| test_v3.T15_Backtest.test_T15b_kein_lookahead_signale_unabhaengig_von_zukunftsdaten | bestanden | 0.15 |
| test_v3.T15_Backtest.test_T15c_ergebnis_unabhaengig_von_daten_nach_dem_testende | bestanden | 3.61 |
| test_v3.T16_WalkForward.test_T16_walk_forward_fenster_ohne_ueberlappung_und_oos_auswertung | bestanden | 24.34 |
| test_v3.T16_WalkForward.test_T16b_optimierung_nutzt_nur_erlaubten_parameterraum | bestanden | 0.0 |
| test_v3.T17_ChampionChallenger.test_T17_challenger_nur_nach_robustem_walk_forward | bestanden | 0.0 |
| test_v3.T17_ChampionChallenger.test_T17b_befoerderung_nur_bei_allen_kriterien | bestanden | 0.0 |
| test_v3.T17_ChampionChallenger.test_T17c_automatischer_rollback | bestanden | 0.0 |
| test_v3.T18_Notfall.test_T18_notfallabschaltung_gesamt_drawdown | bestanden | 0.0 |
| test_v3.T18_Notfall.test_T18b_system_schliesst_positionen_bei_notfall | bestanden | 0.33 |
| test_v3.T19_Tod.test_T19_ki_stirbt_wenn_geld_bei_null_ist_dauerhaft | bestanden | 1.52 |
| test_v3.T19_Tod.test_T19b_team_konto_tod | bestanden | 0.42 |
| test_v3.T20_Dashboard.test_T20_http_state_login_und_seite | bestanden | 1.0 |
| test_v3.T21_Universum_und_Aggressives_Profil.test_T21_standarduniversum_50_paare_gueltig | bestanden | 0.0 |
| test_v3.T21_Universum_und_Aggressives_Profil.test_T21b_universum_laeuft_durch_50_paare | bestanden | 1.93 |
| test_v3.T21_Universum_und_Aggressives_Profil.test_T21c_hohe_hebel_werden_tatsaechlich_genehmigt | bestanden | 0.0 |
| test_v3.T21_Universum_und_Aggressives_Profil.test_T21d_profile_und_alte_grenzen_als_referenz | bestanden | 0.0 |
| test_v3.T21_Universum_und_Aggressives_Profil.test_T21e_binance_available_filtert_ungueltige_symbole | bestanden | 0.0 |
| test_v3.T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22_ohne_login_umleitung_und_401 | bestanden | 0.0 |
| test_v3.T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22b_cookie_90_tage_httponly_und_funktioniert | bestanden | 0.01 |
| test_v3.T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22c_cookie_ueberlebt_neustart_manipulation_und_ablauf_werden_abgelehnt | bestanden | 0.0 |
| test_v3.T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22d_falsches_passwort_und_basic_auth_fuer_skripte | bestanden | 0.01 |
| test_v3.T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22e_logout_loescht_cookie | bestanden | 0.0 |
| test_v3.T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22f_agenten_haben_verlauf_signale_positionen_trades | bestanden | 0.01 |
| test_v3.T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22g_websocket_zustand_ohne_trades_und_mit_cookie | bestanden | 0.01 |
| test_v3.T22_Login_Cookie_und_Agenten_im_Dashboard.test_T22h_sperre_nach_fuenf_fehlversuchen | bestanden | 0.51 |
| test_v3.T23_Datenluecken_und_Pruefung.test_T23_align_fuellt_luecken_statt_alle_paare_zu_kuerzen | bestanden | 0.0 |
| test_v3.T23_Datenluecken_und_Pruefung.test_T23b_align_beginnt_wenn_alle_paare_daten_haben | bestanden | 0.0 |
| test_v3.T23_Datenluecken_und_Pruefung.test_T23c_live_tick_mit_50_paaren_und_luecken_laeuft | bestanden | 0.44 |
| test_v3.T23_Datenluecken_und_Pruefung.test_T23d_einzelner_abruffehler_stoppt_nicht_alles | bestanden | 2.07 |
| test_v3.T23_Datenluecken_und_Pruefung.test_T23e_diagnose_nennt_das_paar_mit_zu_kurzer_historie | bestanden | 0.02 |
| test_v3.T23_Datenluecken_und_Pruefung.test_T23f_vorab_pruefung_filtert_ungueltig_kurz_und_luecken | bestanden | 0.01 |
| test_v3.T23_Datenluecken_und_Pruefung.test_T23g_netzwerkproblem_verwirft_keine_paare | bestanden | 0.0 |
| test_v3.T23_Datenluecken_und_Pruefung.test_T23h_ungueltiges_symbol_wird_nicht_wiederholt | bestanden | 0.0 |
| test_v3.T23_Datenluecken_und_Pruefung.test_T23i_gesperrter_host_faellt_auf_naechsten_host_zurueck | bestanden | 0.0 |
| test_v3.T24_Struktur_und_MTF.test_T24_mtf_und_struktur_sind_kausal | bestanden | 0.16 |
| test_v3.T24_Struktur_und_MTF.test_T24b_mtf_aufwaertstrend_und_unbekannt_bei_wenig_daten | bestanden | 0.0 |
| test_v3.T24_Struktur_und_MTF.test_T24c_mtf_nutzt_keine_unvollstaendige_hoehere_kerze | bestanden | 0.01 |
| test_v3.T24_Struktur_und_MTF.test_T24d_struktur_bos_choch_sweep_fvg_und_gleiche_hochs | bestanden | 0.0 |
| test_v3.T25_Neue_Agenten.test_T25_orderbuch_agent | bestanden | 0.01 |
| test_v3.T25_Neue_Agenten.test_T25b_derivate_agent | bestanden | 0.01 |
| test_v3.T25_Neue_Agenten.test_T25c_marktstruktur_agent | bestanden | 0.01 |
| test_v3.T25_Neue_Agenten.test_T25d_multi_timeframe_agent | bestanden | 0.0 |
| test_v3.T25_Neue_Agenten.test_T25e_liquidations_agent | bestanden | 0.01 |
| test_v3.T25_Neue_Agenten.test_T25f_zusatzdaten_buch_zusammenfassung | bestanden | 0.0 |
| test_v3.T26_Integration_der_neuen_Agenten.test_T26_team_hat_15_agenten_neue_starten_auf_bewaehrung | bestanden | 0.0 |
| test_v3.T26_Integration_der_neuen_Agenten.test_T26b_backtest_laeuft_und_agenten_ohne_daten_bleiben_neutral | bestanden | 3.74 |
| test_v3.T26_Integration_der_neuen_Agenten.test_T26c_alter_speicherstand_ohne_neue_agenten_laedt | bestanden | 0.72 |
| test_v3.T26_Integration_der_neuen_Agenten.test_T26d_live_tick_mit_zusatzdaten_und_ausfaellen | bestanden | 0.09 |
| test_v3.T26_Integration_der_neuen_Agenten.test_T26e_extras_werden_nur_einmal_je_kerze_geholt | bestanden | 0.0 |
| test_v3.T26_Integration_der_neuen_Agenten.test_T26f_demo_laeuft_mit_allen_15_agenten | bestanden | 2.58 |
| test_v3.T26_Integration_der_neuen_Agenten.test_T26g_scalper_meidet_ruhige_maerkte | bestanden | 0.0 |
| test_v4.V4_Ausfuehrung.test_gebuehren_beidseitig_und_kosten_in_geschlossenen_trades | bestanden | 1.73 |
| test_v4.V4_Ausfuehrung.test_order_wird_erst_zur_naechsten_kerze_ausgefuehrt | bestanden | 0.68 |
| test_v4.V4_Auto_Hebel.test_api_und_dashboard_zeigen_hebel | bestanden | 0.27 |
| test_v4.V4_Auto_Hebel.test_hebel_im_system_nie_ueber_agenten_obergrenze_und_profil | bestanden | 3.23 |
| test_v4.V4_Auto_Hebel.test_hebel_waechst_nur_mit_belegter_leistung_und_bleibt_im_profil | bestanden | 0.0 |
| test_v4.V4_Auto_Hebel.test_manuell_einstellbar_aber_durch_profil_begrenzt | bestanden | 0.0 |
| test_v4.V4_Bandit.test_bandit_ist_shadow_und_aendert_team_entscheidungen_nicht | bestanden | 2.63 |
| test_v4.V4_Bandit.test_cooldown_nach_verlustserie_und_persistenz | bestanden | 0.0 |
| test_v4.V4_Bandit.test_delayed_reward_geht_an_den_eroeffnungskontext | bestanden | 0.0 |
| test_v4.V4_Bandit.test_deterministisches_replay | bestanden | 0.0 |
| test_v4.V4_Bandit.test_mindeststichprobe_und_gewichtskappen | bestanden | 0.0 |
| test_v4.V4_Drift_Rollback.test_challenger_wird_deaktiviert_champion_bleibt_intakt | bestanden | 0.0 |
| test_v4.V4_Drift_Rollback.test_drift_loest_nur_derating_pause_rollback_aus | bestanden | 0.0 |
| test_v4.V4_Drift_Rollback.test_psi_erkennt_verschobene_verteilung | bestanden | 0.0 |
| test_v4.V4_Metriken.test_block_bootstrap_deterministisch | bestanden | 0.01 |
| test_v4.V4_Metriken.test_brier_logloss_ece | bestanden | 0.0 |
| test_v4.V4_Nutzersteuerung.test_ablation_hochgewichtet_nichts_automatisch | bestanden | 0.0 |
| test_v4.V4_Nutzersteuerung.test_ablation_laeuft_deterministisch | bestanden | 4.44 |
| test_v4.V4_Nutzersteuerung.test_aktivitaet_lockert_nur_signalfilter_monoton | bestanden | 0.0 |
| test_v4.V4_Nutzersteuerung.test_ausgeschalteter_agent_hat_kein_stimmrecht_aber_schattenkonto_laeuft | bestanden | 2.96 |
| test_v4.V4_Nutzersteuerung.test_hoehere_aktivitaet_gibt_mehr_team_freigaben | bestanden | 4.16 |
| test_v4.V4_Nutzersteuerung.test_niedriges_stimmrecht_loest_keine_qualitaetssperre_aus | bestanden | 0.0 |
| test_v4.V4_Nutzersteuerung.test_stimmrecht_skaliert_gewicht_und_entscheidung | bestanden | 0.0 |
| test_v4.V4_Nutzersteuerung.test_werte_werden_begrenzt_und_validiert | bestanden | 0.0 |
| test_v4.V4_Optimierer_Paritaet.test_deflated_sharpe_sinkt_mit_der_zahl_der_varianten | bestanden | 0.0 |
| test_v4.V4_Optimierer_Paritaet.test_objective_reicht_shadow_wie_walkforward_durch | bestanden | 0.57 |
| test_v4.V4_Optimierer_Paritaet.test_oos_status_inconclusive_bei_wenigen_trades | bestanden | 1.44 |
| test_v4.V4_Optimierer_Paritaet.test_screening_und_inconclusive_duerfen_nicht_befoerdern | bestanden | 0.0 |
| test_v4.V4_Optimierer_Paritaet.test_standard_optimierung_nutzt_volle_produktionslogik | bestanden | 0.0 |
| test_v4.V4_Persistenz_und_Dashboard.test_aus_schalten_setzt_anteil_im_dashboard_auf_null | bestanden | 0.33 |
| test_v4.V4_Persistenz_und_Dashboard.test_dashboard_zeigt_paper_status_nutzersteuerung_und_ablehnungsgruende | bestanden | 0.36 |
| test_v4.V4_Persistenz_und_Dashboard.test_gate_monitor_blockiert_beforderung | bestanden | 0.24 |
| test_v4.V4_Persistenz_und_Dashboard.test_http_endpunkte_validieren_und_begrenzen | bestanden | 0.81 |
| test_v4.V4_Persistenz_und_Dashboard.test_live_kurse_werden_geholt_und_im_dashboard_ausgewiesen | bestanden | 0.41 |
| test_v4.V4_Persistenz_und_Dashboard.test_nutzersteuerung_ueberlebt_neustart | bestanden | 0.32 |
| test_v4.V4_Persistenz_und_Dashboard.test_push_intervall_ist_konfigurierbar_und_schnell | bestanden | 0.0 |
| test_v4.V4_Persistenz_und_Dashboard.test_systemzustand_roundtrip_mit_controls_meta_und_gate | bestanden | 1.26 |
| test_v4.V4_Portfolio.test_deaktivierter_guardian_laesst_alles_durch | bestanden | 0.0 |
| test_v4.V4_Portfolio.test_hochkorrelierte_positionen_zaehlen_als_gemeinsames_risiko | bestanden | 0.01 |
| test_v4.V4_Portfolio.test_skala_nur_verkleinerung | bestanden | 0.01 |
| test_v4.V4_Purging_und_Leakage.test_evolution_agent_ohne_v4_metriken_bleibt_neutral | bestanden | 0.0 |
| test_v4.V4_Purging_und_Leakage.test_evolution_agent_training_ohne_ueberlappung_und_mit_metriken | bestanden | 0.13 |
| test_v4.V4_Purging_und_Leakage.test_purged_split_kein_label_reicht_in_validierung | bestanden | 0.0 |
| test_v4.V4_Purging_und_Leakage.test_purged_split_mit_luecken_im_index | bestanden | 0.0 |
| test_v4.V4_Purging_und_Leakage.test_zukunftsdaten_veraendern_vergangene_signale_nicht | bestanden | 0.06 |
| test_v4.V4_Regime.test_hysterese_verhindert_flattern | bestanden | 0.0 |
| test_v4.V4_Regime.test_stress_wirkt_sofort | bestanden | 0.0 |
| test_v4.V4_Regime.test_unknown_bei_zu_wenig_historie | bestanden | 0.0 |
| test_v4.V4_Regime.test_wahrscheinlichkeiten_summieren_sich_auf_eins | bestanden | 0.0 |
| test_v4.V4_Risiko_Invarianten.test_parameter_optimierer_und_nutzer_koennen_limits_nicht_lockern | bestanden | 0.0 |
| test_v4.V4_Risiko_Invarianten.test_risikoprofil_nicht_per_konfigdatei_lockerbar | bestanden | 0.0 |
| test_v4.V4_Risiko_Invarianten.test_standard_ist_safe_paper | bestanden | 0.0 |
| test_v4.V4_Risiko_Invarianten.test_system_hebel_und_positionen_bleiben_im_safe_profil | bestanden | 1.46 |
| test_v4.V4_Risiko_Invarianten.test_unbekanntes_profil_faellt_auf_safe_und_alles_ist_durch_hard_begrenzt | bestanden | 0.0 |
| test_v4.V4_Trade_Quality.test_aktivitaet_und_nutzersteuerung_aendern_das_gate_nicht | bestanden | 0.0 |
| test_v4.V4_Trade_Quality.test_fehlende_kosten_oder_liquiditaetsdaten_werden_abgelehnt | bestanden | 0.0 |
| test_v4.V4_Trade_Quality.test_gate_lehnt_im_system_ab_und_strict_blockiert | bestanden | 3.31 |
| test_v4.V4_Trade_Quality.test_negative_konservative_edge_wird_abgelehnt | bestanden | 0.0 |
| test_v4.V4_Trade_Quality.test_positive_edge_wird_freigegeben_und_kosten_sind_aufgeschluesselt | bestanden | 0.0 |
| test_v4.V4_Trade_Quality.test_unsicherheit_senkt_die_edge | bestanden | 0.0 |

## Aufgetretene Fehler

Im finalen Lauf keine. (Während der Entwicklung gefundene und behobene Fehler: siehe README, Abschnitt Änderungen/Bugfixes.)

## Beispielhafte Backtesting-Ergebnisse (SYNTHETISCHE Daten!)

Zufallsdaten mit eingebauten Marktphasen. Bei so wenigen Trades sind Sharpe/Profit Factor statistisch wertlos (Zahlen wie Sharpe 5 sind Zufall). **Das sagt nichts über Profitabilität an echten Märkten.** Es belegt nur, dass die Pipeline funktioniert.

**Backtest (Standardparameter, Kerzen 400-3500, seed 11)** (10.9s): Netto 0.00%, Profit Factor -, Sharpe -, Sortino -, Max-Drawdown 0.0%, Trades 0, Gebühren 0.00, Slippage 0.00, Funding 0.00, Liquidationen 0

| Marktphase | Trades | Netto (USDT) | Profit Factor |
|---|---|---|---|

**Walk-forward (Out-of-sample, 3 Folds, 4 Versuche je Fold):** Netto 0.23%, PF inf, Sharpe 4.78, MaxDD 0.3%, Trades 1. Robust: **False** (Prüfungen: {'pf': True, 'mdd': True, 'trades': False, 'folds': False, 'net_positive': True, 'regimes': False})

| Fold | Training | Test | Train-Score | Basis-Score | OOS Netto | OOS Trades |
|---|---|---|---|---|---|---|
| 0 | [320, 1520] | [1520, 2020] | -0.85 | -0.97 | 0.23% | 1 |
| 1 | [820, 2020] | [2020, 2520] | -0.24 | -1.00 | 0.00% | 0 |
| 2 | [1320, 2520] | [2520, 3020] | -0.27 | -1.00 | 0.00% | 0 |

**Hebel-Studie (feste Stufen, Out-of-sample, Parameter fix):** gewählt **1x** (höchste Rendite hatte 1x). ACHTUNG: nur 0 Trades (< 30) - keine belastbare Aussage. Gewählt wird die beste robuste, risikoadjustierte Stufe (Score aus Rendite, Profit Factor, Sharpe, Sortino, Drawdown, Liquidationen) - nicht die höchste Rendite. Keine Aussage über künftige Profitabilität.

| Hebel | Netto | PF | Sharpe | Sortino | MaxDD | Trades | Liq. | Gebühren | Funding | Margin-Anteil | unsicher abgelehnt | Score |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1x | 0.00% | - | - | - | 0.0% | 0 | 0 | 0.00 | 0.00 | - | 0 | -1.00 |
| 2x | 0.00% | - | - | - | 0.0% | 0 | 0 | 0.00 | 0.00 | - | 0 | -1.00 |
| 3x | 0.00% | - | - | - | 0.0% | 0 | 0 | 0.00 | 0.00 | - | 0 | -1.00 |
| 5x | 0.00% | - | - | - | 0.0% | 0 | 0 | 0.00 | 0.00 | - | 0 | -1.00 |
| 10x | 0.00% | - | - | - | 0.0% | 0 | 0 | 0.00 | 0.00 | - | 0 | -1.00 |
| 15x | 0.00% | - | - | - | 0.0% | 0 | 0 | 0.00 | 0.00 | - | 0 | -1.00 |
| 20x | 0.00% | - | - | - | 0.0% | 0 | 0 | 0.00 | 0.00 | - | 11 | -1.00 |

## Vollständig implementiert UND getestet
Execution Simulator (Gebühren, Slippage, Spread, Funding, Gaps, Stop-Loss, Take-Profit, Trailing, Isolated Margin, Maintenance-Margin-Stufen, Liquidation) · Risk Engine (Risiko je Trade bis 5 %, Tages-/Wochen-/Gesamtlimits, Notfallabschaltung, Exposure, Portfoliorisiko, Cooldown) · adaptiver Hebel-Manager bis 125x mit Stufen-Gates · Signal Aggregator mit Konsens, Konflikterkennung, Korrelationsabzug · Meta-Learner (Shrinkage, Konfidenzgrenzen, Halbwertszeit, Deaktivierung, Bewährung) · Marktphasen-Erkennung · Regel-Agenten (15, davon 5 neue auf Bewährung) · Schatten-Konten · KI-Tod bei Geld = 0 · Backtesting (reproduzierbar, ohne Look-ahead) · Walk-forward · Hebel-Studie · eingebauter Optimierer · Champion/Challenger inkl. Rollback · SQLite-Persistenz und Neustart (identisches Ergebnis) · Schutz vor doppelten Orders · Dashboard-Daten, Login, Seite · Demo-Modus.

## Implementiert, aber NICHT automatisch getestet (kein Netzwerk in der Testumgebung)
- Echte Binance-Kursabfrage, Historien-Download, Funding-Historie (Code mit Timeout/Retry/Validierung vorhanden; Validierung getestet, API selbst nicht).
- KI-Agenten (LLM) über die Claude-API (`--llm`): Parsing/Fehlerbehandlung vorhanden, echte Aufrufe ungetestet.
- Optuna-Backend (optional, nicht installiert getestet; Fallback-Suche ist getestet).
- Dauerbetrieb (24/7), Hintergrundoptimierung auf echten Daten, Browser-Darstellung des Dashboards (nur Daten und HTTP getestet, nicht visuell).

## Offene Punkte
- Die Meta-Learner-Gewichte lernen nur aus Schatten-Konten; LLM-Agenten brauchen daher Wochen, bis sie Gewicht bekommen.
- Funding im Backtest ist ohne echte Historie eine konstante, konservative Schätzung.
- Optimierung läuft standardmäßig ohne Schatten-Konten (schneller); die Walk-forward-Auswertung nutzt die volle Pipeline.

## Bekannte Einschränkungen
- Nur Simulation: Spread, Slippage und Liquidität sind Modelle; echte Märkte (Orderbuch, Ausfälle, Liquidationsmotor der Börse) können schlechter sein.
- Kerzen-Auflösung 15 Minuten: Reihenfolge von Stop und Ziel innerhalb einer Kerze ist unbekannt (es wird pessimistisch Stop zuerst angenommen).
- **Es gibt keinen Beleg für Profitabilität.** Alle Beispiel-Ergebnisse stammen aus Zufallsdaten.
