# Walk-forward-Bericht V4 (SYNTHETISCHE Daten)

**Daten:** SYNTHETISCH, seed 11, 3600 Kerzen, Paare ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'XRPUSDT']. Keine Aussage über echte Märkte, keine Profitabilitätsaussage.

**Profil:** SAFE (max. 20x, 1% Risiko/Trade).

## Backtests (Kerzen 400-3600)

| Lauf | Netto | PF | Max DD | Trades |
|---|---|---|---|---|
| V4 Standard (SAFE, Gate streng, Aktivität 3) | +2.54% | inf | 0.4% | 4 |
| Aktivität 5, Gate streng | +1.28% | 2.90 | 0.8% | 5 |
| Aktivität 5, Gate aus (nur Vergleich) | +0.62% | 1.02 | 5.5% | 188 |
| Kosten-Stress (Gebühr x2, Slippage x2), Aktivität 5, Gate aus | +0.12% | 1.01 | 4.4% | 69 |

## Walk-forward (Out-of-sample, volle Produktionslogik, 3 Versuche je Fold)

- OOS: Netto +0.00%, Trades 0, PF None
- Status: **inconclusive** (nur 0 OOS-Trades (< 300)); robust: False; positive Folds: 0%
- Getestete Varianten: 16 (für Multiple-Testing-Korrektur dokumentiert)
- Checks: {'pf': False, 'mdd': True, 'trades': False, 'folds': False, 'net_positive': False, 'regimes': False}

## Einordnung
Ohne belastbare Edge gilt NO TRADE. Ein negatives oder inconclusive Ergebnis ist gültig und wurde nicht wegoptimiert. Seeds, Datenbereich und Kostenannahmen stehen in der JSON-Datei.