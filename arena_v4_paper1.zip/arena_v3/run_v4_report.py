#!/usr/bin/env python3
"""Erzeugt WALKFORWARD_REPORT_V4.md/.json auf SYNTHETISCHEN Daten (ausdrücklich gekennzeichnet; keine Aussage über echte Märkte)."""
import dataclasses, json, sys, os, time, warnings
warnings.simplefilter("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from arena_v3.config import Config, limits_for
from arena_v3.data import generate_synthetic
from arena_v3.backtest import run_backtest, walk_forward
SEED = 11
base = Config(symbols=Config().symbols[:4], wf_train_bars=1200, wf_test_bars=500, wf_step_bars=500, opt_trials=3, opt_segments=2)
data = generate_synthetic(list(base.symbols), 3600, seed=SEED)
out = {"data": f"SYNTHETISCH, seed {SEED}, 3600 Kerzen, Paare {list(base.symbols)}", "profile": base.risk_profile, "limits": limits_for(base).__dict__, "runs": {}}
def rep(m): return {k: m[k] for k in ("net_return", "profit_factor", "sharpe", "max_drawdown", "trades", "fees")}
for name, c in {"V4 Standard (SAFE, Gate streng, Aktivität 3)": base,
                "Aktivität 5, Gate streng": dataclasses.replace(base, activity=5),
                "Aktivität 5, Gate aus (nur Vergleich)": dataclasses.replace(base, activity=5, gate_enabled=False, guard_enabled=False),
                "Kosten-Stress (Gebühr x2, Slippage x2), Aktivität 5, Gate aus": dataclasses.replace(base, activity=5, gate_enabled=False, guard_enabled=False, fee_taker=base.fee_taker*2, slip_base=base.slip_base*2)}.items():
    r = run_backtest(data, c, None, start=400, end=3600)
    out["runs"][name] = rep(r["metrics"])
wf = walk_forward(data, base, n_trials=3, seed=base.seed)
out["walkforward"] = {"folds": [{"fold": f["fold"], "oos": rep(f["oos"]), "seed": f.get("seed"), "n_trials": f.get("n_trials"), "screening": f.get("screening")} for f in wf["folds"]],
    "oos": rep(wf["metrics"]), "status": wf["status"], "status_reason": wf["status_reason"], "robust": wf["robust"], "checks": wf["checks"],
    "positive_folds": wf["positive_fold_fraction"], "variants_tested": wf["n_variants_tested"], "trade_stats": {k: (list(v) if isinstance(v, tuple) else v) for k, v in wf["trade_stats"].items()}}
json.dump(out, open("WALKFORWARD_REPORT_V4.json", "w"), indent=1, default=str)
L = ["# Walk-forward-Bericht V4 (SYNTHETISCHE Daten)\n", f"**Daten:** {out['data']}. Keine Aussage über echte Märkte, keine Profitabilitätsaussage.\n",
     f"**Profil:** SAFE (max. {limits_for(base).max_leverage}x, {limits_for(base).max_risk_per_trade:.0%} Risiko/Trade).\n", "## Backtests (Kerzen 400-3600)\n",
     "| Lauf | Netto | PF | Max DD | Trades |", "|---|---|---|---|---|"]
for k, m in out["runs"].items():
    pf = "–" if m["profit_factor"] is None else f"{m['profit_factor']:.2f}"
    L.append(f"| {k} | {m['net_return']:+.2%} | {pf} | {m['max_drawdown']:.1%} | {m['trades']} |")
w = out["walkforward"]
L += ["\n## Walk-forward (Out-of-sample, volle Produktionslogik, 3 Versuche je Fold)\n",
      f"- OOS: Netto {w['oos']['net_return']:+.2%}, Trades {w['oos']['trades']}, PF {w['oos']['profit_factor']}",
      f"- Status: **{w['status']}** ({w['status_reason']}); robust: {w['robust']}; positive Folds: {w['positive_folds']:.0%}",
      f"- Getestete Varianten: {w['variants_tested']} (für Multiple-Testing-Korrektur dokumentiert)", f"- Checks: {w['checks']}",
      "\n## Einordnung\nOhne belastbare Edge gilt NO TRADE. Ein negatives oder inconclusive Ergebnis ist gültig und wurde nicht wegoptimiert. "
      "Seeds, Datenbereich und Kostenannahmen stehen in der JSON-Datei."]
open("WALKFORWARD_REPORT_V4.md", "w").write("\n".join(L))
print("\n".join(L))
