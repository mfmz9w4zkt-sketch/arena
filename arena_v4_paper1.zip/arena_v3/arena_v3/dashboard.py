"""
Dashboard (nur Standardbibliothek): HTTP-Server mit JSON-Schnittstelle und einer Seite.
Login optional über DASHBOARD_PASSWORD: Anmeldeseite + langlebiges Sitzungs-Cookie (90 Tage, übersteht Neustarts),
damit das Passwort nicht ständig neu eingegeben werden muss. Basic-Auth (Benutzer: arena) geht weiterhin für Skripte.
Alles zeigt Paper-Trading-Spielgeld.
"""
from __future__ import annotations

import base64
import csv
import hmac
import io
import json
import hashlib
import struct
import math
import os
import socket
import threading
import time
from urllib.parse import parse_qs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

from .analytics import compute_metrics, by_regime
from .config import HARD, limits_for
from .regime import label


def clean(o):
    if isinstance(o, float):
        return "inf" if o == float("inf") else None if (math.isnan(o) or o == float("-inf")) else o
    if isinstance(o, dict):
        return {str(k): clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    return o


def down(curve, n=500):
    if len(curve) <= n:
        return [[t, round(e, 2)] for t, e in curve]
    step = len(curve) / n
    out = [curve[int(i * step)] for i in range(n)] + [curve[-1]]
    return [[t, round(e, 2)] for t, e in out]


def system_state(app, role, s, with_trades=True, trade_limit=5000):
    cfg = app.cfg
    prices = {sym: app.window[sym].c[-1] for sym in app.window} if app.window else {}
    lp = getattr(app, "live_prices", None) or {}
    if lp and time.time() - getattr(app, "live_prices_ts", 0) < 30:          # V4: Bewertung mit Live-Kursen statt Kerzenschluss
        for sym_ in list(prices):
            if lp.get(sym_):
                prices[sym_] = lp[sym_]
    L = limits_for(cfg)
    team = s.team
    eq = team.equity(prices) if prices else cfg.start_equity
    m = compute_metrics(s.curve, s.team_closed, cfg.start_equity, cfg.interval_sec)
    st = s.risk.state(team.name)
    lim = s.risk.limits(s.params)
    day = max(0.0, (st.day_start - eq) / st.day_start) if st.day_start else 0.0
    week = max(0.0, (st.week_start - eq) / st.week_start) if st.week_start else 0.0
    tot = max(0.0, (st.peak - eq) / st.peak) if st.peak else 0.0
    pos = []
    for sym, p in team.positions.items():
        px = prices.get(sym, p.entry)
        info = p.lev_info or {}
        liq = s.ex.liq_for(p)
        pos.append({"sym": sym, "side": p.side, "lev": p.lev, "rec_lev": info.get("recommended_lev"), "tier_cap": info.get("tier_cap"),
                    "entry": p.entry, "price": px, "sl": p.sl, "tp": p.tp, "liq": liq, "liq_dist": abs(1 - liq / px),
                    "sl_dist": abs(1 - p.sl / px), "margin": p.margin, "mm": info.get("maintenance_margin"),
                    "fees": info.get("fee_est"), "slip": info.get("slippage_est"), "funding": p.funding_paid,
                    "max_loss": info.get("max_loss_sim"), "loss_stop": info.get("loss_at_stop"), "upnl": p.unreal(px),
                    "reason": info.get("reason"), "score": info.get("score"), "factors": info.get("factors"),
                    "risk_status": st.status, "regime": p.regime})
    agents = []
    bar = (s.last_ts or 0) // s.interval_ms
    eff = {a.name: (s.learner.weight(a.name, "all", bar) * s.agg.div.get(a.name, 1.0)) if a.in_team else 0.0 for a in s.agents}
    eff_tot = sum(eff.values())
    for a in s.agents:
        acct = s.shadow.get(a.name)
        cur = s.shadow_curves.get(a.name, [])
        tr = s.shadow_closed.get(a.name, [])
        mm = compute_metrics(cur, tr, cfg.start_equity, cfg.interval_sec) if cur else None
        w = s.learner.weights.get(a.name, {})
        sg = {sym: [v.dir, round(v.conf, 2), v.reason] for sym, v in s.last_signals.get(a.name, {}).items() if v.dir}
        dis = a.name in s.learner.disabled_until
        ap = []
        if acct:
            for sym, p in acct.positions.items():
                ap.append({"sym": sym, "side": p.side, "lev": p.lev, "entry": p.entry, "upnl": p.unreal(prices.get(sym, p.entry))})
        recent = [{"sym": t.symbol, "side": t.side, "lev": t.lev, "pnl": t.net_pnl, "r": t.r_multiple, "reason": t.reason,
                   "ts": t.close_ts} for t in tr[-8:]][::-1]
        agents.append({"name": a.name, "family": a.family, "in_team": a.in_team, "style": a.style,
                       "curve": down(cur, 80), "positions": ap, "recent": recent,
                       "equity": s.shadow_equity.get(a.name, cfg.start_equity), "metrics": mm,
                       "weights": {k: round(v, 2) for k, v in w.items()}, "reliability": round(s.learner.reliability(a.name, bar), 2),
                       "stats": s.learner.agent_stats(a.name, bar), "disabled": dis,
                       "probation": a.name in s.learner.probation, "dead": s.dead.get(a.name), "llm_error": getattr(a, "last_error", ""), "signals": sg,
                       "status": s.risk.state(acct.name).status if acct else "-",
                       "user": {"enabled": s.controls.enabled(a.name), "influence": s.controls.agents.get(a.name, {}).get("influence", 1.0),
                                "lev_cap": s.controls.agents.get(a.name, {}).get("lev_cap")},
                       "lev_cap_eff": s.agent_cap(a.name, bar), "lev_max": s.risk.L.max_leverage,
                       "share": (eff[a.name] / eff_tot) if eff_tot > 0 else 0.0,
                       "learned_weight": round(s.learner.weight_perf(a.name, "all", bar), 2)})
    decisions = {sym: {"dir": d.dir, "score": round(d.score, 2), "agreement": round(d.agreement, 2), "conflict": round(d.conflict, 2),
                       "conf": round(d.conf, 2), "blocked": d.blocked, "reason": d.reason}
                 for sym, d in s.last_decisions.items()}
    reg = {sym: {"trend": r.trend, "vol": r.vol, "unusual": r.unusual, "fast": r.fast, "strength": round(r.strength, 2),
                 "vol_pct": round(r.vol_pct, 2)} for sym, r in s.last_regime.items()}
    rows = app.db.load_equity(s.name, 2000)
    ref_r = s.last_regime.get(next(iter(s.last_regime), None)) if s.last_regime else None
    from .regime import label as _lbl
    cands = s.meta.weights(f"{_lbl(ref_r).split('/ungewoehnlich')[0]}|liq_hoch", bar) if (s.meta.stats and ref_r is not None) else {}
    v4 = {"risk_profile": getattr(cfg, "risk_profile", "safe"), "paper_only": True,
          "gate": {"mode": s.controls.gate_mode, "stats": dict(s.gate_stats), "last": {k: v for k, v in list(s.last_gate.items())[-12:]}},
          "funnel": dict(s.block_stats.most_common(10)),
          "regime": s.regime_view, "meta_suggestion": {k: round(v, 2) for k, v in cands.items()},
          "controls": s.controls.to_dict()}
    return {"role": role, "v4": v4, "version": s.name, "params": s.params, "equity": eq, "metrics": m,
            "regimes_perf": by_regime(s.team_closed),
            "risk": {"status": st.status, "reason": st.reason, "day": day, "week": week, "total": tot,
                     "limits": {"daily": L.max_daily_loss, "weekly": L.max_weekly_loss, "total": L.max_total_drawdown,
                                "risk_trade": lim.risk_trade, "max_lev": lim.max_lev, "exposure": lim.exposure,
                                "port_risk": lim.port_risk, "max_open": lim.max_open},
                     "exposure_x": team.exposure(prices) / eq if eq > 0 and prices else 0,
                     "rejects": dict(s.risk.rejects), "consec_losses": team.consec_losses},
            "team_dead": s.team_dead, "n_dead": len(s.dead), "positions": pos, "agents": agents, "decisions": decisions, "regime": reg,
            "curve": [[r[0], r[1], r[2]] for r in rows][-1500:],
            "learn": s.learn_log[-8:],
            "trades": list(reversed(app.db.load_trades(system=s.name, account=team.name, limit=trade_limit))) if with_trades else []}


_CACHE = {}
_CACHE_LOCK = threading.Lock()


def build_state_cached(app, ttl=0.25):
    """Für den WebSocket: ein Zustand pro Sekunde, egal wie viele Geräte zuschauen; ohne Trades (die kommen über /api/trades)."""
    with _CACHE_LOCK:
        c = _CACHE.get(id(app))
        if c and time.time() - c[0] < ttl:
            return c[1]
        payload = json.dumps(build_state(app, with_trades=False), separators=(",", ":"))
        _CACHE[id(app)] = (time.time(), payload)
        return payload


def trades_payload(app, role, limit=3000):
    with app.lock:
        s = app.systems.get(role)
        if s is None:
            return {"role": role, "trades": []}
        rows = list(reversed(app.db.load_trades(system=s.name, account=s.team.name, limit=limit)))
    return clean({"role": role, "trades": rows})


def build_state(app, with_trades=True):
    with app.lock:
        systems = {role: system_state(app, role, s, with_trades) for role, s in app.systems.items()}
        opts = app.db.optimizations("walkforward", 3)
        lev = app.db.optimizations("leverage", 1)
        return clean({
            "meta": {"push_ms": getattr(app.cfg, "ui_push_ms", 400), "price_age": (time.time() - app.live_prices_ts) if getattr(app, "live_prices_ts", 0) else None,
                     "risk_profile": getattr(app.cfg, "risk_profile", "safe"), "contribution": app.contribution, "contribution_running": app.contribution_running,
                     "drift": app.drift_report, "demo": app.demo, "cycle": app.cycle, "now": int(time.time()), "opt_running": app.opt_running,
                     "symbols": list(app.cfg.symbols), "paper_only": True, "auth": bool(getattr(app, "dash_auth", False)), "data": getattr(app, "data_status", {}), "trading_enabled": getattr(app, "trading_enabled", True),
                     "hard": {"max_leverage": limits_for(app.cfg).max_leverage, "risk_trade": limits_for(app.cfg).max_risk_per_trade,
                              "daily": limits_for(app.cfg).max_daily_loss, "weekly": limits_for(app.cfg).max_weekly_loss, "total": limits_for(app.cfg).max_total_drawdown},
                     "last_candle": app.window[app.cfg.symbols[0]].ts[-1] if app.window else None},
            "systems": systems,
            "cc": app.cc.to_dict(), "optimizations": opts, "leverage": lev[0] if lev else None,
            "events": app.db.events(40), "log": app.log[-12:]})


_WEB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")


def _read(name):
    with open(os.path.join(_WEB, name), "r", encoding="utf-8") as fh:
        return fh.read()


SESSION_DAYS = 90


class Sessions:
    """Zustandslose, signierte Sitzungs-Cookies (HMAC mit aus dem Passwort abgeleitetem Schlüssel -> gültig auch nach Neustart)."""

    def __init__(self, password):
        self.key = hashlib.sha256(("arena-session:" + password).encode("utf-8")).digest()

    def make(self, days=SESSION_DAYS):
        exp = str(int(time.time()) + days * 86400)
        sig = hmac.new(self.key, exp.encode(), hashlib.sha256).hexdigest()
        return exp + "." + sig

    def valid(self, value):
        try:
            exp, sig = value.split(".", 1)
            good = hmac.new(self.key, exp.encode(), hashlib.sha256).hexdigest()
            return hmac.compare_digest(sig, good) and int(exp) > time.time()
        except Exception:
            return False


def make_handler(app, password):
    sessions = Sessions(password) if password else None
    fails = {}                                  # ip -> [Zeitstempel fehlgeschlagener Logins]
    app.dash_auth = bool(password)

    class H(BaseHTTPRequestHandler):
        def _send(self, code, body, ctype, extra=None):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _cookie(self, name):
            for part in self.headers.get("Cookie", "").split(";"):
                k, _, v = part.strip().partition("=")
                if k == name:
                    return v
            return ""

        def _secure(self):
            return self.headers.get("X-Forwarded-Proto", "").lower() == "https"

        def _set_cookie(self, value, max_age):
            flags = "Path=/; HttpOnly; SameSite=Lax; Max-Age=%d" % max_age + ("; Secure" if self._secure() else "")
            return {"Set-Cookie": "arena_session=%s; %s" % (value, flags)}

        def _logged_in(self):
            if not password:
                return True
            if sessions.valid(self._cookie("arena_session")):
                return True
            exp = "Basic " + base64.b64encode(("arena:" + password).encode()).decode()
            return hmac.compare_digest(self.headers.get("Authorization", ""), exp)

        def _auth(self, page=False):
            """page=True: Browser-Seite -> zur Anmeldung weiterleiten; sonst 401 (API, WebSocket)."""
            if self._logged_in():
                return True
            if page:
                self._send(303, b"", "text/plain", {"Location": "/login"})
            else:
                self._send(401, b'{"error":"login"}', "application/json")
            return False

        def _login(self):
            ip = self.client_address[0]
            now = time.time()
            recent = [t for t in fails.get(ip, []) if now - t < 60]
            fails[ip] = recent
            if len(recent) >= 5:
                return self._send(429, _read("login.html").replace("<!--MSG-->", "Zu viele Versuche. Bitte eine Minute warten.").encode(),
                                  "text/html; charset=utf-8", {"Retry-After": "60"})
            n = min(int(self.headers.get("Content-Length", "0") or 0), 4096)
            form = parse_qs(self.rfile.read(n).decode("utf-8", "ignore"))
            given = (form.get("password") or [""])[0]
            if password and hmac.compare_digest(given.encode("utf-8"), password.encode("utf-8")):
                fails.pop(ip, None)
                hdr = {"Location": "/"}
                hdr.update(self._set_cookie(sessions.make(), SESSION_DAYS * 86400))
                return self._send(303, b"", "text/plain", hdr)
            recent.append(now)
            return self._send(401, _read("login.html").replace("<!--MSG-->", "Passwort falsch.").encode(), "text/html; charset=utf-8")

        def _websocket_stream(self, app):
            """Minimal WebSocket push endpoint using only the Python standard library."""
            key = self.headers.get("Sec-WebSocket-Key")
            if not key or self.headers.get("Upgrade", "").lower() != "websocket":
                return self._send(400, b"WebSocket-Upgrade erforderlich", "text/plain")
            accept = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("ascii")).digest()).decode("ascii")
            self.send_response(101, "Switching Protocols")
            self.send_header("Upgrade", "websocket")
            self.send_header("Connection", "Upgrade")
            self.send_header("Sec-WebSocket-Accept", accept)
            self.end_headers()

            def frame(payload):
                data = payload.encode("utf-8")
                n = len(data)
                if n < 126:
                    header = bytes([0x81, n])
                elif n < 65536:
                    header = bytes([0x81, 126]) + struct.pack("!H", n)
                else:
                    header = bytes([0x81, 127]) + struct.pack("!Q", n)
                return header + data

            try:
                self.connection.settimeout(0.2)
                while True:
                    payload = build_state_cached(app)
                    self.connection.sendall(frame(payload))
                    # Check for a browser close frame without blocking the push loop.
                    try:
                        incoming = self.connection.recv(1024, getattr(__import__('socket'), 'MSG_PEEK', 2))
                        if incoming and incoming[0] == 0x88:
                            break
                    except (socket.timeout, TimeoutError, BlockingIOError):
                        pass
                    except OSError:
                        break
                    time.sleep(max(0.1, float(getattr(app.cfg, "ui_push_ms", 400)) / 1000.0))
            except (BrokenPipeError, ConnectionResetError, OSError):
                pass

        def do_GET(self):
            path = urlparse(self.path).path
            try:
                if path == "/login":
                    if self._logged_in():
                        return self._send(303, b"", "text/plain", {"Location": "/"})
                    return self._send(200, _read("login.html").replace("<!--MSG-->", "").encode(), "text/html; charset=utf-8")
                if path == "/logout":
                    hdr = {"Location": "/login"}
                    hdr.update(self._set_cookie("", 0))
                    return self._send(303, b"", "text/plain", hdr)
                if path == "/api/health":
                    return self._send(200, b'{"ok":true}', "application/json")
                if path == "/":
                    if not self._auth(page=True):
                        return
                    extra = self._set_cookie(sessions.make(), SESSION_DAYS * 86400) if password and sessions.valid(self._cookie("arena_session")) else None
                    return self._send(200, _read("index.html").encode(), "text/html; charset=utf-8", extra)
                if not self._auth():
                    return
                if path == "/ws":
                    return self._websocket_stream(app)
                if path == "/api/state":
                    return self._send(200, json.dumps(build_state(app)).encode(), "application/json")
                if path == "/api/trades":
                    q = parse_qs(urlparse(self.path).query)
                    role = (q.get("role") or ["champion"])[0]
                    lim = max(1, min(int((q.get("limit") or ["3000"])[0]), 20000))
                    return self._send(200, json.dumps(trades_payload(app, role, lim)).encode(), "application/json")
                if path == "/api/export/trades.csv":
                    buf = io.StringIO()
                    w = csv.writer(buf)
                    w.writerow(["close_ts", "system", "symbol", "side", "lev", "entry", "exit", "net_pnl", "fees", "slippage", "funding", "reason"])
                    for s in app.systems.values():
                        for t in app.db.load_trades(system=s.name, account=s.team.name):
                            w.writerow([t["close_ts"], t["system"], t["symbol"], t["side"], t["lev"], t["entry"], t["exit"],
                                        t["net_pnl"], t["fees"], t["slippage"], t["funding"], t["reason"]])
                    return self._send(200, buf.getvalue().encode("utf-8-sig"), "text/csv; charset=utf-8",
                                      {"Content-Disposition": "attachment; filename=trades.csv"})
                return self._send(404, b"nicht gefunden", "text/plain")
            except Exception as e:
                return self._send(500, str(e).encode(), "text/plain")

        def do_POST(self):
            path = urlparse(self.path).path
            if path == "/login":
                return self._login()
            if not self._auth():
                return
            try:
                if path == "/api/optimize":
                    threading.Thread(target=app.optimize_job, daemon=True).start()
                    return self._send(200, b'{"started":true}', "application/json")
                if path == "/api/leverage":
                    threading.Thread(target=app.leverage_job, daemon=True).start()
                    return self._send(200, b'{"started":true}', "application/json")
                if path in ("/api/agent", "/api/activity", "/api/gate_mode", "/api/auto_leverage"):
                    n = min(int(self.headers.get("Content-Length", "0") or 0), 4096)
                    try:
                        body = json.loads(self.rfile.read(n).decode("utf-8") or "{}")
                        if not isinstance(body, dict):
                            raise ValueError("JSON-Objekt erwartet")
                        if path == "/api/agent":
                            res = app.set_agent_control(str(body.get("agent", "")), body.get("enabled"), body.get("influence"), body.get("lev_cap", "keep"))
                        elif path == "/api/auto_leverage":
                            res = {"auto_leverage": app.set_auto_leverage(body.get("on"))}
                        elif path == "/api/activity":
                            res = {"activity": app.set_activity(body.get("level"))}
                        else:
                            res = {"gate_mode": app.set_gate_mode(body.get("mode"))}
                    except (KeyError, ValueError) as e:
                        return self._send(400, json.dumps({"error": str(e)}).encode(), "application/json")
                    return self._send(200, json.dumps({"ok": True, **res}).encode(), "application/json")
                if path == "/api/contribution":
                    threading.Thread(target=app.contribution_job, daemon=True).start()
                    return self._send(200, b'{"started":true}', "application/json")
                if path == "/api/start":
                    app.trading_enabled = True
                    app._log("Paper-Trading über Dashboard gestartet")
                    return self._send(200, b'{"started":true,"trading_enabled":true}', "application/json")
                if path == "/api/stop":
                    app.trading_enabled = False
                    app._log("Paper-Trading über Dashboard pausiert")
                    return self._send(200, b'{"stopped":true,"trading_enabled":false}', "application/json")
                return self._send(404, b"nicht gefunden", "text/plain")
            except Exception as e:
                return self._send(500, str(e).encode(), "text/plain")

        def log_message(self, *a):
            pass
    return H


def serve(app, host="127.0.0.1", port=8000, password=None):
    password = password if password is not None else os.environ.get("DASHBOARD_PASSWORD", "")
    srv = ThreadingHTTPServer((host, port), make_handler(app, password))
    srv.serve_forever()
