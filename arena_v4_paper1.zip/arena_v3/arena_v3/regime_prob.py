"""
Probabilistische Regime-Erkennung (V4) mit Unsicherheit und Hysterese. Baut auf den kausalen Regime-Merkmalen aus regime.py auf.

Zustände: trend_up, trend_down, range, high_vol, stress, unknown. Wahrscheinlichkeiten summieren sich auf 1.
  * unknown : zu wenig Historie (< MIN_HIST Kerzen) oder keine klare Mehrheit (max. Wahrscheinlichkeit < UNCERTAIN_BELOW)
  * Hysterese: Wechsel des ausgewiesenen Zustands nur, wenn der neue Zustand die aktuelle Wahrscheinlichkeit um `margin` übertrifft
    UND der aktuelle Zustand mindestens `min_duration` Kerzen gehalten wurde (Ausnahme: stress wechselt sofort).
Kein Look-ahead: nur Merkmale bis einschließlich Kerze i.
"""
from __future__ import annotations

import math

from .regime import TREND_THR

STATES = ("trend_up", "trend_down", "range", "high_vol", "stress", "unknown")
MIN_HIST = 210
UNCERTAIN_BELOW = 0.40


def _sig(x):
    return 1.0 / (1.0 + math.exp(-max(-30.0, min(30.0, x))))


def regime_probs(r, n_hist: int) -> dict:
    """r: regime.Regime (trend, vol, unusual, fast, strength, vol_pct). Rückgabe: {zustand: p} mit Summe 1."""
    if n_hist < MIN_HIST or r is None:
        return {k: (1.0 if k == "unknown" else 0.0) for k in STATES}
    up = _sig((r.strength - TREND_THR) / 0.5)
    dn = _sig((-r.strength - TREND_THR) / 0.5)
    rng = max(0.05, 1.0 - max(up, dn))
    hv = _sig((r.vol_pct - 0.8) / 0.07)
    st = 0.9 if r.unusual else 0.03
    raw = {"trend_up": up * (1 - 0.5 * hv) + 0.01, "trend_down": dn * (1 - 0.5 * hv) + 0.01, "range": rng * (1 - 0.5 * hv),
           "high_vol": hv * 0.6 + 0.01, "stress": st, "unknown": 0.01}
    tot = sum(raw.values())
    p = {k: v / tot for k, v in raw.items()}
    if max(p.values()) < UNCERTAIN_BELOW:                 # keine klare Mehrheit -> Unsicherheit ausweisen
        p["unknown"] += 0.5
        tot = sum(p.values())
        p = {k: v / tot for k, v in p.items()}
    return p


def uncertainty(p: dict) -> float:
    """Normierte Entropie 0..1 (1 = völlig unsicher)."""
    h = -sum(v * math.log(v) for v in p.values() if v > 0)
    return h / math.log(len(p))


class RegimeTracker:
    def __init__(self, min_duration: int = 8, margin: float = 0.15, smooth: float = 0.25):
        self.min_duration, self.margin, self.smooth = min_duration, margin, smooth
        self.sm = None                  # exponentiell geglättete Wahrscheinlichkeiten (Rauschen wechselt den Zustand nicht)
        self.state = "unknown"
        self.held = 0
        self.switches = 0

    def update(self, raw: dict) -> str:
        self.sm = dict(raw) if self.sm is None else {k: (1 - self.smooth) * self.sm[k] + self.smooth * raw[k] for k in raw}
        stress_now = raw["stress"] > max(v for k, v in raw.items() if k != "stress")      # Stress: ungeglättet, sofort
        p = raw if stress_now else self.sm
        best = max(p, key=p.get)
        self.held += 1
        if self.state == "unknown" and best != "unknown" and max(p.values()) >= UNCERTAIN_BELOW:
            self.state, self.held = best, 0
            return self.state
        if best == self.state:
            return self.state
        if best == "stress" and p["stress"] > p.get(self.state, 0.0):          # Stress wirkt sofort
            self.state, self.held, self.switches = best, 0, self.switches + 1
        elif self.held >= self.min_duration and p[best] > p.get(self.state, 0.0) + self.margin:
            self.state, self.held, self.switches = best, 0, self.switches + 1
        return self.state
