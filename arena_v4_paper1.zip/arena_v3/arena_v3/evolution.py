"""Bounded strategy evolution and a small pure-Python neural classifier.

The system evolves declarative rule genomes, never Python source. This avoids
runtime code execution while still allowing signal logic to change automatically.
All training labels are delayed until the full forecast horizon has elapsed.
"""
from __future__ import annotations
import math, random

FEATURES = ("roc8", "roc32", "ema_gap", "rsi", "macd", "vol_ratio")


def _sigmoid(x):
    x = max(-30.0, min(30.0, x))
    return 1.0 / (1.0 + math.exp(-x))


class TinyMLP:
    """6 -> 8 -> 1 MLP, trained with deterministic SGD and L2 regularization."""
    def __init__(self, seed=41):
        r = random.Random(seed)
        self.w1 = [[r.uniform(-0.15, 0.15) for _ in FEATURES] for _ in range(8)]
        self.b1 = [0.0] * 8
        self.w2 = [r.uniform(-0.15, 0.15) for _ in range(8)]
        self.b2 = 0.0
        self.trained = False

    def predict(self, x):
        h = [math.tanh(sum(w*v for w, v in zip(row, x)) + b) for row, b in zip(self.w1, self.b1)]
        return _sigmoid(sum(w*v for w, v in zip(self.w2, h)) + self.b2)

    def fit(self, rows, epochs=6, lr=0.025, l2=0.001):
        if len(rows) < 80:
            return False
        # Deterministic chronological SGD; no random train/test mixing.
        for _ in range(epochs):
            for x, y in rows:
                h = [math.tanh(sum(w*v for w, v in zip(row, x)) + b) for row, b in zip(self.w1, self.b1)]
                p = _sigmoid(sum(w*v for w, v in zip(self.w2, h)) + self.b2)
                d = p - y
                old_w2 = self.w2[:]
                for j in range(8):
                    self.w2[j] -= lr * (d*h[j] + l2*self.w2[j])
                    dh = d * old_w2[j] * (1-h[j]*h[j])
                    for k in range(len(FEATURES)):
                        self.w1[j][k] -= lr * (dh*x[k] + l2*self.w1[j][k])
                    self.b1[j] -= lr * dh
                self.b2 -= lr*d
        self.trained = True
        return True


class RuleEvolution:
    """Genetic search over a constrained rule DSL (feature, threshold, direction)."""
    def __init__(self, seed=73, population=12):
        self.seed, self.population = seed, population
        self.rng = random.Random(seed)
        self.genome = {"feature": 0, "threshold": 0.0, "direction": 1, "min_edge": 0.0005}
        self.generation = 0
        self.best_fitness = -1e9

    def _score(self, g, rows):
        vals = []
        for x, y in rows:
            v = x[g["feature"]]
            pred = g["direction"] if v > g["threshold"] else -g["direction"]
            if abs(v) < g["min_edge"]:
                continue
            vals.append(pred * y)
        if len(vals) < 30:
            return -1e9
        mean = sum(vals)/len(vals)
        downside = sum(min(0.0, v)**2 for v in vals)/len(vals)
        return mean - 0.5*math.sqrt(downside)

    def evolve(self, rows, generations=3):
        if len(rows) < 100:
            return False
        candidates = [dict(self.genome)]
        for _ in range(self.population-1):
            candidates.append({"feature": self.rng.randrange(len(FEATURES)),
                               "threshold": self.rng.uniform(-0.02, 0.02),
                               "direction": self.rng.choice((-1, 1)),
                               "min_edge": self.rng.uniform(0.0002, 0.004)})
        for _ in range(generations):
            ranked = sorted(((self._score(g, rows), g) for g in candidates), key=lambda z:z[0], reverse=True)
            parents = [g for _,g in ranked[:max(2, self.population//4)]]
            nxt = [dict(g) for g in parents]
            while len(nxt) < self.population:
                p = dict(self.rng.choice(parents))
                if self.rng.random() < 0.35: p["feature"] = self.rng.randrange(len(FEATURES))
                if self.rng.random() < 0.8: p["threshold"] = max(-0.05, min(0.05, p["threshold"] + self.rng.gauss(0,0.004)))
                if self.rng.random() < 0.15: p["direction"] *= -1
                if self.rng.random() < 0.5: p["min_edge"] = max(0.0001, min(0.01, p["min_edge"] + self.rng.gauss(0,0.001)))
                nxt.append(p)
            candidates = nxt
        score, genome = max(((self._score(g, rows), g) for g in candidates), key=lambda z:z[0])
        if score > self.best_fitness:
            self.genome, self.best_fitness = dict(genome), score
        self.generation += generations
        return True
