"""
Backtesting Engine, Walk-forward-Validator und Hebel-Studie.

Garantien:
  * Gleicher Code wie im Live-Paper-Betrieb (TradingSystem.step).
  * Signale nutzen nur Daten bis Kerze i; Ausführung erst zum Eröffnungskurs von Kerze i+1 (kein Look-ahead).
  * Indikatoren sind kausal. Trainings- und Testfenster überschneiden sich nicht; der Burn-in (Lernphase der Gewichte)
    liegt immer VOR dem Testfenster.
  * Gebühren, Slippage, Spread, Funding, Kurslücken und Liquidation sind eingerechnet.
  * Reproduzierbar: feste Seeds, keine Zeitabhängigkeit.
"""
from __future__ import annotations

import dataclasses
import statistics
import time

from .agents import MarketCtx
from .analytics import compute_metrics, by_regime, max_drawdown
from .config import Config, clamp_params, DEFAULT_PARAMS
from .system import TradingSystem
from . import model_validation as mv


def run_backtest(data, cfg: Config, params=None, start=None, end=None, burn_in=800, shadow=True, ctx=None,
                 keep_system=False, disable_agents=None):
    ctx = ctx or MarketCtx(data)
    n = ctx.n()
    start = max(start if start is not None else cfg.warmup_bars, 1)
    end = min(end if end is not None else n, n)
    first = max(1, start - burn_in)
    sysm = TradingSystem("bt", cfg, params, shadow=shadow, disable_agents=disable_agents)
    for i in range(first, end):
        sysm.step(ctx, i)
    ts0 = ctx.s(ctx.ref).ts[min(start, n - 1)]
    m = compute_metrics(sysm.curve, sysm.team_closed, cfg.start_equity, cfg.interval_sec, from_ts=ts0)
    trades = [t for t in sysm.team_closed if t.open_ts >= ts0]
    res = {"metrics": m, "trades": trades, "curve": [(t, e) for t, e in sysm.curve if t >= ts0],
           "regimes": by_regime(trades), "rejects": dict(sysm.risk.rejects), "params": sysm.params,
           "start": start, "end": end}
    if keep_system:
        res["system"] = sysm
    return res


def folds_for(n, cfg, train=None, test=None, step=None):
    train, test, step = train or cfg.wf_train_bars, test or cfg.wf_test_bars, step or cfg.wf_step_bars
    out, s = [], cfg.warmup_bars
    while s + train + test <= n:
        out.append((s, s + train, s + train + test))
        s += step
    return out


def chain_curves(curves, start_equity):
    """Setzt die Kurven der Testfenster hintereinander (Renditen werden verkettet)."""
    out, eq = [], start_equity
    for c in curves:
        if not c:
            continue
        base = c[0][1]
        for ts, e in c:
            out.append((ts, eq * e / base))
        eq = out[-1][1]
    return out


def evaluate_oos(results, cfg, screening=False):
    """Fasst Testfenster-Ergebnisse zusammen und prüft die Robustheitskriterien."""
    curves = [r["curve"] for r in results]
    chain = chain_curves(curves, cfg.start_equity)
    trades = [t for r in results for t in r["trades"]]
    m = compute_metrics(chain, trades, cfg.start_equity, cfg.interval_sec)
    pos = sum(1 for r in results if r["metrics"]["net_return"] > 0)
    frac = pos / len(results) if results else 0.0
    reg = by_regime(trades)
    reg_ok = sum(1 for k, v in reg.items() if v["trades"] >= 5 and v["net_pnl"] >= 0)
    checks = {
        "pf": (m["profit_factor"] or 0) >= cfg.promo_min_oos_pf,
        "mdd": m["max_drawdown"] <= cfg.promo_max_oos_mdd,
        "trades": m["trades"] >= cfg.promo_min_oos_trades,
        "folds": frac >= cfg.promo_min_pos_folds,
        "net_positive": m["net_return"] > 0,
        "regimes": reg_ok >= cfg.promo_min_regimes,
    }
    ts = mv.trade_stats(trades)
    st = mv.promotion_status(m["trades"], getattr(cfg, "v4_min_oos_trades", 300), screening=screening)
    return {"metrics": m, "positive_fold_fraction": frac, "regimes": reg, "checks": checks,
            "robust": all(checks.values()), "n_folds": len(results), "curve": chain,
            "status": st["status"], "status_reason": st["reason"], "screening": bool(screening), "trade_stats": ts}


def walk_forward(data, cfg: Config, n_trials=None, params=None, optimizer=None, seed=None, progress=None):
    """
    Walk-forward: je Fold (1) auf dem Trainingsfenster optimieren, (2) auf dem NACHFOLGENDEN, ungesehenen Testfenster prüfen,
    (3) Fenster weiterschieben. n_trials=0 -> feste Parameter (kein Training), nur Out-of-sample-Auswertung.
    """
    from .optimizer import optimize, is_screening
    ctx = MarketCtx(data)
    n = ctx.n()
    folds = folds_for(n, cfg)
    n_trials = cfg.opt_trials if n_trials is None else n_trials
    results, fold_info = [], []
    for k, (a, b, c) in enumerate(folds):
        t0 = time.time()
        if n_trials > 0:
            opt = optimize(ctx, cfg, a, b, n_trials, (seed if seed is not None else cfg.seed) + k, backend=optimizer or "auto")
            p = opt["params"]
            info = {"train_score": opt["score"], "baseline_score": opt["baseline_score"], "backend": opt["backend"],
                    "n_trials": opt["n_trials"], "seed": opt["seed"], "screening": opt["screening"]}
        else:
            p, info = clamp_params(params), {}
        r = run_backtest(data, cfg, p, start=b, end=c, burn_in=min(800, b - 1), ctx=ctx)
        results.append(r)
        fold_info.append({"fold": k, "train": [a, b], "test": [b, c], "params": p, "oos": r["metrics"],
                          "secs": round(time.time() - t0, 1), **info})
        if progress:
            progress(k + 1, len(folds), r["metrics"])
    rep = evaluate_oos(results, cfg, screening=is_screening(cfg) and n_trials > 0)
    rep["folds"] = fold_info
    rep["results"] = results
    rep["n_variants_tested"] = sum(f.get("n_trials", 0) for f in fold_info) or n_trials * len(folds)
    rep["seeds"] = {"base": seed if seed is not None else cfg.seed, "fold_seeds": [(seed if seed is not None else cfg.seed) + k for k in range(len(folds))]}
    return rep


def leverage_study(data, cfg: Config, params=None, levels=(1, 2, 5, 10, 20, 35, 50, 75, 100, 125), progress=None):
    """
    Vergleicht feste Hebelstufen auf denselben Out-of-sample-Fenstern (Parameter fix, kein Training auf den Testdaten).
    Gewählt wird NICHT die höchste Rendite, sondern der robusteste risikoadjustierte Wert.
    """
    from .optimizer import score_metrics
    ctx = MarketCtx(data)
    folds = folds_for(ctx.n(), cfg)
    rows = []
    for L in levels:
        c2 = dataclasses.replace(cfg, lev_mode="fixed", fixed_lev=int(L))
        results = []
        for (a, b, c) in folds:
            results.append(run_backtest(data, c2, params, start=b, end=c, burn_in=min(800, b - 1), ctx=ctx))
        rep = evaluate_oos(results, c2)
        m = rep["metrics"]
        rejects = sum(v for r in results for k, v in r["rejects"].items() if "Liquidationsabstand" in k)
        liq_rate = m["liquidations"] / m["trades"] if m["trades"] else 0.0
        sc = score_metrics(m, cfg, min_trades=cfg.promo_min_oos_trades) - 2.0 * liq_rate
        rows.append({"level": L, "metrics": m, "regimes": rep["regimes"], "score": sc, "liq_rate": liq_rate,
                     "rejected_unsafe": rejects, "robust": rep["robust"], "pos_folds": rep["positive_fold_fraction"]})
        if progress:
            progress(L, m)
    ok = [r for r in rows if r["metrics"]["trades"] >= cfg.promo_min_oos_trades and r["metrics"]["net_return"] > 0]
    pool = ok or rows
    best = max(pool, key=lambda r: r["score"])
    top_ret = max(rows, key=lambda r: r["metrics"]["net_return"])
    few = best["metrics"]["trades"] < cfg.promo_min_oos_trades
    warn = (f"ACHTUNG: nur {best['metrics']['trades']} Trades (< {cfg.promo_min_oos_trades}) - keine belastbare Aussage. " if few else "")
    return {"rows": rows, "selected": best["level"], "highest_return_level": top_ret["level"], "too_few_trades": few,
            "note": (warn + "Gewählt wird die beste robuste, risikoadjustierte Stufe (Score aus Rendite, Profit Factor, Sharpe, "
                     "Sortino, Drawdown, Liquidationen) - nicht die höchste Rendite. Keine Aussage über künftige Profitabilität."),
            "folds": len(folds)}
