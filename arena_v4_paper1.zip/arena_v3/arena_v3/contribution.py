"""
Incremental Contribution (V4): Mehrwert eines Agenten durch kontrollierte Ablation.

  Baseline-Team  vs.  Team ohne Agent A  - jeweils identischer Zeitraum, identische Daten, Kosten-, Risiko- und Ausführungsmodell,
  gleiche Parameter und Seeds. Der Agent wird nur im TEAM ausgeschaltet (sein Schattenkonto läuft weiter, damit die Lernwerte
  der übrigen Agenten unverändert bleiben).

Kennzahlen je Agent: Delta Nettorendite, Delta Profit Factor, Delta Max-Drawdown, Delta Trades sowie die Streuung über Teilfenster
(Stabilität). Ergänzend: Signalredundanz (mittlere Korrelation zu den anderen Agenten) und Rohleistung des Schattenkontos nach
Symbol / Richtung / Regime.

Grenzen (werden im Ergebnis ausgewiesen): Wegen Interaktionen (Konsens-Schwellen, Risikobudget, Portfolio-Limits) ist eine einzelne
Ablation nicht immer kausal. Bei zu wenigen Trades ist das Ergebnis "inconclusive". Rechenlast: (Agenten + 1) Backtests.
"""
from __future__ import annotations

import math

from .agents import MarketCtx
from .analytics import compute_metrics
from .backtest import run_backtest
from .learning import pearson


def _seg_returns(res, cfg, k):
    """Nettorendite je Teilfenster aus der Equity-Kurve."""
    c = res["curve"]
    if len(c) < k * 2:
        return []
    out = []
    for j in range(k):
        a, b = c[len(c) * j // k][1], c[min(len(c) - 1, len(c) * (j + 1) // k - 1)][1]
        out.append(b / a - 1.0 if a > 0 else 0.0)
    return out


def ablation(data, cfg, params=None, start=None, end=None, agents=None, segments=3, burn_in=800, min_trades=30, progress=None):
    ctx = MarketCtx(data)
    base = run_backtest(data, cfg, params, start=start, end=end, burn_in=burn_in, ctx=ctx, keep_system=True)
    bm, bsys = base["metrics"], base["system"]
    names = agents or [a.name for a in bsys.agents]
    bseg = _seg_returns(base, cfg, segments)
    rows, hist = [], bsys.agg.hist
    for n_i, name in enumerate(names):
        r = run_backtest(data, cfg, params, start=start, end=end, burn_in=burn_in, ctx=ctx, disable_agents=[name])
        m = r["metrics"]
        seg = _seg_returns(r, cfg, segments)
        # Beitrag = Baseline MINUS Team ohne Agent (positiv = Agent hilft)
        d_seg = [b - s for b, s in zip(bseg, seg)]
        mean_d = sum(d_seg) / len(d_seg) if d_seg else None
        sd = (sum((x - mean_d) ** 2 for x in d_seg) / max(1, len(d_seg) - 1)) ** 0.5 if d_seg and len(d_seg) > 1 else None
        pf_b, pf_r = bm["profit_factor"], m["profit_factor"]
        # Redundanz: mittlere Korrelation der Signalstärken mit allen anderen Agenten
        cs = []
        for o in hist:
            if o != name and name in hist:
                n_ = min(len(hist[name]), len(hist[o]), 300)
                if n_ >= 30:
                    cs.append(pearson(hist[name][-n_:], hist[o][-n_:]))
        rows.append({
            "agent": name,
            "delta_net_return": bm["net_return"] - m["net_return"],
            "delta_profit_factor": (None if pf_b is None or pf_r is None or math.isinf(pf_b) or math.isinf(pf_r) else pf_b - pf_r),
            "delta_max_drawdown": m["max_drawdown"] - bm["max_drawdown"],        # positiv = Agent senkt den Drawdown
            "delta_trades": bm["trades"] - m["trades"],
            "segment_deltas": d_seg, "segment_mean": mean_d, "segment_sd": sd,
            "redundancy": (sum(cs) / len(cs)) if cs else None,
            "verdict": _verdict(bm["trades"], m["trades"], mean_d, sd, min_trades),
        })
        if progress:
            progress(n_i + 1, len(names), name)
    return {"baseline": {k: bm[k] for k in ("net_return", "profit_factor", "max_drawdown", "trades", "sharpe")},
            "rows": rows, "segments": segments, "n_runs": len(names) + 1, "by_group": shadow_breakdown(bsys),
            "note": ("Ablation je Agent gegen identische Baseline (gleicher Zeitraum, Kosten-, Risiko-, Ausführungsmodell). Wegen Interaktionen "
                     "nicht immer kausal; bei weniger als %d Trades 'inconclusive'. Kein Auto-Hochgewichten." % min_trades)}


def _verdict(n_base, n_wo, mean_d, sd, min_trades):
    if max(n_base, n_wo) < min_trades or mean_d is None:
        return "inconclusive"
    if sd is None:
        return "unklar"
    se = sd / math.sqrt(3.0)
    if mean_d - 1.28 * se > 0:
        return "hilft"
    if mean_d + 1.28 * se < 0:
        return "schadet"
    return "kein_nachweis"


def shadow_breakdown(sysm) -> dict:
    """Rohleistung der Schattenkonten je Agent nach Symbol / Richtung / Regime (Netto-R, Anzahl)."""
    out = {}
    for a, trades in sysm.shadow_closed.items():
        g = {"symbol": {}, "side": {}, "regime": {}}
        for t in trades:
            for key, val in (("symbol", t.symbol), ("side", "long" if t.side > 0 else "short"), ("regime", (t.regime or "?").split("/")[0])):
                b = g[key].setdefault(val, [0, 0.0])
                b[0] += 1; b[1] += t.r_multiple
        out[a] = {k: {x: {"n": v[0], "mean_r": v[1] / v[0]} for x, v in d.items()} for k, d in g.items()}
    return out


def suggest_influence(rows, current=None, step=0.25) -> dict:
    """Vorschläge für das Nutzer-Stimmrecht aus der Ablation. NIE automatisch angewendet.
    Nicht-positive oder unklare Beiträge werden nie hochgewichtet (Vorschlag <= aktueller Wert)."""
    cur = current or {}
    out = {}
    for r in rows:
        c = cur.get(r["agent"], 1.0)
        v = r["verdict"]
        if v == "schadet":
            out[r["agent"]] = max(0.0, c - 2 * step)
        elif v == "hilft":
            out[r["agent"]] = min(1.5, c + step)
        else:                                      # kein_nachweis / unklar / inconclusive: nicht hochgewichten
            out[r["agent"]] = min(c, 1.0)
    return out
