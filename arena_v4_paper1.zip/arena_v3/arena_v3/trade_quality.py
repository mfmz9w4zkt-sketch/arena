"""
Trade Quality Gate (V4): konservative Netto-Edge VOR der Risk Engine.

Ein Trade wird nur freigegeben, wenn der KONSERVATIVE erwartete Nettoertrag (je Notional) positiv ist:

    p_win        = 0.5 + (conf - 0.5) * shrink            shrink = 0.5 + 0.5 * reliability  (unbewährte Agenten: halber Vertrauensbonus)
    EV_brutto    = p_win * TP - (1 - p_win) * SL          (Stop-/Target-Asymmetrie ist enthalten)
    Kosten       = Gebühren (beide Seiten) + Spread + Slippage (beide Seiten, Stop schlechter) + Market Impact + Funding
    sigma        = (TP + SL) / 2 * sqrt(p (1-p) / n_eff)  Unsicherheit des Erwartungswerts bei effektiver Stichprobe n_eff
    konservativ  = EV_brutto - Kosten - z * sigma

Fehlende oder ungültige Eingaben (Kosten-, Liquiditäts-, Preisdaten) führen IMMER zur Ablehnung (konservativ).
Das Gate lockert nichts: Aktivitätsstufe und Nutzersteuerung haben keinen Einfluss auf diese Prüfung.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, asdict


@dataclass
class GateResult:
    ok: bool
    reason: str
    gross_edge: float = 0.0            # erwarteter Bruttoertrag (EV vor Kosten) je Notional
    costs: dict = field(default_factory=dict)
    total_cost: float = 0.0
    p_win: float = 0.0
    sigma: float = 0.0
    conservative_net: float = 0.0
    gate_version: int = 1

    def to_dict(self):
        return asdict(self)


def _bad(x) -> bool:
    return x is None or not isinstance(x, (int, float)) or math.isnan(x) or math.isinf(x)


def evaluate(cfg, ex, *, stop_dist, tp_dist, conf, reliability, n_eff, atr_pct, liquidity, fund_rate=None, exp_ret=None) -> GateResult:
    ver = int(getattr(cfg, "gate_version", 1))
    for name, v in (("stop_dist", stop_dist), ("tp_dist", tp_dist), ("conf", conf), ("atr_pct", atr_pct),
                    ("liquidity", liquidity), ("reliability", reliability), ("n_eff", n_eff)):
        if _bad(v):
            return GateResult(False, f"Daten unvollständig ({name} fehlt)", gate_version=ver)
    if stop_dist <= 0 or tp_dist <= 0 or atr_pct <= 0:
        return GateResult(False, "Daten ungültig (Stop/Target/ATR <= 0)", gate_version=ver)
    if liquidity <= 0:
        return GateResult(False, "Liquidität unbekannt oder 0", gate_version=ver)
    shrink = 0.5 + 0.5 * max(0.0, min(1.0, reliability))
    p = max(0.05, min(0.95, 0.5 + (conf - 0.5) * shrink))
    ev_gross = p * tp_dist - (1.0 - p) * stop_dist
    # Kosten (je Notional, Hin- und Rückweg)
    fees = 2 * cfg.fee_taker
    spread = 2 * cfg.half_spread
    slip = 2 * ex.slip(atr_pct)
    stop_extra = (1.0 - p) * (ex.stop_slip(atr_pct) - ex.slip(atr_pct))       # Stops werden schlechter ausgeführt
    impact = 2 * cfg.gate_impact_coef * (1.0 - max(0.0, min(1.0, liquidity)))
    fr = abs(fund_rate if fund_rate is not None else cfg.funding_const_8h)     # unbekanntes Funding: konservativ Konstante, beide Seiten
    funding = fr * cfg.expected_hold_bars * cfg.interval_sec / 28800.0
    costs = {"fees": fees, "spread": spread, "slippage": slip + stop_extra, "impact": impact, "funding": funding}
    total = sum(costs.values())
    n = max(float(n_eff), 5.0)
    sigma = 0.5 * (tp_dist + stop_dist) * math.sqrt(p * (1.0 - p) / n)
    cons = ev_gross - total - cfg.gate_z * sigma
    base = dict(gross_edge=ev_gross, costs=costs, total_cost=total, p_win=p, sigma=sigma, conservative_net=cons, gate_version=ver)
    if cons <= cfg.gate_min_margin:
        return GateResult(False, f"konservative Netto-Edge {cons * 100:+.3f} % <= Mindestabstand", **base)
    return GateResult(True, "ok", **base)
