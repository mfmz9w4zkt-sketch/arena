"""
Validierungswerkzeuge (V4): Purging/Embargo, Kalibrierungsmetriken, Block-Bootstrap, Deflated Sharpe, Promotion-Status.
Alles deterministisch (feste Seeds) und ohne externe Abhängigkeiten.
"""
from __future__ import annotations

import math
import random
from statistics import NormalDist


# ---------------------------------------------------------------- Purging / Embargo
def purged_split(idx: list, cut_pos: int, horizon: int, embargo: int = 0):
    """
    idx     : aufsteigende Kerzenindizes j der Beispiele (Features bei j, Label reicht bis j + horizon)
    cut_pos : Position in idx, ab der die Validierung beginnt
    Trainingsbeispiele werden entfernt (purged), wenn ihr Label-Fenster [j, j+horizon] (+ Embargo) den Beginn der Validierung
    v0 = idx[cut_pos] erreicht:  behalten nur  j + horizon + embargo < v0.
    Rückgabe: (train_positions, valid_positions, v0)
    """
    if not (0 < cut_pos < len(idx)):
        return list(range(len(idx))), [], None
    v0 = idx[cut_pos]
    train = [k for k in range(cut_pos) if idx[k] + horizon + embargo < v0]
    valid = list(range(cut_pos, len(idx)))
    return train, valid, v0


def label_overlap(idx_train: list, v0: int, horizon: int) -> int:
    """Anzahl Trainingsbeispiele, deren Label in die Validierung hineinreicht (Soll: 0)."""
    return sum(1 for j in idx_train if j + horizon >= v0)


# ---------------------------------------------------------------- Kalibrierung
def brier(p: list, y: list) -> float:
    return sum((a - b) ** 2 for a, b in zip(p, y)) / len(p) if p else float("nan")


def log_loss(p: list, y: list, eps=1e-9) -> float:
    if not p:
        return float("nan")
    return -sum(b * math.log(max(eps, min(1 - eps, a))) + (1 - b) * math.log(max(eps, min(1 - eps, 1 - a)))
                for a, b in zip(p, y)) / len(p)


def ece(p: list, y: list, bins=10) -> float:
    """Expected Calibration Error (gleich breite Bins)."""
    if not p:
        return float("nan")
    tot, n = 0.0, len(p)
    for b in range(bins):
        lo, hi = b / bins, (b + 1) / bins
        sel = [k for k in range(n) if (lo <= p[k] < hi) or (b == bins - 1 and p[k] == 1.0)]
        if sel:
            conf = sum(p[k] for k in sel) / len(sel)
            acc = sum(y[k] for k in sel) / len(sel)
            tot += len(sel) / n * abs(conf - acc)
    return tot


def reliability_curve(p: list, y: list, bins=10) -> list:
    out = []
    for b in range(bins):
        lo, hi = b / bins, (b + 1) / bins
        sel = [k for k in range(len(p)) if (lo <= p[k] < hi) or (b == bins - 1 and p[k] == 1.0)]
        out.append({"bin": [round(lo, 2), round(hi, 2)], "n": len(sel),
                    "mean_p": round(sum(p[k] for k in sel) / len(sel), 4) if sel else None,
                    "freq": round(sum(y[k] for k in sel) / len(sel), 4) if sel else None})
    return out


# ---------------------------------------------------------------- Bootstrap
def block_bootstrap_ci(values: list, block: int = 5, n_boot: int = 500, alpha: float = 0.05, seed: int = 7, stat=None):
    """Block-Bootstrap-Konfidenzintervall (Mittelwert oder stat(list)). Rückgabe (lo, hi) oder (None, None) bei zu wenig Daten."""
    n = len(values)
    if n < 8:
        return None, None
    stat = stat or (lambda v: sum(v) / len(v))
    rng = random.Random(seed)
    block = max(1, min(block, n))
    out = []
    for _ in range(n_boot):
        s = []
        while len(s) < n:
            a = rng.randrange(0, n - block + 1)
            s.extend(values[a:a + block])
        out.append(stat(s[:n]))
    out.sort()
    return out[int(alpha / 2 * n_boot)], out[min(n_boot - 1, int((1 - alpha / 2) * n_boot))]


def trade_stats(trades) -> dict:
    """Netto-Erwartungswert je Trade (USDT) und je Risikoeinheit (R) mit Mittelwert, Median und Bootstrap-CI."""
    r = [float(t.r_multiple) for t in trades]
    pnl = [float(t.net_pnl) for t in trades]
    if not r:
        return {"n": 0, "mean_r": None, "median_r": None, "ci_r": (None, None), "mean_pnl": None}
    srt = sorted(r)
    med = srt[len(srt) // 2] if len(srt) % 2 else 0.5 * (srt[len(srt) // 2 - 1] + srt[len(srt) // 2])
    return {"n": len(r), "mean_r": sum(r) / len(r), "median_r": med, "ci_r": block_bootstrap_ci(r),
            "mean_pnl": sum(pnl) / len(pnl)}


# ---------------------------------------------------------------- Multiple Testing
def expected_max_sharpe(n_trials: int, var_sr: float = 1.0) -> float:
    """Erwartetes Maximum des Sharpe unter n_trials unabhängigen Nullversuchen (Bailey & López de Prado)."""
    if n_trials <= 1:
        return 0.0
    nd = NormalDist()
    g = 0.5772156649
    return math.sqrt(var_sr) * ((1 - g) * nd.inv_cdf(1 - 1.0 / n_trials) + g * nd.inv_cdf(1 - 1.0 / (n_trials * math.e)))


def deflated_sharpe(sr: float, n_obs: int, n_trials: int, skew: float = 0.0, kurt: float = 3.0, var_sr: float | None = None) -> float | None:
    """Deflated Sharpe Ratio (Wahrscheinlichkeit, dass der wahre Sharpe > 0 ist, nach Abzug des Selektionseffekts). sr je Beobachtung."""
    if n_obs < 10:
        return None
    var_sr = var_sr if var_sr is not None else 1.0 / n_obs
    sr0 = expected_max_sharpe(n_trials, var_sr)
    denom = math.sqrt(max(1e-12, 1 - skew * sr + (kurt - 1) / 4.0 * sr * sr))
    z = (sr - sr0) * math.sqrt(n_obs - 1) / denom
    return NormalDist().cdf(z)


# ---------------------------------------------------------------- Promotion-Status
def promotion_status(n_trades: int, min_trades: int, screening: bool = False, leakage_findings: int = 0) -> dict:
    """'inconclusive', wenn Stichprobe zu klein; 'screening', wenn schneller Modus; 'blocked', wenn kritische Leakage-Befunde."""
    if leakage_findings:
        return {"status": "blocked", "reason": f"{leakage_findings} kritische Leakage-Befunde"}
    if screening:
        return {"status": "screening", "reason": "Screening-Modus (ohne Schattenkonten) darf nicht befördern"}
    if n_trades < min_trades:
        return {"status": "inconclusive", "reason": f"nur {n_trades} OOS-Trades (< {min_trades})"}
    return {"status": "conclusive", "reason": "Stichprobe ausreichend"}
