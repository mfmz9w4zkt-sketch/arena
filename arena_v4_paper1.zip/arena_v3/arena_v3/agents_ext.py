"""
Erweiterte Agenten 11-15. Alle sind "experimentell": Sie starten auf Bewährung (Teamgewicht max. 0,3), bis ihr Schatten-Konto
genug Netto-Ergebnisse gesammelt hat. Danach zählt nur noch ihre echte Bilanz.

  11 Orderbuch      Kauf-/Verkaufsdruck aus dem Orderbuch (nur live: es gibt keine Orderbuch-Historie)
  12 Derivate       Open Interest, Funding, Long/Short-Verhältnis (nur mit Futures-Daten)
  13 Liquidations   geschätzte Liquidationszonen und Stop-Cluster (Open Interest + gleiche Hochs/Tiefs)
  14 Marktstruktur  Swings, BOS, CHoCH, Fair Value Gaps, Liquidity Sweeps (nur Kerzen: auch im Backtest)
  15 Multi-Timeframe 15m/1h/4h/1d-Trend (nur Kerzen: auch im Backtest)

Ohne die nötigen Zusatzdaten (Backtest, Paar ohne Futures-Kontrakt, API-Fehler) geben 11-13 einfach "neutral" ab.
"""
from __future__ import annotations

import math

from .agents import Agent, Signal, NEUTRAL, against_strong_trend
from .extras import INTERVAL_MS, series_window


def _clip(x, lo, hi):
    return max(lo, min(hi, x))


def _last_funding(series, ts):
    fm = series.funding
    if not fm:
        return None
    ks = [k for k in fm if k <= ts]
    return fm[max(ks)] if ks else None


def _zscore_of_changes(ex, ts, lag, back):
    """z-Wert der letzten `lag`-Kerzen-Änderung des Open Interest gegen die Streuung der letzten `back` Kerzen. None, wenn zu wenig Daten."""
    ser = series_window(ex.oi_ts, ex.oi_v, ts, back)
    chg = [ser[k] / ser[k - lag] - 1.0 for k in range(lag, len(ser)) if ser[k] and ser[k - lag]]
    if len(chg) < 12 or ser[-1] is None or ser[-1 - lag] in (None, 0):
        return None, None
    last = ser[-1] / ser[-1 - lag] - 1.0
    mean = sum(chg) / len(chg)
    sd = math.sqrt(sum((x - mean) ** 2 for x in chg) / len(chg))
    return last, (last / sd if sd > 1e-9 else 0.0)


class OrderbookAgent(Agent):
    name, family = "Orderbuch", "orderflow"
    experimental = True
    affinity = {"up": 1.0, "down": 1.0, "range": 1.0}
    style = "Kauf-/Verkaufsdruck aus dem Orderbuch (Ungleichgewicht, große Limit-Orders, Spread, Tiefe). Nur live."
    MAX_CONF = 0.7                    # große Limit-Orders können nur zur Täuschung platziert sein (Spoofing)

    def signal(self, m, sym, i):
        if i < 130 or i != m.n() - 1:                      # Schnappschuss gilt nur für die neueste Kerze
            return NEUTRAL
        ex = m.extra.get(sym)
        ob = ex.ob if ex else None
        if not ob or ob.get("depth_usd", 0) < 20_000:
            return NEUTRAL
        ca, c, ap = self._basic(m, sym, i)
        if ob["spread_bps"] / 1e4 > 0.3 * ap or m.regime[sym][i].unusual:
            return NEUTRAL                                  # Spread frisst zu viel / Nachrichtenspitze: Buch unzuverlässig
        move = ca.roc(4)[i] / ap                            # Kursbewegung der letzten Stunde in ATR
        pressure = 0.6 * ob["imb_near"] + 0.4 * ob["imb_far"] + 0.25 * _clip(ob.get("imb_chg", 0.0), -1.0, 1.0)
        notes = []
        wb, wa = ob.get("wall_bid"), ob.get("wall_ask")
        if wb and wb["rel"] >= 6 and wb["dist"] <= 0.004:
            pressure += 0.15
            notes.append(f"Kauf-Wand {wb['rel']:.0f}x")
        if wa and wa["rel"] >= 6 and wa["dist"] <= 0.004:
            pressure -= 0.15
            notes.append(f"Verkaufs-Wand {wa['rel']:.0f}x")
        pressure = _clip(pressure, -1.0, 1.0)
        d, conf, why = 0, 0.0, ""
        if move >= 0.8 and pressure >= 0.25:
            d, conf, why = 1, 0.5 + 0.25 * pressure, "Anstieg wird von Käuferdruck getragen"
        elif move <= -0.8 and pressure <= -0.25:
            d, conf, why = -1, 0.5 + 0.25 * -pressure, "Rückgang wird von Verkäuferdruck getragen"
        elif move >= 0.8 and pressure <= -0.25:
            d, conf, why = -1, 0.5 + 0.1 * -pressure, "Anstieg ohne Käufer, Verkäufer halten dagegen"
        elif move <= -0.8 and pressure >= 0.25:
            d, conf, why = 1, 0.5 + 0.1 * pressure, "Rückgang ohne Verkäufer, Käufer saugen auf"
        elif abs(move) < 0.5 and abs(pressure) >= 0.5 and ob.get("depth_chg", 0.0) > 0:
            d, conf, why = (1 if pressure > 0 else -1), 0.5, "starkes Ungleichgewicht bei ruhigem Kurs"
        if not d:
            return NEUTRAL
        txt = f"{why} (Imbalance {pressure:+.2f}, Spread {ob['spread_bps']:.1f} bp" + (", " + ", ".join(notes) if notes else "") + ")"
        return Signal(d, min(self.MAX_CONF, conf), ap * 1.5, 1.5 * ap, txt)


class DerivativesAgent(Agent):
    name, family = "Derivate", "deriv"
    experimental = True
    affinity = {"up": 1.1, "down": 1.1, "range": 0.8}
    style = "Open Interest gegen Preis, Funding und Long/Short-Verhältnis: neue Positionen oder Liquidation?"
    FUND_HIGH, FUND_EXTREME = 0.0003, 0.001                 # Funding je 8 Stunden (0,03 % / 0,1 %)

    def signal(self, m, sym, i):
        if i < 130:
            return NEUTRAL
        ex = m.extra.get(sym)
        if not ex or not ex.oi_ts:
            return NEUTRAL
        s = m.s(sym)
        ts = s.ts[i]
        d_oi, z = _zscore_of_changes(ex, ts, 4, 52)
        if z is None:
            return NEUTRAL
        ca, c, ap = self._basic(m, sym, i)
        move = ca.roc(4)[i] / ap
        fund = _last_funding(s, ts) or 0.0
        ls = ex.ls_at(ts)
        lsw = series_window(ex.ls_ts, ex.ls_v, ts, 96) if ls is not None else []
        lsv = [x for x in lsw if x]
        ls_z = 0.0
        if len(lsv) >= 24:
            mu = sum(lsv) / len(lsv)
            sd = math.sqrt(sum((x - mu) ** 2 for x in lsv) / len(lsv))
            ls_z = (ls - mu) / sd if sd > 1e-9 else 0.0
        crowd_long = fund >= self.FUND_HIGH or ls_z >= 1.5
        crowd_short = fund <= -self.FUND_HIGH * 0.5 or ls_z <= -1.5
        d, conf, why = 0, 0.0, ""
        if abs(move) >= 0.6 and abs(z) >= 0.8:
            if move > 0 and z > 0:
                d, conf, why = 1, 0.52 + 0.06 * min(z, 3.0), "Kurs und Open Interest steigen: neue Longs werden aufgebaut"
                conf -= 0.12 if crowd_long else 0.0
                if fund >= self.FUND_EXTREME:
                    d = 0                                   # extrem überlaufene Longs: nicht noch hinterherlaufen
            elif move < 0 and z > 0:
                d, conf, why = -1, 0.52 + 0.06 * min(z, 3.0), "Kurs fällt, Open Interest steigt: neue Shorts werden aufgebaut"
                conf -= 0.12 if crowd_short else 0.0
                if fund <= -self.FUND_EXTREME * 0.5:
                    d = 0                                   # extrem überlaufene Shorts: Squeeze-Gefahr
            elif move < -2.0 and z <= -1.5:
                d, conf, why = 1, 0.5, "starker Kursverfall bei stark fallendem Open Interest: Positionen werden liquidiert"
        if d == 0:
            if fund >= self.FUND_EXTREME and move <= 0.5:
                d, conf, why = -1, 0.5, "Funding extrem hoch: Longs überlaufen"
            elif fund <= -self.FUND_EXTREME * 0.5 and move >= -0.5:
                d, conf, why = 1, 0.5, "Funding stark negativ: Shorts überlaufen"
        if not d or conf < 0.45:
            return NEUTRAL
        txt = f"{why} (OI {d_oi * 100:+.1f} %, z={z:+.1f}, Funding {fund * 100:+.3f} %, L/S-z {ls_z:+.1f})"
        return Signal(d, min(0.72, conf), ap * 2.0, 2 * ap, txt)


class LiquidationAgent(Agent):
    name, family = "Liquidations-Agent", "liquidity"
    experimental = True
    affinity = {"up": 1.0, "down": 1.0, "range": 1.0}
    style = "Geschätzte Liquidationszonen (aus Open-Interest-Zuwachs) und Stop-Cluster (gleiche Hochs/Tiefs): Squeezes und Sweeps"
    LEVS = ((5, 0.10), (10, 0.30), (25, 0.35), (50, 0.20), (100, 0.05))
    MM = 0.005                                                # Maintenance-Margin-Näherung
    LOOK = 192                                                # 2 Tage
    REACH = 3.0                                               # Zonen bis zu 3 ATR Entfernung zählen

    def _zones(self, m, sym, i, ex):
        """-> (obere_zone, untere_zone) als (preis, stärke) oder None. Stärke = Gewicht relativ zum Durchschnitt aller Zonen."""
        s = m.s(sym)
        lo = max(2, i - self.LOOK + 1)
        ts = s.ts
        oi = [ex.oi_at(ts[k]) for k in range(lo - 1, i + 1)]
        if any(x is None for x in oi):
            return None, None
        _, c, ap = self._basic(m, sym, i)
        width = 0.25 * ap * c
        # min/max seit Kerze k: bereits ausgelöste Zonen entfallen
        n = i - lo + 1
        suf_min, suf_max = [0.0] * (n + 1), [0.0] * (n + 1)
        suf_min[n], suf_max[n] = float("inf"), float("-inf")
        for k in range(n - 1, -1, -1):
            suf_min[k] = min(suf_min[k + 1], s.l[lo + k])
            suf_max[k] = max(suf_max[k + 1], s.h[lo + k])
        up, dn = {}, {}
        for k in range(n):
            j = lo + k
            dpos = oi[k + 1] - oi[k]
            if dpos <= 0:
                continue
            px = s.c[j]
            longs = s.c[j] >= s.o[j]                          # steigende Kerze + wachsendes OI: überwiegend neue Longs
            for lev, w in self.LEVS:
                if longs:
                    lvl = px * (1.0 - 1.0 / lev + self.MM)
                    if lvl < c and suf_min[k + 1] > lvl:
                        dn[round(lvl / width)] = dn.get(round(lvl / width), 0.0) + dpos * w
                else:
                    lvl = px * (1.0 + 1.0 / lev - self.MM)
                    if lvl > c and suf_max[k + 1] < lvl:
                        up[round(lvl / width)] = up.get(round(lvl / width), 0.0) + dpos * w
        allw = list(up.values()) + list(dn.values())
        if len(allw) < 3:
            return None, None
        avg = sum(allw) / len(allw)

        def best(zones, above):
            cand = [((b * width), wgt / avg) for b, wgt in zones.items() if 0 < (((b * width) - c) if above else (c - (b * width))) <= self.REACH * ap * c]
            return max(cand, key=lambda x: x[1], default=None)
        return best(up, True), best(dn, False)

    def signal(self, m, sym, i):
        if i < 130:
            return NEUTRAL
        ca, c, ap = self._basic(m, sym, i)
        st = m.structure(sym)[i]
        ex = m.extra.get(sym)
        up = dn = None
        have_oi = bool(ex and ex.oi_ts)
        if have_oi:
            up, dn = self._zones(m, sym, i, ex)
            if up and up[1] < 2.5:
                up = None
            if dn and dn[1] < 2.5:
                dn = None
        src_up = f"geschätzte Short-Liquidationen bei {up[0]:.6g}" if up else ""
        src_dn = f"geschätzte Long-Liquidationen bei {dn[0]:.6g}" if dn else ""
        if st.eq_high and (st.eq_high - c) <= self.REACH * ap * c:
            up = up or (st.eq_high, 2.5)
            src_up = (src_up + ", " if src_up else "") + f"gleiche Hochs (Stop-Cluster) bei {st.eq_high:.6g}"
        if st.eq_low and (c - st.eq_low) <= self.REACH * ap * c:
            dn = dn or (st.eq_low, 2.5)
            src_dn = (src_dn + ", " if src_dn else "") + f"gleiche Tiefs (Stop-Cluster) bei {st.eq_low:.6g}"
        if not up and not dn:
            return NEUTRAL
        reg = m.regime[sym][i]
        if reg.unusual:
            return NEUTRAL
        cap = 0.65 if have_oi else 0.58
        # Sweep: Zone wurde gerade angestochen und abgelehnt -> Umkehr
        if st.sweep == 1 and dn:
            return Signal(1, min(cap, 0.55 + 0.04 * min(dn[1], 5)), ap * 2.0, 1.5 * ap, f"Sweep nach unten abgelehnt, Stops abgefischt ({src_dn})")
        if st.sweep == -1 and up:
            return Signal(-1, min(cap, 0.55 + 0.04 * min(up[1], 5)), ap * 2.0, 1.5 * ap, f"Sweep nach oben abgelehnt, Stops abgefischt ({src_up})")
        # Magnet: Preis läuft auf eine dichte Zone zu
        mom = ca.roc(4)[i] / ap
        e20 = ca.ema(20)[i]
        if up and mom > 0.4 and c > e20 and not against_strong_trend(reg, 1) and (not dn or up[1] >= dn[1]):
            dist = (up[0] - c) / c
            return Signal(1, min(cap, 0.5 + 0.04 * min(up[1], 5)), max(ap, min(dist, 3 * ap)), 1.5 * ap, f"Squeeze-Magnet über dem Preis ({src_up})")
        if dn and mom < -0.4 and c < e20 and not against_strong_trend(reg, -1) and (not up or dn[1] >= up[1]):
            dist = (c - dn[0]) / c
            return Signal(-1, min(cap, 0.5 + 0.04 * min(dn[1], 5)), max(ap, min(dist, 3 * ap)), 1.5 * ap, f"Squeeze-Magnet unter dem Preis ({src_dn})")
        return NEUTRAL


class MarketStructureAgent(Agent):
    name, family = "Marktstruktur", "structure"
    experimental = True
    affinity = {"up": 1.1, "down": 1.1, "range": 0.9}
    style = "Swings, BOS/CHoCH, Fair Value Gaps, Liquidity Sweeps und Unterstützung/Widerstand"

    def signal(self, m, sym, i):
        if i < 130:
            return NEUTRAL
        st = m.structure(sym)[i]
        s = m.s(sym)
        ca, c, ap = self._basic(m, sym, i)
        o, h, l = s.o[i], s.h[i], s.l[i]
        pos = (c - l) / (h - l) if h > l else 0.5
        reg = m.regime[sym][i]
        if reg.unusual:
            return NEUTRAL
        # A) Liquidity Sweep mit Ablehnung
        if st.sweep == 1 and pos >= 0.6 and not against_strong_trend(reg, 1):
            conf = 0.55 + (0.08 if st.trend == 1 else 0.0) + (0.05 if st.eq_low else 0.0)
            return Signal(1, min(0.75, conf), ap * 2.2, _clip((c - l) / c * 1.2, ap, 3 * ap),
                          "Liquidity Sweep unter Swing-Tief, Schluss zurück darüber")
        if st.sweep == -1 and pos <= 0.4 and not against_strong_trend(reg, -1):
            conf = 0.55 + (0.08 if st.trend == -1 else 0.0) + (0.05 if st.eq_high else 0.0)
            return Signal(-1, min(0.75, conf), ap * 2.2, _clip((h - c) / c * 1.2, ap, 3 * ap),
                          "Liquidity Sweep über Swing-Hoch, Schluss zurück darunter")
        # B) Rücksetzer nach Strukturbruch in eine Fair Value Gap oder an Unterstützung/Widerstand
        age = i - st.event_idx if st.event_idx >= 0 else 10 ** 9
        if st.trend == 1 and st.event in ("BOS_UP", "CHOCH_UP") and 2 <= age <= 40 and c > o:
            z = st.fvg_bull
            in_fvg = bool(z and l <= z[1] and c >= z[0])
            near_sup = st.sl is not None and 0 <= (l - st.sl) / (ap * c) <= 0.8
            if in_fvg or near_sup:
                conf = 0.6 + (0.05 if st.event == "CHOCH_UP" else 0.0) + (0.05 if in_fvg and near_sup else 0.0)
                where = "Fair Value Gap" if in_fvg else "Unterstützung am Swing-Tief"
                return Signal(1, min(0.75, conf), ap * 2.5, _clip((c - (st.sl or l)) / c, ap, 3 * ap),
                              f"{'CHoCH' if st.event == 'CHOCH_UP' else 'BOS'} nach oben, Rücksetzer in {where}")
        if st.trend == -1 and st.event in ("BOS_DN", "CHOCH_DN") and 2 <= age <= 40 and c < o:
            z = st.fvg_bear
            in_fvg = bool(z and h >= z[0] and c <= z[1])
            near_res = st.sh is not None and 0 <= (st.sh - h) / (ap * c) <= 0.8
            if in_fvg or near_res:
                conf = 0.6 + (0.05 if st.event == "CHOCH_DN" else 0.0) + (0.05 if in_fvg and near_res else 0.0)
                where = "Fair Value Gap" if in_fvg else "Widerstand am Swing-Hoch"
                return Signal(-1, min(0.75, conf), ap * 2.5, _clip(((st.sh or h) - c) / c, ap, 3 * ap),
                              f"{'CHoCH' if st.event == 'CHOCH_DN' else 'BOS'} nach unten, Rücksetzer in {where}")
        return NEUTRAL


class MultiTimeframeAgent(Agent):
    name, family = "Multi-Timeframe", "mtf"
    experimental = True
    affinity = {"up": 1.2, "down": 1.2, "range": 0.5}
    style = "Einstieg nur, wenn 15m-Rücksetzer zum Trend von 1h, 4h und Tag passt"
    W = (("1d", 0.35), ("4h", 0.30), ("1h", 0.20))

    def signal(self, m, sym, i):
        if i < 210:
            return NEUTRAL
        mt = m.mtf(sym)
        score = wsum = 0.0
        names = []
        for tf, w in self.W:
            tr, st = mt[tf][0][i], mt[tf][1][i]
            if tr == 0 and st == 0.0:                         # Ebene noch nicht berechenbar (zu wenig Historie)
                continue
            score += w * tr
            wsum += w
            names.append(f"{tf} {'auf' if tr > 0 else 'ab' if tr < 0 else 'seitwärts'}")
        if wsum < 0.5:                                        # mindestens zwei Ebenen nötig
            return NEUTRAL
        score /= wsum
        if abs(score) < 0.6:
            return NEUTRAL                                    # Zeitebenen widersprechen sich oder sind seitwärts
        d = 1 if score > 0 else -1
        ca, c, ap = self._basic(m, sym, i)
        reg = m.regime[sym][i]
        if reg.unusual or reg.vol == "extreme":
            return NEUTRAL
        gap15 = (ca.ema(20)[i] - ca.ema(50)[i]) / c / ap
        if gap15 * d < -0.5:                                  # 15m läuft klar gegen die höheren Ebenen: abwarten
            return NEUTRAL
        rs = ca.rsi(14)[i]
        ext = (c - ca.ema(80)[i]) / c / ap * d                # Abstand vom 1h-Trendanker in ATR (nicht hinterherlaufen)
        if d > 0:
            ok = c > ca.ema(20)[i] and 40 <= rs <= 68 and ext <= 3.0
        else:
            ok = c < ca.ema(20)[i] and 32 <= rs <= 60 and ext <= 3.0
        if not ok:
            return NEUTRAL
        conf = min(0.85, 0.5 + 0.3 * abs(score) + (0.05 if gap15 * d > 0.3 else 0.0))
        return Signal(d, conf, ap * 2.5, 2 * ap, "Trend " + ", ".join(names) + ", Einstieg nach Rücksetzer auf 15m")


EXT_AGENT_CLASSES = [OrderbookAgent, DerivativesAgent, LiquidationAgent, MarketStructureAgent, MultiTimeframeAgent]
