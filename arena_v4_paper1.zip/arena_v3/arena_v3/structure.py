"""
Marktstruktur (kausal, ohne Look-ahead): Swing-Hochs/-Tiefs, Break of Structure (BOS), Change of Character (CHoCH),
Liquidity Sweeps, Fair Value Gaps (FVG), Unterstützung/Widerstand und gleiche Hochs/Tiefs (Stop-Cluster).

Ein Swing-Hoch bei Index j gilt erst als bekannt, wenn K weitere Kerzen abgeschlossen sind (Bestätigung bei i = j + K).
Ereignisse werden immer auf Basis der Schlusskurse bis einschließlich Kerze i erkannt.
"""
from __future__ import annotations

from collections import namedtuple

K = 3                   # Kerzen links und rechts für einen Swing
FVG_MAX_AGE = 150
EQ_TOL_ATR = 0.25       # Swings innerhalb dieser Distanz (in ATR) gelten als "gleiche Hochs/Tiefs"

Struct = namedtuple("Struct", "trend event event_idx sh sl sweep fvg_bull fvg_bear eq_high eq_low")
# trend: +1/-1/0 | event: "BOS_UP","BOS_DN","CHOCH_UP","CHOCH_DN" oder "" (letztes Ereignis) | event_idx: Index des Ereignisses
# sh/sl: Pegel des letzten Swing-Hochs/-Tiefs | sweep: +1 (Tief abgefischt, bullisch) / -1 (Hoch abgefischt, bärisch) / 0 (nur diese Kerze)
# fvg_bull/fvg_bear: (unten, oben) der nächsten unmitigierten Lücke oder None | eq_high/eq_low: Pegel gleicher Hochs/Tiefs oder None


def compute_structure(series, atr_pct) -> list:
    h, l, c, o = series.h, series.l, series.c, series.o
    n = len(c)
    out = []
    trend = 0
    last_sh = last_sl = None            # (level, idx, broken)
    swing_highs, swing_lows = [], []    # (level, idx)
    ev, ev_idx = "", -1
    fvg_b, fvg_s = [], []               # [lo, hi, born]
    eq_hi, eq_lo = [], []               # Pegel gleicher Hochs/Tiefs (Stop-Cluster), werden bei Durchbruch verbraucht
    for i in range(n):
        ap_abs = max(atr_pct[i], 1e-6) * c[i]
        # Swings bestätigen (Kandidat j = i - K)
        j = i - K
        if j >= K:
            if h[j] > max(h[j - K:j]) and h[j] >= max(h[j + 1:j + K + 1]):
                last_sh = [h[j], j, False]
                swing_highs.append((h[j], j))
                if sum(1 for x, _ in swing_highs[-8:] if abs(x - h[j]) <= EQ_TOL_ATR * ap_abs) >= 2:
                    eq_hi.append(h[j])
                    del eq_hi[:-4]
            if l[j] < min(l[j - K:j]) and l[j] <= min(l[j + 1:j + K + 1]):
                last_sl = [l[j], j, False]
                swing_lows.append((l[j], j))
                if sum(1 for x, _ in swing_lows[-8:] if abs(x - l[j]) <= EQ_TOL_ATR * ap_abs) >= 2:
                    eq_lo.append(l[j])
                    del eq_lo[:-4]
        sweep = 0
        # Strukturbruch per Schlusskurs
        if last_sh and not last_sh[2] and c[i] > last_sh[0]:
            ev = "BOS_UP" if trend == 1 else "CHOCH_UP"
            ev_idx, trend, last_sh[2] = i, 1, True
        elif last_sl and not last_sl[2] and c[i] < last_sl[0]:
            ev = "BOS_DN" if trend == -1 else "CHOCH_DN"
            ev_idx, trend, last_sl[2] = i, -1, True
        else:
            # Liquidity Sweep: Docht über/unter Swing, Schluss zurück innerhalb
            if last_sh and not last_sh[2] and h[i] > last_sh[0] >= c[i]:
                sweep = -1
            if last_sl and not last_sl[2] and l[i] < last_sl[0] <= c[i]:
                sweep = 1 if sweep == 0 else 0
        # Fair Value Gaps
        if i >= 2:
            if l[i] > h[i - 2] and c[i - 1] > o[i - 1]:
                fvg_b.append([h[i - 2], l[i], i])
            if h[i] < l[i - 2] and c[i - 1] < o[i - 1]:
                fvg_s.append([h[i], l[i - 2], i])
        fvg_b = [z for z in fvg_b if i - z[2] <= FVG_MAX_AGE and c[i] >= z[0]][-6:]    # Schluss unter die Lücke = ungültig
        fvg_s = [z for z in fvg_s if i - z[2] <= FVG_MAX_AGE and c[i] <= z[1]][-6:]
        zb = max((z for z in fvg_b if z[2] < i), key=lambda z: z[1], default=None)     # nächste Lücke unter dem Preis
        zs = min((z for z in fvg_s if z[2] < i), key=lambda z: z[0], default=None)
        # gleiche Hochs/Tiefs: nächster noch nicht durchbrochener Pegel
        eq_hi = [x for x in eq_hi if x > c[i]]
        eq_lo = [x for x in eq_lo if x < c[i]]
        eqh = min(eq_hi) if eq_hi else None
        eql = max(eq_lo) if eq_lo else None
        out.append(Struct(trend, ev, ev_idx, last_sh[0] if last_sh else None, last_sl[0] if last_sl else None, sweep,
                          (zb[0], zb[1]) if zb else None, (zs[0], zs[1]) if zs else None, eqh, eql))
    return out
