"""
Nutzersteuerung (V4): Der Nutzer bewertet die Agenten selbst und bestimmt, wie viel Entscheidungsrecht sie im Team haben.

  * enabled   : Schalter. Aus = Agent bekommt im Team 0 % Stimmrecht. Sein Schattenkonto läuft weiter, damit man sieht,
                was er geleistet hätte (reine Messung, keine Trades des Teams).
  * influence : Stimmrecht-Faktor 0 .. 2 (1 = so, wie das Lernsystem es berechnet). Wirkt multiplikativ AUF das gelernte Gewicht.
  * activity  : Handelsaktivität 1 .. 5. Lockert bzw. verschärft nur die SIGNALFILTER des Teams (Konsens, Übereinstimmung, Confidence).

Leitplanken (technisch erzwungen):
  * Die Nutzersteuerung kann Risiko-Limits, die Risk Engine, das Trade Quality Gate und den Portfolio Guardian NICHT lockern.
  * Alle Werte werden begrenzt (clamp). Unbekannte Agenten werden ignoriert.
"""
from __future__ import annotations

INFLUENCE_MIN, INFLUENCE_MAX = 0.0, 2.0
ACTIVITY_MIN, ACTIVITY_MAX = 1, 5

# Aktivitätsstufe -> Faktoren auf die Team-Schwellen. Stufe 3 = Parameter unverändert (wie optimiert).
_ACTIVITY = {
    1: {"consensus": 1.35, "agreement": +0.05, "min_conf": 1.15, "conflict": -0.05, "shadow_conf": 1.10},
    2: {"consensus": 1.15, "agreement": +0.02, "min_conf": 1.07, "conflict": -0.02, "shadow_conf": 1.05},
    3: {"consensus": 1.00, "agreement": 0.00, "min_conf": 1.00, "conflict": 0.00, "shadow_conf": 1.00},
    4: {"consensus": 0.75, "agreement": -0.06, "min_conf": 0.88, "conflict": +0.05, "shadow_conf": 0.92},
    5: {"consensus": 0.55, "agreement": -0.12, "min_conf": 0.75, "conflict": +0.10, "shadow_conf": 0.85},
}
FLOORS = {"consensus": 0.10, "agreement": 0.55, "min_conf": 0.20, "conflict_max": 0.55, "shadow_conf": 0.30}


class UserControls:
    def __init__(self, agent_names=None):
        self.agents: dict = {}
        self.activity: int = 3
        self.auto_leverage: bool = True    # Hebel-Obergrenze je Agent wächst mit nachgewiesener Netto-Leistung (nie über das Risikoprofil)
        self.gate_mode: str = "strict"     # strict (Standard, Spezifikation 6.6) | monitor (Gate rechnet und protokolliert nur; Risk Engine bleibt bindend)
        for n in (agent_names or []):
            self.ensure(n)

    # ------------------------------------------------------------------
    def ensure(self, name):
        if name not in self.agents:
            self.agents[name] = {"enabled": True, "influence": 1.0, "lev_cap": None}   # lev_cap None = automatisch (leistungsabhängig)
        return self.agents[name]

    def set_agent(self, name, enabled=None, influence=None, lev_cap="keep") -> dict:
        if name not in self.agents:
            raise KeyError(f"unbekannter Agent: {name}")
        a = self.agents[name]
        if enabled is not None:
            a["enabled"] = bool(enabled)
        if influence is not None:
            try:
                v = float(influence)
            except (TypeError, ValueError):
                raise ValueError("influence muss eine Zahl sein")
            if v != v:                                    # NaN
                raise ValueError("influence muss eine Zahl sein")
            a["influence"] = max(INFLUENCE_MIN, min(INFLUENCE_MAX, v))
        if lev_cap != "keep":
            if lev_cap in (None, "auto"):
                a["lev_cap"] = None
            else:
                try:
                    v = int(round(float(lev_cap)))
                except (TypeError, ValueError):
                    raise ValueError("lev_cap muss eine Zahl oder 'auto' sein")
                a["lev_cap"] = max(1, min(125, v))          # endgültig begrenzt das Risikoprofil (agent_lev_cap)
        return dict(a)

    def set_auto_leverage(self, on) -> bool:
        self.auto_leverage = bool(on)
        return self.auto_leverage

    AUTO_TIERS = ((0.20, 60, 20), (0.10, 40, 10), (0.0, 20, 5))   # (untere Konfidenzgrenze in R, effektive Stichprobe, Hebel-Obergrenze)

    def agent_lev_cap(self, name, stats, profile_max) -> int:
        """Hebel-Obergrenze eines Agenten. Manuell: Nutzerwert. Automatisch: unbewährt 2x; mit belegter positiver Netto-Leistung
        (untere Konfidenzgrenze > 0 bei genügend Stichprobe) stufenweise 5x/10x/20x. Immer <= Risikoprofil; kein Hebel nach Verlusten."""
        a = self.agents.get(name, {})
        if a.get("lev_cap"):
            return max(1, min(int(a["lev_cap"]), profile_max))
        if not self.auto_leverage:
            return profile_max
        cap = 2
        for lcb, n, c in self.AUTO_TIERS:
            if stats.get("n_eff", 0) >= n and stats.get("lcb", -1) > lcb:
                cap = c
                break
        return max(1, min(cap, profile_max))

    def set_activity(self, level) -> int:
        try:
            lv = int(round(float(level)))
        except (TypeError, ValueError):
            raise ValueError("activity muss eine Zahl 1..5 sein")
        self.activity = max(ACTIVITY_MIN, min(ACTIVITY_MAX, lv))
        return self.activity

    def set_gate_mode(self, mode) -> str:
        if mode not in ("strict", "monitor"):
            raise ValueError("gate_mode muss 'strict' oder 'monitor' sein")
        self.gate_mode = mode
        return mode

    def influence(self, name) -> float:
        a = self.agents.get(name)
        if a is None:
            return 1.0
        return a["influence"] if a["enabled"] else 0.0

    def enabled(self, name) -> bool:
        a = self.agents.get(name)
        return True if a is None else bool(a["enabled"])

    # ------------------------------------------------------------------
    def thresholds(self, p: dict, cfg) -> dict:
        """Wirksame Team-Schwellen = Parameter (optimiert) x Aktivitäts-Overlay. Nur Signalfilter, keine Risikogrenzen."""
        f = _ACTIVITY[self.activity]
        return {
            "consensus": max(FLOORS["consensus"], p["team.consensus"] * f["consensus"]),
            "agreement": max(FLOORS["agreement"], min(0.95, p["team.agreement"] + f["agreement"])),
            "min_conf": max(FLOORS["min_conf"], p["team.min_conf"] * f["min_conf"]),
            "conflict": min(FLOORS["conflict_max"], max(0.2, cfg.conflict_thr + f["conflict"])),
            "shadow_conf": max(FLOORS["shadow_conf"], cfg.shadow_min_conf * f["shadow_conf"]),
        }

    def to_dict(self) -> dict:
        return {"agents": {k: dict(v) for k, v in self.agents.items()}, "activity": self.activity, "gate_mode": self.gate_mode, "auto_leverage": self.auto_leverage}

    def load_dict(self, d: dict | None):
        if not isinstance(d, dict):
            return
        for k, v in (d.get("agents") or {}).items():
            if k in self.agents and isinstance(v, dict):
                self.set_agent(k, v.get("enabled", True), v.get("influence", 1.0), v.get("lev_cap"))
        if "auto_leverage" in d:
            self.auto_leverage = bool(d["auto_leverage"])
        if d.get("gate_mode") in ("strict", "monitor"):
            self.gate_mode = d["gate_mode"]
        if "activity" in d:
            try:
                self.set_activity(d["activity"])
            except ValueError:
                pass
