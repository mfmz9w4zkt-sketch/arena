"""
Portfolio Guardian (V4): Korrelations-/Faktor-Exposure, Konzentration und risikobasierte Skalierung VOR der Risk Engine.

  * 50 ähnliche Altcoin-Longs sind nicht 50 unabhängige Risiken: gleichgerichtete Positionen mit Korrelation >= guard_corr_thr
    zählen als gemeinsames Risiko (korrelationsgewichtete Clusterzahl).
  * Beta zu BTC (rollierend, kausal) -> Netto-Beta-Exposure des Kontos.
  * Ergebnis: Freigabe/Ablehnung + Risikoskala (0..1). Die Skala kann nur VERKLEINERN (nie vergrößern).
  * Die Risk Engine bleibt unabhängiges Veto (Guardian ersetzt sie nicht und kann sie nicht umgehen).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field


@dataclass
class GuardResult:
    ok: bool
    reason: str
    scale: float = 1.0
    info: dict = field(default_factory=dict)


class PortfolioGuardian:
    def __init__(self, cfg):
        self.cfg = cfg

    def beta(self, m, sym, i, w=96):
        """Rollierendes Beta von sym zum Referenzmarkt (BTC); kausal bis Kerze i-1."""
        ref = m.ref
        if sym == ref:
            return 1.0
        ra, rb = m.returns(sym), m.returns(ref)
        a = max(1, i - w)
        x, y = rb[a:i], ra[a:i]
        n = len(x)
        if n < 20:
            return 1.0
        mx, my = sum(x) / n, sum(y) / n
        vx = sum((v - mx) ** 2 for v in x) / n
        if vx <= 0:
            return 1.0
        cov = sum((x[k] - mx) * (y[k] - my) for k in range(n)) / n
        return max(-3.0, min(3.0, cov / vx))

    def cluster_weight(self, m, acct, sym, side, i):
        """Korrelationsgewichtete Anzahl bestehender gleichgerichteter Positionen, die mit sym korrelieren."""
        thr = self.cfg.guard_corr_thr
        tot = 0.0
        for s, p in acct.positions.items():
            if s == sym or p.side != side:
                continue
            c = m.corr(sym, s, i - 1)
            if c >= thr:
                tot += c
        return tot

    def net_beta(self, m, acct, i):
        return sum(p.side * self.beta(m, s, i) for s, p in acct.positions.items())

    def check(self, m, acct, sym, side, i) -> GuardResult:
        cfg = self.cfg
        if not getattr(cfg, "guard_enabled", True):
            return GuardResult(True, "deaktiviert")
        try:
            cl = self.cluster_weight(m, acct, sym, side, i)
            nb = self.net_beta(m, acct, i)
            b = self.beta(m, sym, i)
        except Exception as e:                       # fehlende Daten -> konservativ ablehnen
            return GuardResult(False, f"Portfolio-Daten unvollständig ({e})")
        info = {"cluster": round(cl, 2), "net_beta": round(nb, 2), "beta": round(b, 2)}
        if cl >= cfg.guard_max_cluster - 0.05:        # Toleranz: Korrelation ist nie exakt 1,0
            return GuardResult(False, f"gemeinsames Risiko: {cl:.1f} korrelierte gleichgerichtete Positionen", 0.0, info)
        if abs(nb + side * b) > cfg.guard_beta_limit and abs(nb + side * b) > abs(nb):
            return GuardResult(False, f"Netto-Beta-Exposure {nb + side * b:+.1f} über Limit {cfg.guard_beta_limit}", 0.0, info)
        scale = 1.0 / (1.0 + 0.5 * cl)               # je mehr korrelierte Positionen, desto kleiner (nur Verkleinerung)
        info["scale"] = round(scale, 2)
        return GuardResult(True, "ok", scale, info)
