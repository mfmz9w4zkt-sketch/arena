"""
Multi-Timeframe-Trend aus den 15-Minuten-Kerzen (kausal, ohne Look-ahead).

Die höheren Zeitebenen (1 Stunde, 4 Stunden, 1 Tag) werden aus den 15-Minuten-Kerzen zusammengesetzt, an UTC-Grenzen ausgerichtet.
Für die 15-Minuten-Kerze i zählen NUR bereits abgeschlossene höhere Kerzen (die laufende wird nie verwendet). Unvollständige
Kerzen am Anfang des Datenfensters werden verworfen. Trend je Ebene: EMA schnell gegen EMA langsam, gemessen in ATR der Ebene.
"""
from __future__ import annotations

INTERVAL_MS = 900_000
# Ebene: (Anzahl 15m-Kerzen, EMA schnell, EMA langsam, mind. abgeschlossene Kerzen)
TFS = {"1h": (4, 10, 30, 34), "4h": (16, 6, 18, 20), "1d": (96, 3, 8, 8)}
STRONG = 0.3          # |EMA-Abstand| in ATR der Ebene, ab dem ein Trend gilt


def _ema_step(prev, x, n):
    a = 2.0 / (n + 1)
    return x if prev is None else prev + a * (x - prev)


def compute_mtf(series) -> dict:
    """-> {tf: (trend[i] in {-1,0,1}, strength[i] float)} für jede 15m-Kerze i."""
    ts, o, h, l, c = series.ts, series.o, series.h, series.l, series.c
    n = len(ts)
    out = {}
    for name, (k, nf, ns, need) in TFS.items():
        period = k * INTERVAL_MS
        trend, strength = [0] * n, [0.0] * n
        # Buckets bilden: (bucket_id, erster Index, letzter Index)
        buckets = []
        start = 0
        for i in range(1, n + 1):
            if i == n or ts[i] // period != ts[start] // period:
                buckets.append((ts[start] // period, start, i - 1))
                start = i
        # nur vollständige Buckets (k Kerzen, lückenlos) zählen
        comp = []                                   # (bucket_id, last_idx, O, H, L, C)
        for bid, a, b in buckets:
            if b - a + 1 == k and ts[a] == bid * period and ts[b] == (bid + 1) * period - INTERVAL_MS:
                comp.append((bid, b, o[a], max(h[a:b + 1]), min(l[a:b + 1]), c[b]))
        ef = es = None
        atrv = None
        prev_c = None
        states = []                                 # nach jeder vollständigen Kerze: (last_idx, trend, strength)
        for cnt, (bid, last, oo, hh, ll, cc) in enumerate(comp, start=1):
            ef, es = _ema_step(ef, cc, nf), _ema_step(es, cc, ns)
            tr = max(hh - ll, abs(hh - prev_c) if prev_c is not None else 0.0, abs(ll - prev_c) if prev_c is not None else 0.0)
            atrv = tr if atrv is None else atrv + (tr - atrv) / 14.0
            prev_c = cc
            if cnt >= need and atrv and atrv > 0:
                st = (ef - es) / atrv
                states.append((last, 1 if st > STRONG else -1 if st < -STRONG else 0, st))
            else:
                states.append((last, 0, 0.0))
        # Zuordnung: Kerze i sieht alle Buckets, die VOR ihrem eigenen Bucket vollständig abgeschlossen wurden
        j = -1
        for i in range(n):
            while j + 1 < len(states) and states[j + 1][0] < i and comp[j + 1][0] < ts[i] // period:
                j += 1
            if j >= 0:
                trend[i], strength[i] = states[j][1], states[j][2]
        out[name] = (trend, strength)
    return out
