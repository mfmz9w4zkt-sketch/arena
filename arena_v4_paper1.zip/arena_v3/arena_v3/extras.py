"""
Zusatzdaten für Orderbuch-, Derivate- und Liquiditäts-Agent (nur Live/Demo, nicht im Backtest):

  * Orderbuch-Schnappschuss (Spot, aktuelle Tiefe). Es gibt keine Orderbuch-HISTORIE, deshalb sind diese Daten nur für die
    jeweils neueste Kerze gültig. Große Limit-Orders können gespooft (nur zur Täuschung platziert) sein: Signale daraus bleiben vorsichtig.
  * Open Interest und globales Long/Short-Verhältnis (Futures-Daten, 15m, Binance liefert nur etwa 30 Tage Historie).
  * Fehlen Daten (kein Perpetual-Kontrakt, API-Fehler), liefern die Agenten für dieses Paar einfach "neutral".

Im Backtest, Walk-forward und Optimierer gibt es diese Daten nicht: die drei Agenten bleiben dort neutral und werden
ausschließlich live über ihr Schatten-Konto bewertet.
"""
from __future__ import annotations

import math
import random
import time
from bisect import bisect_right
from concurrent.futures import ThreadPoolExecutor

from .data import ClientError

INTERVAL_MS = 15 * 60 * 1000


class SymExtra:
    """Zusatzdaten eines Paars. Zeitreihen sind nach Zeit sortiert (ms)."""
    __slots__ = ("ob", "oi_ts", "oi_v", "ls_ts", "ls_v")

    def __init__(self, ob=None, oi=None, ls=None):
        self.ob = ob                                           # Orderbuch-Zusammenfassung (dict) oder None
        self.oi_ts, self.oi_v = _split(oi)                     # Open Interest in USD
        self.ls_ts, self.ls_v = _split(ls)                     # Long/Short-Konten-Verhältnis

    def oi_at(self, ts):
        return _at(self.oi_ts, self.oi_v, ts)

    def ls_at(self, ts):
        return _at(self.ls_ts, self.ls_v, ts)


def _split(pairs):
    if not pairs:
        return [], []
    pairs = sorted(pairs)
    return [int(t) for t, _ in pairs], [float(v) for _, v in pairs]


def _at(ts_list, v_list, t):
    """Letzter bekannter Wert zum Zeitpunkt t oder früher (None, wenn es keinen gibt)."""
    k = bisect_right(ts_list, t) - 1
    return v_list[k] if k >= 0 else None


def series_window(ts_list, v_list, ts_now, back_bars):
    """Werte für die letzten `back_bars`+1 Kerzen bis ts_now (None, wenn nicht vorhanden)."""
    return [_at(ts_list, v_list, ts_now - k * INTERVAL_MS) for k in range(back_bars, -1, -1)]


# ---------------------------------------------------------------- Orderbuch
def summarize_book(bids, asks):
    """
    Verdichtet ein Orderbuch (Listen aus [Preis, Menge]) auf wenige Kennzahlen. Gibt None bei leerem/ungültigem Buch zurück.
    Verglichen wird immer derselbe Preisabstand auf beiden Seiten, auch wenn das sichtbare Buch nicht so weit reicht.
    """
    try:
        bids = [(float(p), float(q)) for p, q in bids if float(q) > 0]
        asks = [(float(p), float(q)) for p, q in asks if float(q) > 0]
    except (TypeError, ValueError):
        return None
    if not bids or not asks:
        return None
    bids.sort(reverse=True)
    asks.sort()
    bb, ba = bids[0][0], asks[0][0]
    if bb <= 0 or ba <= bb * 0.5 or ba < bb:
        return None
    mid = (bb + ba) / 2
    reach = min((mid - bids[-1][0]) / mid, (asks[-1][0] - mid) / mid)          # so weit sehen wir auf BEIDEN Seiten
    if reach <= 0:
        return None
    near, far = min(0.003, reach), min(0.01, reach)

    def side(levels, band, sign):
        lim = mid * (1 + sign * band)
        return [(p, q) for p, q in levels if (p >= lim if sign < 0 else p <= lim)]

    def usd(levels):
        return sum(p * q for p, q in levels)

    b_n, a_n = usd(side(bids, near, -1)), usd(side(asks, near, +1))
    b_f_l, a_f_l = side(bids, far, -1), side(asks, far, +1)
    b_f, a_f = usd(b_f_l), usd(a_f_l)

    def imb(b, a):
        return (b - a) / (b + a) if (b + a) > 0 else 0.0

    def wall(levels):
        if len(levels) < 5:
            return None
        sizes = sorted(p * q for p, q in levels)
        med = sizes[len(sizes) // 2] or 1e-9
        p, q = max(levels, key=lambda x: x[0] * x[1])
        return {"dist": abs(p - mid) / mid, "rel": p * q / med, "usd": p * q}

    return {"mid": mid, "spread_bps": (ba - bb) / mid * 1e4, "imb_near": imb(b_n, a_n), "imb_far": imb(b_f, a_f),
            "bid_usd": b_f, "ask_usd": a_f, "depth_usd": b_f + a_f, "reach": reach,
            "wall_bid": wall(b_f_l), "wall_ask": wall(a_f_l)}


# ---------------------------------------------------------------- Abruf (live)
class ExtraFetcher:
    """Holt Zusatzdaten parallel und fehlertolerant, höchstens einmal je neuer Kerze. Jeder Fehler -> für das Paar keine Daten."""

    def __init__(self, get_client, workers=8):
        self.get_client = get_client
        self.workers = workers
        self.prev_ob = {}
        self.no_fut = set()                 # Paare ohne Futures-Kontrakt: nicht erneut abfragen
        self.last_bar = None
        self.cache = {}
        self.stats = {}

    def refresh(self, symbols, bar):
        if bar == self.last_bar and self.cache:
            return self.cache
        c = self.get_client()

        def one(sym):
            ob = oi = ls = None
            try:
                ob = summarize_book(*_book(c.depth(sym, 500)))
            except Exception:
                pass
            if sym not in self.no_fut:
                try:
                    oi = [(r["timestamp"], r["sumOpenInterestValue"]) for r in c.open_interest_hist(sym, "15m", 500)]
                    ls = [(r["timestamp"], r["longShortRatio"]) for r in c.long_short_ratio(sym, "15m", 500)]
                except Exception as e:
                    if isinstance(e, ClientError):
                        self.no_fut.add(sym)
            return sym, ob, oi, ls

        out = {}
        with ThreadPoolExecutor(max_workers=self.workers) as ex:
            for sym, ob, oi, ls in ex.map(one, symbols):
                if ob is not None:
                    prev = self.prev_ob.get(sym)
                    if prev and prev.get("depth_usd"):
                        ob["depth_chg"] = ob["depth_usd"] / prev["depth_usd"] - 1.0
                        ob["imb_chg"] = ob["imb_near"] - prev["imb_near"]
                    self.prev_ob[sym] = {"depth_usd": ob["depth_usd"], "imb_near": ob["imb_near"]}
                out[sym] = SymExtra(ob, oi, ls)
        self.cache, self.last_bar = out, bar
        self.stats = {"orderbook": sum(1 for x in out.values() if x.ob), "derivate": sum(1 for x in out.values() if x.oi_ts),
                      "paare": len(symbols)}
        return out


def _book(d):
    return d.get("bids", []), d.get("asks", [])


# ---------------------------------------------------------------- Demo-Daten (synthetisch, nur zur Anschauung)
def synthetic_extras(data, seed=7):
    """Erzeugt plausible, aber ERFUNDENE Orderbuch-/Derivate-Daten passend zu den Demo-Kursen (damit die Agenten im Demo laufen)."""
    out = {}
    for sym, s in data.items():
        n = len(s)
        if n < 30:
            out[sym] = SymExtra()
            continue
        rng = random.Random(seed * 7919 + sum(map(ord, sym)) * 31 + s.ts[0] // INTERVAL_MS)
        oi, ls = [], []
        base = 5e7 * (1 + (sum(map(ord, sym)) % 7))
        cur = base
        for i in range(max(0, n - 320), n):                      # nur die letzten ~3 Tage (reicht für alle Agenten)
            ret = s.c[i] / s.o[i] - 1.0
            rng_i = random.Random(seed * 1_000_003 + (s.ts[i] // INTERVAL_MS) * 17 + sum(map(ord, sym)))
            cur = max(base * 0.3, cur * (1.0 + 0.6 * abs(ret) * 10 * (1 if rng_i.random() < 0.62 else -1) + rng_i.gauss(0, 0.0015)))
            oi.append((s.ts[i], cur))
            look = max(0, i - 96)
            mom = (s.c[i] / s.c[look] - 1.0) * 8
            ls.append((s.ts[i], max(0.3, 1.0 + 0.6 * math.tanh(mom) + rng_i.gauss(0, 0.08))))
        mom4 = s.c[-1] / s.c[-5] - 1.0
        vol = max(1e-4, sum(abs(s.c[k] / s.c[k - 1] - 1) for k in range(n - 20, n)) / 20)
        imb = max(-0.9, min(0.9, math.tanh(0.5 * mom4 / vol) * 0.6 + rng.gauss(0, 0.2)))
        total = s.c[-1] * s.v[-1] * 6
        ob = {"mid": s.c[-1], "spread_bps": 1.0 + 8.0 * rng.random(), "imb_near": imb, "imb_far": 0.7 * imb + rng.gauss(0, 0.1),
              "bid_usd": total * (1 + imb) / 2, "ask_usd": total * (1 - imb) / 2, "depth_usd": total, "reach": 0.01,
              "wall_bid": {"dist": 0.002 + 0.004 * rng.random(), "rel": 1 + 8 * rng.random(), "usd": total * 0.2},
              "wall_ask": {"dist": 0.002 + 0.004 * rng.random(), "rel": 1 + 8 * rng.random(), "usd": total * 0.2},
              "depth_chg": rng.gauss(0, 0.2), "imb_chg": rng.gauss(0, 0.2)}
        out[sym] = SymExtra(ob, oi, ls)
    return out
