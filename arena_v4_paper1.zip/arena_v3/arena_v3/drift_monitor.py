"""
Drift-Monitor (V4): Feature-Drift (PSI), Regime-Drift, Kalibrierungs-Drift (Brier) und Netto-Performance-Drift.
Drift löst nur De-Rating, Pause oder Rollback aus - NIE eine Risikosteigerung (Faktoren sind immer <= 1).
"""
from __future__ import annotations

import math


def psi(expected: list, actual: list, bins: int = 10) -> float | None:
    """Population Stability Index; Bins aus den Quantilen der Referenz. >0.25 = deutlicher Drift."""
    if len(expected) < 50 or len(actual) < 30:
        return None
    srt = sorted(expected)
    edges = [srt[int(len(srt) * k / bins)] for k in range(1, bins)]

    def hist(v):
        c = [0] * bins
        for x in v:
            b = sum(1 for e in edges if x > e)
            c[b] += 1
        n = len(v)
        return [max(1e-4, k / n) for k in c]
    e, a = hist(expected), hist(actual)
    return sum((a[k] - e[k]) * math.log(a[k] / e[k]) for k in range(bins))


def dist_drift(expected: list, actual: list) -> float | None:
    """Verteilungsabstand (Total Variation) für Kategorien, z. B. Regime-Häufigkeiten."""
    if len(expected) < 50 or len(actual) < 30:
        return None
    cats = set(expected) | set(actual)
    return 0.5 * sum(abs(expected.count(c) / len(expected) - actual.count(c) / len(actual)) for c in cats)


class DriftMonitor:
    PSI_WARN, PSI_ALARM = 0.10, 0.25
    Z_PAUSE, Z_ROLLBACK = -2.0, -3.0

    def __init__(self, min_trades: int = 20):
        self.min_trades = min_trades

    def performance_z(self, ref_r: list, recent_r: list) -> float | None:
        """z-Wert der jüngsten mittleren Netto-R gegenüber der Referenz (negativ = schlechter)."""
        if len(ref_r) < self.min_trades or len(recent_r) < self.min_trades:
            return None
        mr = sum(ref_r) / len(ref_r)
        vr = sum((x - mr) ** 2 for x in ref_r) / max(1, len(ref_r) - 1)
        mc = sum(recent_r) / len(recent_r)
        se = math.sqrt(vr / len(recent_r) + 1e-12)
        return (mc - mr) / se

    def assess(self, feat_ref=None, feat_new=None, regime_ref=None, regime_new=None, brier_ref=None, brier_new=None,
               ref_r=None, recent_r=None, drawdown=None, max_drawdown=None) -> dict:
        flags, level = [], 0
        for name in (feat_ref or {}):
            v = psi(feat_ref[name], (feat_new or {}).get(name, []))
            if v is not None and v >= self.PSI_ALARM:
                flags.append(f"Feature-Drift {name} (PSI {v:.2f})"); level = max(level, 1)
            elif v is not None and v >= self.PSI_WARN:
                flags.append(f"Feature-Drift leicht {name} (PSI {v:.2f})")
        d = dist_drift(regime_ref or [], regime_new or [])
        if d is not None and d > 0.35:
            flags.append(f"Regime-Drift (TV {d:.2f})"); level = max(level, 1)
        if brier_ref is not None and brier_new is not None and brier_new > brier_ref * 1.2 + 0.01:
            flags.append(f"Kalibrierungs-Drift (Brier {brier_ref:.3f} -> {brier_new:.3f})"); level = max(level, 1)
        z = self.performance_z(ref_r or [], recent_r or [])
        if z is not None and z <= self.Z_PAUSE:
            flags.append(f"Performance-Drift (z={z:.1f})"); level = max(level, 2)
        if z is not None and z <= self.Z_ROLLBACK:
            level = max(level, 3)
        if drawdown is not None and max_drawdown is not None and drawdown > max_drawdown:
            flags.append(f"Drawdown {drawdown:.1%} > Limit {max_drawdown:.1%}"); level = 3
        action = ("ok", "derate", "pause", "rollback")[level]
        factor = {"ok": 1.0, "derate": 0.7, "pause": 0.0, "rollback": 0.0}[action]
        return {"action": action, "weight_factor": factor, "flags": flags, "perf_z": z}
