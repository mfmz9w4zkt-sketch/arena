"""
Meta-Agent / Contextual Bandit (V4) - NUR Shadow/Paper: liefert Gewichtsvorschläge je Kontext, greift aber nicht in Team-Entscheidungen ein.

  * Kontext   : Regime-Label (Trend/Volatilität) + Liquiditätsklasse.
  * Reward    : realisiertes Netto-R des Schattentrades (nach Kosten); verzögerter Reward wird über die Trade-ID dem
                Signal/Agenten und dem Kontext der ERÖFFNUNG zugeordnet (nicht dem Kontext beim Schließen).
  * Sicherheit: Mindeststichprobe, Posterior-Schrumpfung, Gewichtskappen, Cooldown nach Verlustserie, Exploration nur als Vorschlag.
  * Deterministisch: Zufall nur über Seeds aus (seed, Kontext, Bar) -> exakt reproduzierbares Replay.
"""
from __future__ import annotations

import math
import random


class ContextualBandit:
    def __init__(self, agents, seed=11, min_samples=20, w_min=0.2, w_max=1.6, shrink_k=20.0, cooldown_bars=48, streak=5):
        self.agents = list(agents)
        self.seed, self.min_samples, self.w_min, self.w_max = seed, min_samples, w_min, w_max
        self.shrink_k, self.cooldown_bars, self.streak = shrink_k, cooldown_bars, streak
        self.stats: dict = {}          # "ctx|agent" -> [n, sum, sum2]
        self.pending: dict = {}        # trade_id -> (ctx, agent)
        self.cooldown_until: dict = {}
        self.recent: dict = {}         # agent -> letzte Rewards

    @staticmethod
    def context(regime_label: str, liquidity: float) -> str:
        liq = "liq_hoch" if liquidity >= 0.7 else "liq_mittel" if liquidity >= 0.4 else "liq_niedrig"
        return f"{regime_label.split('/ungewoehnlich')[0]}|{liq}"

    def register(self, trade_id, agent, ctx):
        if agent in self.agents:
            self.pending[trade_id] = (ctx, agent)
            if len(self.pending) > 5000:
                for k in list(self.pending)[:1000]:
                    self.pending.pop(k, None)

    def reward(self, trade_id, r_net: float, bar: int = 0) -> bool:
        item = self.pending.pop(trade_id, None)
        if item is None:
            return False
        ctx, agent = item
        s = self.stats.setdefault(f"{ctx}|{agent}", [0, 0.0, 0.0])
        s[0] += 1; s[1] += r_net; s[2] += r_net * r_net
        rec = self.recent.setdefault(agent, [])
        rec.append(r_net)
        del rec[:-self.streak]
        if len(rec) == self.streak and all(x < 0 for x in rec):
            self.cooldown_until[agent] = bar + self.cooldown_bars
            self.recent[agent] = []
        return True

    def posterior(self, ctx, agent):
        n, s1, s2 = self.stats.get(f"{ctx}|{agent}", [0, 0.0, 0.0])
        if n == 0:
            return 0, 0.0, 1.0
        mean = s1 / n
        var = max(0.0, s2 / n - mean * mean)
        m = n * mean / (n + self.shrink_k)                      # Schrumpfung Richtung 0
        se = math.sqrt((var + 1.0) / (n + 1.0))
        return n, m, se

    def weights(self, ctx, bar=0, explore=False) -> dict:
        """Gewichtsvorschlag je Agent (Kappen w_min..w_max). explore=True: Thompson-Probe (nur Vorschlag, deterministisch je Seed/Kontext/Bar)."""
        rng = random.Random(f"{self.seed}:{ctx}:{bar}")
        out = {}
        for a in self.agents:
            n, m, se = self.posterior(ctx, a)
            if n < self.min_samples:
                w = 1.0                                          # zu wenig Daten: neutral, keine Abweichung
            else:
                est = (m + se * rng.gauss(0, 1)) if explore else (m - 1.28 * se)   # konservativ: untere Schranke
                w = 1.0 + 3.0 * est
            if bar < self.cooldown_until.get(a, -1):
                w = min(w, 0.5)
            out[a] = max(self.w_min, min(self.w_max, w))
        return out

    def to_dict(self):
        return {"stats": self.stats, "pending": {k: list(v) for k, v in self.pending.items()},
                "cooldown": self.cooldown_until, "recent": self.recent}

    def load_dict(self, d):
        if not isinstance(d, dict):
            return
        self.stats = {k: list(v) for k, v in d.get("stats", {}).items()}
        self.pending = {k: tuple(v) for k, v in d.get("pending", {}).items()}
        self.cooldown_until = dict(d.get("cooldown", {}))
        self.recent = {k: list(v) for k, v in d.get("recent", {}).items()}
