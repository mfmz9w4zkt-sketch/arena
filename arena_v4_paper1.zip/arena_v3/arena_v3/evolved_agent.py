"""Evolutionary + neural signal agent; only emits paper-trading signals."""
from __future__ import annotations
from .agents import Agent, Signal, NEUTRAL
from .evolution import RuleEvolution, TinyMLP
from . import model_validation as mv

HORIZON = 8                 # Label-Horizont (Kerzen)
ROUNDTRIP_COST = 0.0018     # grobe Netto-Kosten je Trade (2x Gebühr + Spread + Slippage) für die OOS-Edge-Prüfung


class EvolutionAgent(Agent):
    name, family, experimental = "Evolution-Neural", "evolution", True
    style = "Evolvierte Regel-DSL plus kleines neuronales Netz (matured labels, walk-forward-like split)"

    def __init__(self, params=None, seed=73):
        super().__init__(params)
        self.rules = RuleEvolution(seed)
        self.net = TinyMLP(seed)
        self.last_fit = -1
        self.train_samples = 0
        self.validation_accuracy = 0.0
        self.embargo = 4
        self.purge_report = {}
        self.val_metrics = {}        # V4: Brier, LogLoss, ECE, OOS-Netto-Edge + CI, Purge-Bericht

    def _features(self, m, sym, i):
        ca, c = m.cache[sym], m.s(sym).c[i]
        if i < 210 or c <= 0: return None
        roc8, roc32 = ca.roc(8)[i], ca.roc(32)[i]
        ema_gap = (ca.ema(24)[i] - ca.ema(96)[i]) / c
        rsi = (ca.rsi(14)[i] - 50.0) / 50.0
        macd = ca.macd()[i] / c
        vr = m.s(sym).v[i] / max(ca.vol_sma_prev(48)[i], 1e-9)
        return [max(-0.1,min(0.1,roc8)), max(-0.1,min(0.1,roc32)),
                max(-0.1,min(0.1,ema_gap)), max(-1,min(1,rsi)),
                max(-0.1,min(0.1,macd)), max(0,min(5,vr))/5.0]

    def _train(self, m, sym, i):
        horizon, start = HORIZON, max(210, i - 1400)
        # Nur Labels, deren gesamter Zukunftshorizont bereits beobachtbar ist.
        rows, idx = [], []
        closes = m.s(sym).c
        for j in range(start, i - horizon):
            x = self._features(m, sym, j)
            if x is None: continue
            ret = closes[j + horizon] / closes[j] - 1.0
            if abs(ret) < 0.0005: continue
            rows.append((x, 1.0 if ret > 0 else 0.0, ret)); idx.append(j)
        if len(rows) < 120: return
        # V4: chronologischer 80/20-Split MIT Purging + Embargo: kein Trainingslabel reicht in die Validierung hinein.
        cut = max(80, int(len(rows) * 0.8))
        tr_pos, va_pos, v0 = mv.purged_split(idx, cut, horizon, int(getattr(self, "embargo", 4)))
        if len(tr_pos) < 80: return
        train = [(rows[k][0], rows[k][1]) for k in tr_pos]
        valid = [rows[k] for k in va_pos]
        # Skalierung: feste, datenunabhängige Clamps (keine gelernten Normalisierungsstatistiken -> kein Fit außerhalb des Trainingsfensters).
        if not self.rules.evolve([(x, (y * 2 - 1) * 0.01) for x, y in train]): return
        self.net.fit(train)
        self.purge_report = {"v0": v0, "n_total": len(rows), "n_train": len(train), "n_purged": cut - len(tr_pos),
                             "overlap": mv.label_overlap([idx[k] for k in tr_pos], v0, horizon) if v0 is not None else 0}
        if valid:
            p = [self.net.predict(x) for x, _, _ in valid]
            y = [yy for _, yy, _ in valid]
            self.validation_accuracy = sum((pp >= 0.5) == bool(yy) for pp, yy in zip(p, y)) / len(valid)
            net = [(1 if pp >= 0.5 else -1) * r - ROUNDTRIP_COST for pp, (_, _, r) in zip(p, valid)]   # Netto-Ertrag je Trade
            lo, hi = mv.block_bootstrap_ci(net, block=HORIZON)
            self.val_metrics = {"n": len(valid), "accuracy": self.validation_accuracy, "brier": mv.brier(p, y),
                                "log_loss": mv.log_loss(p, y), "ece": mv.ece(p, y), "net_edge": sum(net) / len(net),
                                "net_edge_ci": [lo, hi], **self.purge_report}
        self.train_samples = len(rows)
        self.last_fit = i

    def _model_ok(self):
        """V4: Aktivierung nicht nur über Accuracy, sondern über Brier (besser als Münzwurf) und OOS-Netto-Edge."""
        v = self.val_metrics
        if not v:                                    # Altzustand ohne V4-Metriken: konservativ neutral
            return False
        return v["n"] >= 30 and v["brier"] < 0.25 and v["net_edge"] > 0 and self.validation_accuracy >= 0.51

    def state_dict(self):
        return {"genome": dict(self.rules.genome), "generation": self.rules.generation,
                "best_fitness": self.rules.best_fitness, "last_fit": self.last_fit,
                "train_samples": self.train_samples, "validation_accuracy": self.validation_accuracy, "val_metrics": self.val_metrics,
                "w1": self.net.w1, "b1": self.net.b1, "w2": self.net.w2,
                "b2": self.net.b2, "trained": self.net.trained}

    def load_state_dict(self, state):
        if not isinstance(state, dict): return
        genome = state.get("genome", {})
        if set(genome) == {"feature", "threshold", "direction", "min_edge"} and 0 <= int(genome["feature"]) < 6:
            self.rules.genome = {"feature": int(genome["feature"]), "threshold": float(genome["threshold"]),
                                 "direction": 1 if int(genome["direction"]) >= 0 else -1,
                                 "min_edge": max(0.0001, min(0.01, float(genome["min_edge"]))) }
        self.rules.generation = int(state.get("generation", 0))
        self.rules.best_fitness = float(state.get("best_fitness", -1e9))
        self.last_fit = int(state.get("last_fit", -1))
        self.train_samples = int(state.get("train_samples", 0))
        self.validation_accuracy = float(state.get("validation_accuracy", 0.0))
        self.val_metrics = state.get("val_metrics", {}) if isinstance(state.get("val_metrics", {}), dict) else {}
        try:
            if len(state["w1"]) == 8 and all(len(r) == 6 for r in state["w1"]):
                self.net.w1 = [[float(v) for v in r] for r in state["w1"]]
                self.net.b1 = [float(v) for v in state["b1"]]
                self.net.w2 = [float(v) for v in state["w2"]]
                self.net.b2 = float(state["b2"])
                self.net.trained = bool(state.get("trained", False))
        except (KeyError, TypeError, ValueError):
            self.net = TinyMLP(self.rules.seed)

    def signal(self, m, sym, i):
        x = self._features(m, sym, i)
        if x is None: return NEUTRAL
        if self.last_fit < 0 or i-self.last_fit >= 192:
            self._train(m, sym, i)
        if not self.net.trained or not self._model_ok():
            return NEUTRAL
        p_up = self.net.predict(x)
        g = self.rules.genome
        rule_value = x[g["feature"]]
        rule_dir = g["direction"] if rule_value > g["threshold"] else -g["direction"]
        if abs(rule_value) < g["min_edge"]: return NEUTRAL
        neural_dir = 1 if p_up >= 0.5 else -1
        # Agreement is mandatory: neural classifier cannot override evolved rule.
        if neural_dir != rule_dir or abs(p_up-0.5) < 0.08: return NEUTRAL
        ap = max(m.cache[sym].atr_pct_arr()[i], 1e-6)
        conf = min(0.78, 0.5 + abs(p_up-0.5)*0.8)
        return Signal(rule_dir, conf, ap*1.5, ap*2.0,
                      f"Evolution g{self.rules.generation}; NN p(up)={p_up:.2f}; val={self.validation_accuracy:.0%}")
