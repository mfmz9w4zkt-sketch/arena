"""
Agent Intelligence Layer.

Jeder Agent gibt je Handelspaar ein Signal ab: Richtung (+1 long, -1 short, 0 neutral), Confidence (0..1),
erwartete Bewegung (exp_ret, Bruchteil des Preises), geschätztes Risiko (risk, Stop-Abstand als Bruchteil) und eine Begründung.
Agenten eröffnen NICHT selbst Trades für das Team: eine zentrale Instanz (learning.SignalAggregator) wertet alle Signale aus.
Zusätzlich führt jeder Agent ein Schatten-Konto (system.py), damit seine echte Netto-Performance gemessen werden kann.
"""
from __future__ import annotations

import random
from collections import namedtuple

from .config import clamp_params
from .indicators import Cache
from .mtf import compute_mtf
from .regime import compute_regimes
from .structure import compute_structure

Signal = namedtuple("Signal", "dir conf exp_ret risk reason")
NEUTRAL = Signal(0, 0.0, 0.0, 0.0, "neutral")


class MarketCtx:
    """Alle Daten + Indikator-Caches + Regime-Arrays. Index i = zuletzt abgeschlossene Kerze."""

    def __init__(self, data: dict, extra: dict | None = None):
        self.data = data
        self.syms = list(data)
        self.cache = {s: Cache(data[s]) for s in self.syms}
        self.regime = {s: compute_regimes(self.cache[s]) for s in self.syms}
        self.ref = "BTCUSDT" if "BTCUSDT" in data else self.syms[0]
        self.extra = extra or {}              # Orderbuch-/Derivate-Daten (extras.SymExtra je Paar); leer im Backtest
        self._ret = {}
        self._cumx = {}
        self._cxy = {}
        self._rank = {}
        self._struct = {}
        self._mtf = {}

    def structure(self, sym):
        """Marktstruktur (Swings, BOS/CHoCH, FVG, Sweeps, Liquiditätspools), einmal je Paar berechnet."""
        if sym not in self._struct:
            self._struct[sym] = compute_structure(self.data[sym], self.cache[sym].atr_pct_arr())
        return self._struct[sym]

    def mtf(self, sym):
        """Trends auf 1h/4h/1d, aus den 15m-Kerzen zusammengesetzt (nur abgeschlossene höhere Kerzen)."""
        if sym not in self._mtf:
            self._mtf[sym] = compute_mtf(self.data[sym])
        return self._mtf[sym]

    def s(self, sym):
        return self.data[sym]

    def n(self):
        return len(self.data[self.ref])

    def returns(self, sym):
        if sym not in self._ret:
            c = self.data[sym].c
            self._ret[sym] = [0.0] + [c[i] / c[i - 1] - 1 for i in range(1, len(c))]
        return self._ret[sym]

    def _cums(self, sym):
        c = self._cumx.get(sym)
        if c is None:
            r = self.returns(sym)
            cx, cxx, sx, sxx = [0.0], [0.0], 0.0, 0.0
            for v in r:
                sx += v
                sxx += v * v
                cx.append(sx)
                cxx.append(sxx)
            c = self._cumx[sym] = (cx, cxx)
        return c

    def corr(self, a, b, i, w=96):
        """Rollierende Pearson-Korrelation der letzten w Kerzenrenditen; über Summen-Tabellen in O(1) je Abfrage."""
        if a == b:
            return 1.0
        if a > b:
            a, b = b, a
        lo = max(1, i - w + 1)
        m = i - lo + 1
        if m < 5:
            return 0.0
        pair = self._cxy.get((a, b))
        if pair is None:
            ra, rb = self.returns(a), self.returns(b)
            acc, pair = 0.0, [0.0]
            for x, y in zip(ra, rb):
                acc += x * y
                pair.append(acc)
            self._cxy[(a, b)] = pair
        ax, axx = self._cums(a)
        bx, bxx = self._cums(b)
        sx, sy = ax[i + 1] - ax[lo], bx[i + 1] - bx[lo]
        vx = (axx[i + 1] - axx[lo]) - sx * sx / m
        vy = (bxx[i + 1] - bxx[lo]) - sy * sy / m
        if vx <= 1e-18 or vy <= 1e-18:
            return 0.0
        return ((pair[i + 1] - pair[lo]) - sx * sy / m) / (vx * vy) ** 0.5

    def rank_info(self, i, n=96):
        """Rang (0 = schwächster) aller Paare nach Preisänderung der letzten n Kerzen; einmal je Kerze berechnet."""
        key = (i, n)
        r = self._rank.get(key)
        if r is None:
            order = sorted(self.syms, key=lambda x: self.cache[x].roc(n)[i])
            r = {x: k for k, x in enumerate(order)}
            if len(self._rank) > 64:
                self._rank.clear()
            self._rank[key] = r
        return r

    def rel_rank(self, sym, i, n=96):
        r = self.rank_info(i, n)
        return r[sym] / max(1, len(r) - 1)


def pearson(x, y):
    n = min(len(x), len(y))
    if n < 5:
        return 0.0
    mx, my = sum(x[:n]) / n, sum(y[:n]) / n
    sxx = sum((a - mx) ** 2 for a in x[:n])
    syy = sum((b - my) ** 2 for b in y[:n])
    if sxx <= 0 or syy <= 0:
        return 0.0
    return sum((a - mx) * (b - my) for a, b in zip(x[:n], y[:n])) / (sxx * syy) ** 0.5


STRONG_TREND = 3.0      # |EMA50-EMA200| in ATR: ab hier gilt ein Trend als stark (Gegenbewegungs-Agenten halten dann Abstand)


def against_strong_trend(r, d):
    """True, wenn ein Signal in Richtung d gegen einen starken Trend läuft (fallendes Messer / Rakete nicht fangen)."""
    return (d > 0 and r.trend == "down" and r.strength <= -STRONG_TREND) or (d < 0 and r.trend == "up" and r.strength >= STRONG_TREND)


class Agent:
    name = "Agent"
    family = "generic"
    in_team = True
    batch = False
    experimental = False      # True: startet auf Bewährung (Teamgewicht max. 0,3), bis genug Netto-Ergebnisse vorliegen
    # Vorwissen, wie gut eine Strategie-Familie zu einer Marktphase passt (nur Startwert, wird durch Lernen überstimmt)
    affinity = {"up": 1.0, "down": 1.0, "range": 1.0}
    style = ""

    def __init__(self, params=None):
        self.p = clamp_params(params)

    def signal(self, m: MarketCtx, sym: str, i: int) -> Signal:
        raise NotImplementedError

    @staticmethod
    def _basic(m, sym, i):
        ca = m.cache[sym]
        return ca, m.s(sym).c[i], max(ca.atr_pct_arr()[i], 1e-6)


class MomentumAgent(Agent):
    name, family = "Momentum", "trend"
    affinity = {"up": 1.2, "down": 1.2, "range": 0.6}
    style = "Trendhandel mit EMA-Abstand, ROC und MACD"

    def signal(self, m, sym, i):
        if i < 130:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        gap = (ca.ema(p["mom.ema_fast"])[i] - ca.ema(p["mom.ema_slow"])[i]) / c / ap
        r = ca.roc(p["mom.roc_n"])[i] / ap
        mh = ca.macd()[i]
        d = 1 if gap > p["mom.min_gap"] and r > 0 and mh > 0 else -1 if gap < -p["mom.min_gap"] and r < 0 and mh < 0 else 0
        if not d:
            return NEUTRAL
        rs = ca.rsi(14)[i]
        if (d > 0 and rs > 82) or (d < 0 and rs < 18):          # Erschöpfung: hinterherlaufen nach schon extremer Bewegung vermeiden
            return NEUTRAL
        conf = min(1.0, 0.4 + 0.2 * min(abs(gap), 2.0) + 0.08 * min(abs(r), 3.0))
        return Signal(d, conf, ap * (1.0 + 2.0 * conf), 2 * ap, f"EMA-Abstand {gap:.2f} ATR, ROC {r:.2f} ATR")


class MeanReversionAgent(Agent):
    name, family = "Mean Reversion", "meanrev"
    affinity = {"up": 0.7, "down": 0.7, "range": 1.3}
    style = "Gegenbewegung bei RSI-Extremen und Bollinger-Rand"

    def signal(self, m, sym, i):
        if i < 130:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        n = p["mr.bb_n"]
        mid, sd = ca.sma(n)[i], ca.std(n)[i]
        if sd <= 0:
            return NEUTRAL
        z, rs = (c - mid) / sd, ca.rsi(14)[i]
        d = 1 if rs < p["mr.rsi_low"] and z < -p["mr.bb_k"] else -1 if rs > p["mr.rsi_high"] and z > p["mr.bb_k"] else 0
        if not d:
            return NEUTRAL
        reg = m.regime[sym][i]
        if against_strong_trend(reg, d):
            return NEUTRAL
        conf = min(1.0, 0.4 + 0.15 * (abs(z) - p["mr.bb_k"]) + 0.01 * abs(rs - 50))
        if reg.trend != "range" and reg.trend != ("up" if d > 0 else "down"):
            conf *= 0.85                                          # gegen einen (schwächeren) Trend: weniger Überzeugung
        return Signal(d, conf, max(abs(mid - c) / c * 0.6, ap * 0.8), 1.5 * ap, f"z={z:.2f}, RSI {rs:.0f}")


class BreakoutAgent(Agent):
    name, family = "Breakout", "breakout"
    affinity = {"up": 1.1, "down": 1.1, "range": 0.8}
    style = "Ausbruch aus der Donchian-Spanne mit Volumenbestätigung"

    def signal(self, m, sym, i):
        if i < 130:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        s = m.s(sym)
        vr = s.v[i] / max(ca.vol_sma_prev(48)[i], 1e-9)
        hi, lo = ca.hi_prev(p["bo.lookback"])[i], ca.lo_prev(p["bo.lookback"])[i]
        buf = 0.1 * ap * c
        d = 1 if c > hi + buf and vr > p["bo.vol_mult"] else -1 if c < lo - buf and vr > p["bo.vol_mult"] else 0
        if not d:
            return NEUTRAL
        rng_ = s.h[i] - s.l[i]
        pos = (c - s.l[i]) / rng_ if rng_ > 0 else 0.5
        if (d > 0 and pos < 0.65) or (d < 0 and pos > 0.35):    # Schluss nicht nahe dem Kerzenextrem: oft ein falscher Ausbruch (langer Docht)
            return NEUTRAL
        if m.regime[sym][i].unusual:                              # Nachrichten-Spitzen laufen häufig sofort zurück
            return NEUTRAL
        conf = min(1.0, 0.45 + 0.2 * (vr - p["bo.vol_mult"]))
        return Signal(d, conf, ap * (1.5 + conf * 2), 2 * ap, f"Ausbruch, Volumen x{vr:.1f}")


class TrendFollowerAgent(Agent):
    name, family = "Trendfolger", "trend"
    affinity = {"up": 1.3, "down": 1.3, "range": 0.5}
    style = "Langsamer Trend (EMA 80/200 auf 15m ~ 20/50 auf 1h)"

    def signal(self, m, sym, i):
        if i < 210:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        gap = (ca.ema(p["tf.fast"])[i] - ca.ema(p["tf.slow"])[i]) / c / ap
        if abs(gap) < p["tf.min_gap"] or m.regime[sym][i].vol == "extreme":
            return NEUTRAL
        d = 1 if gap > 0 else -1
        conf = min(1.0, 0.4 + 0.2 * abs(gap))
        return Signal(d, conf, ap * 2.5, 2.5 * ap, f"Trend-Abstand {gap:.2f} ATR")


class ScalperAgent(Agent):
    name, family = "Scalper", "scalp"
    affinity = {"up": 1.0, "down": 1.0, "range": 1.0}
    style = "Kurzfristige Bewegung mit Volumenspitze (hohe Kostenbelastung)"

    def signal(self, m, sym, i):
        if i < 130:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        r = ca.roc(p["sc.roc_n"])[i] / ap
        vr = m.s(sym).v[i] / max(ca.vol_sma_prev(48)[i], 1e-9)
        if abs(r) < 1.2 or vr < p["sc.vol_mult"]:
            return NEUTRAL
        if ap < 0.003 or m.regime[sym][i].unusual:                 # zu ruhig: Gebühren und Spread fressen den Gewinn / Nachrichtenspitze
            return NEUTRAL
        d = 1 if r > 0 else -1
        s = m.s(sym)
        pos = (c - s.l[i]) / (s.h[i] - s.l[i]) if s.h[i] > s.l[i] else 0.5
        if (d > 0 and pos < 0.7) or (d < 0 and pos > 0.3):         # Schluss nicht am Kerzenextrem: Bewegung schon verpufft
            return NEUTRAL
        return Signal(d, min(0.7, 0.45 + 0.05 * abs(r)), ap * 0.9, ap, f"ROC {r:.1f} ATR, Vol x{vr:.1f}")


class ContrarianAgent(Agent):
    name, family = "Contrarian", "meanrev"
    affinity = {"up": 0.8, "down": 0.8, "range": 1.2}
    style = "Gegen extreme Bewegungen"

    def signal(self, m, sym, i):
        if i < 130:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        r = ca.roc(p["co.roc_n"])[i] / ap
        if abs(r) < p["co.k"] * 1.5:
            return NEUTRAL
        d = -1 if r > 0 else 1
        reg = m.regime[sym][i]
        if against_strong_trend(reg, d):
            return NEUTRAL
        conf = min(0.85, 0.4 + 0.05 * (abs(r) - p["co.k"] * 1.5))
        if reg.trend != "range" and reg.trend != ("up" if d > 0 else "down"):
            conf *= 0.85
        return Signal(d, conf, ap * 1.5, 1.5 * ap, f"Extrem {r:.1f} ATR")


class CautiousAgent(Agent):
    name, family = "Vorsichtig", "trend"
    affinity = {"up": 1.1, "down": 1.0, "range": 0.8}
    style = "Nur Setups mit Trend + Momentum + neutralem RSI + ruhiger Volatilität"

    def signal(self, m, sym, i):
        if i < 210:
            return NEUTRAL
        p = self.p
        ca, c, ap = self._basic(m, sym, i)
        e48, e200 = ca.ema(48)[i], ca.ema(200)[i]
        rs, mh = ca.rsi(14)[i], ca.macd()[i]
        if m.regime[sym][i].vol_pct > p["ca.max_vol_pct"]:
            return NEUTRAL
        if c > e48 > e200 and mh > 0 and p["ca.rsi_min"] <= rs <= p["ca.rsi_max"]:
            return Signal(1, 0.8, ap * 2.2, 2 * ap, "Trend, MACD, RSI neutral, ruhig")
        if c < e48 < e200 and mh < 0 and 100 - p["ca.rsi_max"] <= rs <= 100 - p["ca.rsi_min"]:
            return Signal(-1, 0.8, ap * 2.2, 2 * ap, "Trend, MACD, RSI neutral, ruhig")
        return NEUTRAL


class DiversifierAgent(Agent):
    name, family = "Diversifizierer", "relstrength"
    affinity = {"up": 1.1, "down": 1.0, "range": 0.8}
    style = "Relative Stärke: stärkster Coin long, schwächster short (mit Trendfilter)"

    def signal(self, m, sym, i):
        if i < 210 or len(m.syms) < 3:
            return NEUTRAL
        ca, c, ap = self._basic(m, sym, i)
        n = len(m.syms)
        pos = m.rank_info(i, 96)[sym]                               # 0 = schwächster, n-1 = stärkster
        k = max(2, round(0.1 * n))                                  # oberste/unterste ~10 % (bei 6 Coins: 2, bei 50 Coins: 5)
        e96 = ca.ema(96)[i]
        rk = pos / max(1, n - 1)
        if pos >= n - k and c > e96:
            return Signal(1, min(0.75, 0.55 + 0.2 * (pos - (n - k) + 1) / k), ap * 1.8, 2 * ap, f"relative Stärke {rk:.2f} (Platz {n - pos} von {n})")
        if pos < k and c < e96:
            return Signal(-1, min(0.75, 0.55 + 0.2 * (k - pos) / k), ap * 1.8, 2 * ap, f"relative Schwäche {rk:.2f} (Platz {pos + 1} von unten)")
        return NEUTRAL


class RuleEMAAgent(Agent):
    name, family = "Regelbot EMA", "trend"
    style = "Einfacher Vergleichsbot (feste Parameter, keine Optimierung)"

    def signal(self, m, sym, i):
        if i < 210:
            return NEUTRAL
        ca, c, ap = self._basic(m, sym, i)
        gap = (ca.ema(80)[i] - ca.ema(200)[i]) / c
        if abs(gap) < 0.0015:
            return NEUTRAL
        return Signal(1 if gap > 0 else -1, 0.5, ap * 2.0, 2 * ap, f"EMA80/200-Abstand {gap * 100:.2f}%")


class RandomAgent(Agent):
    """Zufalls-Baseline (deterministisch). Zählt NICHT zum Team, läuft aber als Schatten-Konto zum Vergleich."""
    name, family, in_team = "Zufall", "random", False
    style = "Würfelt - wer das nicht schlägt, hat keinen Vorteil"

    def __init__(self, params=None, seed=42):
        super().__init__(params)
        self.seed = seed

    def signal(self, m, sym, i):
        rng = random.Random(self.seed * 1_000_003 + i * 97 + sum(map(ord, sym)))
        x = rng.random()
        if x > 0.03:
            return NEUTRAL
        ap = max(m.cache[sym].atr_pct_arr()[i], 1e-6)
        return Signal(1 if rng.random() < 0.5 else -1, 0.5, ap * 1.5, 2 * ap, "Würfel")


AGENT_CLASSES = [MomentumAgent, MeanReversionAgent, BreakoutAgent, TrendFollowerAgent, ScalperAgent,
                 ContrarianAgent, CautiousAgent, DiversifierAgent, RuleEMAAgent, RandomAgent]


def build_agents(params=None, seed=42):
    from .agents_ext import EXT_AGENT_CLASSES            # Agenten 11-15 (Orderbuch, Derivate, Liquidation, Struktur, Multi-Timeframe)
    out = []
    for cls in AGENT_CLASSES:
        out.append(cls(params, seed) if cls is RandomAgent else cls(params))
    for cls in EXT_AGENT_CLASSES:
        out.append(cls(params))
    # Evolutionary strategy is isolated on probation and cannot bypass risk controls.
    from .evolved_agent import EvolutionAgent
    out.append(EvolutionAgent(params, seed + 73))
    return out
