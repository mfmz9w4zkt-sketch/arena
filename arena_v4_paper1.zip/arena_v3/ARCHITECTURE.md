# Architektur KI-Trading-Arena V3

Alle 15 Komponenten sind als Module in `arena_v3/` umgesetzt:

| # | Komponente | Datei | Aufgabe |
|---|---|---|---|
| 1 | Market Data Engine | `data.py` | Binance-Client (Timeout, Retry, Host-Fallback), Validierung, Historien-Download, Demo-Generator |
| 2 | Market Regime Detector | `regime.py` | Trend (auf/ab/seitwärts), Volatilität (niedrig..extrem), ungewöhnlich, schnelle Bewegung - kausal |
| 3 | Agent Intelligence Layer | `agents.py`, `agents_ext.py`, `mtf.py`, `structure.py`, `extras.py`, `llm_agents.py` | 15 Regel-Agenten (+ optionale Claude-Agenten); Signal = Richtung, Confidence, erwarteter Gewinn, Risiko, Begründung |
| 4 | Signal Aggregator | `learning.py` | zentrale Entscheidung: Gewichtung, Konflikt, Korrelationsabzug, Marktfilter |
| 5 | Meta-Learner | `learning.py` | R-Multiple-Statistik der Schatten-Konten, Shrinkage, Konfidenzgrenze, Halbwertszeit, Deaktivierung/Bewährung |
| 6 | Strategy Optimizer | `optimizer.py` | Optuna oder eingebaute Suche; Score = Rendite, PF, Sharpe, Sortino, Drawdown, Liquidationen, Stabilität |
| 7 | Backtesting Engine | `backtest.py` | derselbe Code wie live, reproduzierbar |
| 8 | Walk-forward Validator | `backtest.py` | Train/Test-Fenster, verkettete Out-of-sample-Kurve, Robustheitsprüfung |
| 9 | Champion-Challenger Manager | `champion.py` | Zulassung nur nach robustem WF, Beförderung nach Vorwärtstest, Rollback |
| 10 | Portfolio Manager | `system.py`, `sim.py` | Team-Konto + Schatten-Konten, Positionen, Korrelation |
| 11 | Risk Management Engine | `risk.py` | Hard Limits, Größenberechnung, Hebel-Manager, Liquidationsschutz, Notfall |
| 12 | Execution Simulator | `sim.py` | Gebühren, Slippage, Funding, Gaps, Isolated Margin, Liquidation |
| 13 | Performance Analytics | `analytics.py` | Netto-Rendite, PF, Sharpe, Sortino, MaxDD, Phasen-Auswertung |
| 14 | Persistent Database | `db.py` | SQLite: Kerzen, Trades, Orders, Equity, Ereignisse, Lernzyklen, Optimierungen, Parameter, Zustand |
| 15 | Dashboard | `dashboard.py`, `web/` | Web-Oberfläche (`web/index.html`, `web/login.html`) + JSON-API + Login mit Sitzungs-Cookie |

## Ablauf je Kerze (`system.py`)
1. Aufträge der Vorkerze zum Eröffnungskurs (Slippage, Risiko-Freigabe, Schutz vor Doppel-Orders)
2. Kerze verarbeiten: Funding, Gaps, Stop-Loss, Liquidation, Take-Profit, Trailing
3. Tages-/Wochen-/Gesamtlimits, Notfall; Tod bei Geld = 0
4. Agenten-Signale (nur Daten bis zur Kerze)
5. Schatten-Konten und zentrale Team-Entscheidung -> neue Aufträge (Ausführung erst bei der nächsten Kerze)
6. Lernzyklus (Gewichte) im festen Takt

## Zwei Systeme parallel (Live-Paper)
Champion und Challenger laufen als getrennte `TradingSystem`-Instanzen (eigene Konten, eigene Lerndaten). Optimierung läuft im
Hintergrund (alle 24 h); der Challenger wird nur zugelassen, wenn der Walk-forward robust ist.


## Evolution / neuronales Lernen
`evolved_agent.py` bindet `evolution.py` als experimentellen Agenten ein. Der genetische Operator verändert nur ein festes Regel-Genom; dynamische Quellcode-Ausführung ist bewusst ausgeschlossen. `TinyMLP` lernt die Richtung der 8-Kerzen-Bewegung aus sechs kausalen Features. Trainingsbeispiele werden erst nach Ablauf des Horizonts freigegeben, und die letzten 20 % der zeitlich sortierten Samples dienen als Validierungssegment. Die Modellparameter werden im `TradingSystem`-Snapshot persistiert.
