# V4 Architektur
Entscheidungsfluss je Kerze: Daten -> Features/Regime (+Wahrscheinlichkeiten, Hysterese) -> Agenten (Schattenkonten laufen immer) -> Aggregator (Gewicht = gelernt x Nutzer-Stimmrecht x Diversität; Schwellen = Parameter x Aktivität) -> **Trade Quality Gate** (konservative Netto-Edge) -> **Portfolio Guardian** (Cluster/Beta, nur Verkleinerung) -> **Risk Engine** (unabhängiges Veto, Profil SAFE) -> Paper-Ausführung -> Attribution/Lernen (Learner + Meta-Bandit nur Shadow).

| Modul | Aufgabe |
|---|---|
| `controls.py` | Nutzer: Stimmrecht 0-200 %, Ein/Aus, Aktivität 1-5, Gate streng/beobachtend, Auto-Hebel + manuelle Hebel-Obergrenze je Agent |
| `trade_quality.py` | p_win, EV, Kosten (Gebühren, Spread, Slippage, Impact, Funding), Unsicherheit; fehlende Daten -> Ablehnung |
| `portfolio.py` | korrelationsgewichtete Cluster, Netto-Beta, Skala <= 1 |
| `regime_prob.py` | Zustände inkl. unknown/stress, geglättet + Mindestdauer |
| `meta_agent.py` | Contextual Bandit, nur Vorschläge, verzögerter Reward, Kappen, Replay-deterministisch |
| `contribution.py` | Ablation je Agent, Vorschläge (nie automatisch) |
| `drift_monitor.py` | PSI, Regime-, Kalibrierungs-, Performance-Drift; nur Derate/Pause/Rollback |
| `model_validation.py` | Purging, Brier/LogLoss/ECE, Block-Bootstrap, Deflated Sharpe, Promotion-Status |

Nicht verhandelbar: Paper-only, kein Live-Code, Profil nur per Startparameter, Nutzer/Optimierer/Agenten können Limits nicht lockern. Hebel: Obergrenze je Agent = min(Nutzer/Auto-Stufe, Tier der Risk Engine, Profil).
