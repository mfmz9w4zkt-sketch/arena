import unittest
from arena_v3.evolution import RuleEvolution, TinyMLP
from arena_v3.config import Config
from arena_v3.system import TradingSystem


class EvolutionTests(unittest.TestCase):
    def _rows(self):
        rows = []
        for i in range(240):
            x = [(i % 11 - 5) / 100, (i % 17 - 8) / 100, (i % 7 - 3) / 100,
                 (i % 9 - 4) / 4, (i % 13 - 6) / 100, (i % 5) / 5]
            y = 1.0 if x[0] + x[1] > 0 else 0.0
            rows.append((x, y))
        return rows

    def test_neural_model_trains_and_predicts_probability(self):
        rows = self._rows()
        net = TinyMLP()
        self.assertTrue(net.fit(rows))
        self.assertGreaterEqual(net.predict(rows[-1][0]), 0.0)
        self.assertLessEqual(net.predict(rows[-1][0]), 1.0)

    def test_rule_genome_evolves_within_bounded_dsl(self):
        rows = self._rows()
        evo = RuleEvolution()
        self.assertTrue(evo.evolve([(x, (y * 2 - 1) * 0.01) for x, y in rows]))
        self.assertIn(evo.genome["feature"], range(6))
        self.assertIn(evo.genome["direction"], (-1, 1))
        self.assertGreaterEqual(evo.genome["threshold"], -0.05)
        self.assertLessEqual(evo.genome["threshold"], 0.05)

    def test_agent_and_model_state_are_persisted(self):
        system = TradingSystem("evolution-test", Config(symbols=("BTCUSDT",)))
        self.assertIn("Evolution-Neural", system.am)
        snapshot = system.to_dict()
        self.assertIn("Evolution-Neural", snapshot["evolution"])
        system.load_dict(snapshot)


if __name__ == "__main__":
    unittest.main()
