"""V4-Tests (deterministisch, offline, synthetische Daten). Ergänzen die unveränderte Legacy-Suite tests/test_v3.py."""
import dataclasses
import json
import math
import os
import tempfile
import threading
import time
import unittest
import urllib.request

from arena_v3 import model_validation as mv
from arena_v3 import trade_quality
from arena_v3.agents import MarketCtx, build_agents
from arena_v3.app import ArenaApp
from arena_v3.backtest import run_backtest, evaluate_oos
from arena_v3.champion import ChampionChallenger
from arena_v3.config import (EXTENDED_PAPER, Config, HARD, SAFE_LIMITS, LIVE_TRADING_IMPLEMENTED, DEFAULT_SYMBOLS, clamp_params, limits_for)
from arena_v3.contribution import suggest_influence
from arena_v3.controls import UserControls
from arena_v3.dashboard import build_state, serve
from arena_v3.data import generate_synthetic, Series, Candle
from arena_v3.drift_monitor import DriftMonitor, psi
from arena_v3.evolved_agent import EvolutionAgent
from arena_v3.meta_agent import ContextualBandit
from arena_v3.portfolio import PortfolioGuardian
from arena_v3.regime import Regime
from arena_v3.regime_prob import regime_probs, RegimeTracker, STATES
from arena_v3.risk import RiskEngine
from arena_v3.sim import ExecutionSimulator, Account
from arena_v3.system import TradingSystem

CFG = Config(symbols=DEFAULT_SYMBOLS[:3])


def data(n=1500, seed=3, k=3):
    return generate_synthetic(list(DEFAULT_SYMBOLS[:k]), n, seed=seed)


# ----------------------------------------------------------------------------- Risiko-Invarianten
class V4_Risiko_Invarianten(unittest.TestCase):
    def test_standard_ist_safe_paper(self):
        c = Config()
        self.assertEqual(c.risk_profile, "safe")
        self.assertEqual(limits_for(c), SAFE_LIMITS)
        self.assertFalse(c.experimental_high_leverage)
        self.assertFalse(LIVE_TRADING_IMPLEMENTED)

    def test_erweitertes_profil_hoeher_als_safe_aber_unter_hard(self):
        l = limits_for(dataclasses.replace(Config(), risk_profile="extended_paper"))
        self.assertEqual(l, EXTENDED_PAPER)
        self.assertGreater(l.max_daily_loss, SAFE_LIMITS.max_daily_loss)
        self.assertGreater(l.max_total_drawdown, SAFE_LIMITS.max_total_drawdown)
        self.assertGreater(l.max_risk_per_trade, SAFE_LIMITS.max_risk_per_trade)
        for f in ("max_leverage", "max_risk_per_trade", "max_daily_loss", "max_weekly_loss", "max_total_drawdown", "max_open_positions"):
            self.assertLessEqual(getattr(l, f), getattr(HARD, f))

    def test_risikoprofil_nicht_per_konfigdatei_lockerbar(self):
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            json.dump({"risk_profile": "aggressive_paper", "activity": 4}, f)
        try:
            c = Config.load(f.name)
        finally:
            os.unlink(f.name)
        self.assertEqual(c.risk_profile, "safe")          # Profil-Schlüssel aus Datei wird ignoriert
        self.assertEqual(c.activity, 4)                   # andere Schlüssel gelten

    def test_unbekanntes_profil_faellt_auf_safe_und_alles_ist_durch_hard_begrenzt(self):
        lim = limits_for(dataclasses.replace(Config(), risk_profile="irgendwas"))
        self.assertEqual(lim, SAFE_LIMITS)
        for prof in ("safe", "aggressive_paper"):
            l = limits_for(dataclasses.replace(Config(), risk_profile=prof))
            self.assertLessEqual(l.max_leverage, HARD.max_leverage)
            self.assertLessEqual(l.max_risk_per_trade, HARD.max_risk_per_trade)
            self.assertLessEqual(l.max_daily_loss, HARD.max_daily_loss)
            self.assertLessEqual(l.max_open_positions, HARD.max_open_positions)
            self.assertGreaterEqual(l.min_liq_safety_mult, HARD.min_liq_safety_mult)

    def test_parameter_optimierer_und_nutzer_koennen_limits_nicht_lockern(self):
        ex = ExecutionSimulator(CFG)
        rk = RiskEngine(CFG, ex)
        p = clamp_params({"lev.cap": 125, "team.risk_frac": 0.05})
        lim = rk.limits(p)
        self.assertLessEqual(lim.max_lev, SAFE_LIMITS.max_leverage)
        self.assertLessEqual(lim.risk_trade, SAFE_LIMITS.max_risk_per_trade)
        uc = UserControls(["A"])
        uc.set_agent("A", influence=999)
        uc.set_activity(99)
        self.assertEqual(rk.limits(p), lim)                # Nutzersteuerung ändert Risiko-Limits nicht

    def test_system_hebel_und_positionen_bleiben_im_safe_profil(self):
        d = data(1400, 5)
        r = run_backtest(d, dataclasses.replace(CFG, activity=5, gate_enabled=False, guard_enabled=False), None, start=400, end=1400, keep_system=True)
        s = r["system"]
        for t in s.team_closed:
            self.assertLessEqual(t.lev, SAFE_LIMITS.max_leverage)
        self.assertLessEqual(max(len(a.positions) for a in [s.team] + list(s.shadow.values())), SAFE_LIMITS.max_open_positions)


# ----------------------------------------------------------------------------- Purging / Leakage
class V4_Purging_und_Leakage(unittest.TestCase):
    def test_purged_split_kein_label_reicht_in_validierung(self):
        idx = list(range(300, 700))
        cut = 320
        tr, va, v0 = mv.purged_split(idx, cut, horizon=8, embargo=4)
        self.assertEqual(mv.label_overlap([idx[k] for k in tr], v0, 8), 0)
        self.assertTrue(all(idx[k] + 8 + 4 < v0 for k in tr))                 # Embargo eingehalten
        self.assertEqual(len(tr), cut - 12)                                    # Horizont 8 + Embargo 4 = 12 Beispiele entfernt
        naive = list(range(cut))
        self.assertGreater(mv.label_overlap([idx[k] for k in naive], v0, 8), 0)  # der naive Split WÜRDE leaken

    def test_purged_split_mit_luecken_im_index(self):
        idx = [300, 301, 305, 306, 310, 311, 312, 320, 321, 330]               # herausgefilterte Zeilen (|ret| zu klein)
        tr, va, v0 = mv.purged_split(idx, 7, horizon=8, embargo=0)
        self.assertEqual(v0, 320)
        self.assertEqual(mv.label_overlap([idx[k] for k in tr], v0, 8), 0)

    def test_evolution_agent_training_ohne_ueberlappung_und_mit_metriken(self):
        d = data(2200, 7, k=2)
        m = MarketCtx(d)
        ag = EvolutionAgent()
        sym = list(d)[0]
        ag._train(m, sym, 1800)
        if ag.last_fit < 0:
            self.skipTest("Training nicht ausgeführt (zu wenig Zeilen)")
        self.assertEqual(ag.purge_report["overlap"], 0)
        self.assertGreater(ag.purge_report["n_purged"], 0)
        for k in ("brier", "log_loss", "ece", "net_edge", "net_edge_ci", "accuracy", "n"):
            self.assertIn(k, ag.val_metrics)

    def test_evolution_agent_ohne_v4_metriken_bleibt_neutral(self):
        d = data(1200, 8, k=1)
        ag = EvolutionAgent()
        ag.net.trained = True
        ag.validation_accuracy = 0.9                       # hohe Accuracy allein reicht NICHT
        ag.last_fit = 1000
        self.assertFalse(ag._model_ok())
        ag.val_metrics = {"n": 100, "brier": 0.24, "net_edge": -0.001}
        self.assertFalse(ag._model_ok())                   # negative OOS-Netto-Edge -> neutral
        ag.val_metrics = {"n": 100, "brier": 0.24, "net_edge": 0.001}
        self.assertTrue(ag._model_ok())

    def test_zukunftsdaten_veraendern_vergangene_signale_nicht(self):
        d = data(900, 9, k=3)
        i = 700
        cut = {s: Series.from_rows(s, [[x.ts[j], x.o[j], x.h[j], x.l[j], x.c[j], x.v[j]] for j in range(i + 1)]) if hasattr(Series, "from_rows") else x.slice(0, i + 1) for s, x in d.items()}
        # zweite Variante: gleiche Historie, aber manipulierte Zukunft
        fut = {}
        for s, x in d.items():
            y = x.slice(0, len(x))
            for j in range(i + 1, len(y)):
                y.c[j] *= 1.5; y.h[j] *= 1.5; y.l[j] *= 1.5; y.o[j] *= 1.5
            fut[s] = y
        m1, m2 = MarketCtx({s: x.slice(0, i + 1) for s, x in d.items()}), MarketCtx(fut)
        for a in build_agents(clamp_params(None), 42):
            if a.batch or a.name in ("Evolution-Neural",):
                continue
            for s in d:
                self.assertEqual(tuple(a.signal(m1, s, i)[:4]), tuple(a.signal(m2, s, i)[:4]), a.name)
        for s in d:
            self.assertEqual(m1.regime[s][i], m2.regime[s][i])


# ----------------------------------------------------------------------------- Optimierer-Parität / Promotion
class V4_Optimierer_Paritaet(unittest.TestCase):
    def test_standard_optimierung_nutzt_volle_produktionslogik(self):
        from arena_v3 import optimizer
        self.assertFalse(optimizer.is_screening(Config()))
        self.assertTrue(optimizer.is_screening(Config(opt_light=True)))
        self.assertTrue(optimizer.is_screening(Config(opt_screening=True)))

    def test_objective_reicht_shadow_wie_walkforward_durch(self):
        from arena_v3 import optimizer, backtest
        seen = []
        orig = backtest.run_backtest

        def spy(*a, **k):
            seen.append(k.get("shadow"))
            return orig(*a, **k)
        backtest.run_backtest = spy
        try:
            d = data(900, 4, k=2)
            ctx = MarketCtx(d)
            c = dataclasses.replace(CFG, opt_segments=1, symbols=tuple(d))
            optimizer.objective(ctx, c, clamp_params(None), 500, 900, burn=100)
            optimizer.objective(ctx, dataclasses.replace(c, opt_screening=True), clamp_params(None), 500, 900, burn=100)
        finally:
            backtest.run_backtest = orig
        self.assertEqual(seen, [True, False])              # voll = mit Schattenkonten; Screening = ohne

    def test_screening_und_inconclusive_duerfen_nicht_befoerdern(self):
        cc = ChampionChallenger(Config())
        base = {"robust": True, "checks": {}, "positive_fold_fraction": 1.0,
                "metrics": {k: 1 for k in ("net_return", "profit_factor", "sharpe", "sortino", "max_drawdown", "trades")}}
        self.assertFalse(cc.propose({"mom.ema_fast": 9}, dict(base, screening=True))["accepted"])
        self.assertFalse(cc.propose({"mom.ema_fast": 9}, dict(base, status="inconclusive"))["accepted"])
        self.assertTrue(cc.propose({"mom.ema_fast": 9}, dict(base, status="conclusive", screening=False))["accepted"])

    def test_oos_status_inconclusive_bei_wenigen_trades(self):
        d = data(1500, 3)
        r = run_backtest(d, CFG, None, start=400, end=1500)
        rep = evaluate_oos([r], CFG)
        self.assertEqual(rep["status"], "inconclusive")       # weit unter 300 OOS-Trades
        self.assertIn("trade_stats", rep)

    def test_deflated_sharpe_sinkt_mit_der_zahl_der_varianten(self):
        a = mv.deflated_sharpe(0.2, 250, 1)
        b = mv.deflated_sharpe(0.2, 250, 200)
        self.assertGreater(a, b)
        self.assertEqual(mv.promotion_status(100, 300)["status"], "inconclusive")
        self.assertEqual(mv.promotion_status(400, 300)["status"], "conclusive")
        self.assertEqual(mv.promotion_status(400, 300, screening=True)["status"], "screening")
        self.assertEqual(mv.promotion_status(400, 300, leakage_findings=1)["status"], "blocked")


class V4_Metriken(unittest.TestCase):
    def test_brier_logloss_ece(self):
        self.assertAlmostEqual(mv.brier([1.0, 0.0], [1, 0]), 0.0)
        self.assertAlmostEqual(mv.brier([0.5, 0.5], [1, 0]), 0.25)
        self.assertAlmostEqual(mv.log_loss([0.5, 0.5], [1, 0]), math.log(2), places=6)
        self.assertAlmostEqual(mv.ece([0.9] * 10, [1] * 9 + [0]), 0.0, places=6)
        self.assertGreater(mv.ece([0.9] * 10, [1] * 5 + [0] * 5), 0.3)

    def test_block_bootstrap_deterministisch(self):
        v = [0.1, -0.2, 0.3, 0.05, -0.1, 0.2, 0.15, -0.05, 0.25, 0.1]
        self.assertEqual(mv.block_bootstrap_ci(v, 2), mv.block_bootstrap_ci(v, 2))
        lo, hi = mv.block_bootstrap_ci(v, 2)
        self.assertLess(lo, hi)
        self.assertEqual(mv.block_bootstrap_ci([1, 2], 2), (None, None))


# ----------------------------------------------------------------------------- Trade Quality Gate
class V4_Trade_Quality(unittest.TestCase):
    def setUp(self):
        self.ex = ExecutionSimulator(CFG)
        self.good = dict(stop_dist=0.01, tp_dist=0.04, conf=0.8, reliability=0.8, n_eff=80, atr_pct=0.004, liquidity=0.9, fund_rate=0.0001)

    def test_positive_edge_wird_freigegeben_und_kosten_sind_aufgeschluesselt(self):
        g = trade_quality.evaluate(CFG, self.ex, **self.good)
        self.assertTrue(g.ok, g.reason)
        for k in ("fees", "spread", "slippage", "impact", "funding"):
            self.assertIn(k, g.costs)
        self.assertAlmostEqual(g.costs["fees"], 2 * CFG.fee_taker)         # beide Seiten
        self.assertGreater(g.conservative_net, 0)
        self.assertLess(g.conservative_net, g.gross_edge)

    def test_negative_konservative_edge_wird_abgelehnt(self):
        g = trade_quality.evaluate(CFG, self.ex, **dict(self.good, conf=0.45, tp_dist=0.003, stop_dist=0.01))
        self.assertFalse(g.ok)

    def test_fehlende_kosten_oder_liquiditaetsdaten_werden_abgelehnt(self):
        for k in ("liquidity", "atr_pct", "stop_dist", "tp_dist", "conf", "reliability", "n_eff"):
            g = trade_quality.evaluate(CFG, self.ex, **dict(self.good, **{k: None}))
            self.assertFalse(g.ok, k)
            self.assertIn("unvollständig", g.reason)
        self.assertFalse(trade_quality.evaluate(CFG, self.ex, **dict(self.good, liquidity=0.0)).ok)
        self.assertFalse(trade_quality.evaluate(CFG, self.ex, **dict(self.good, atr_pct=float("nan"))).ok)

    def test_unsicherheit_senkt_die_edge(self):
        hi = trade_quality.evaluate(CFG, self.ex, **dict(self.good, n_eff=500))
        lo = trade_quality.evaluate(CFG, self.ex, **dict(self.good, n_eff=8))
        self.assertGreater(hi.conservative_net, lo.conservative_net)

    def test_aktivitaet_und_nutzersteuerung_aendern_das_gate_nicht(self):
        a = trade_quality.evaluate(CFG, self.ex, **self.good).to_dict()
        c5 = dataclasses.replace(CFG, activity=5)
        b = trade_quality.evaluate(c5, ExecutionSimulator(c5), **self.good).to_dict()
        self.assertEqual(a, b)

    def test_gate_lehnt_im_system_ab_und_strict_blockiert(self):
        d = data(1500, 3)
        s_strict = run_backtest(d, dataclasses.replace(CFG, activity=5), None, start=400, end=1500, keep_system=True)["system"]
        s_off = run_backtest(d, dataclasses.replace(CFG, activity=5, gate_enabled=False, guard_enabled=False), None, start=400, end=1500, keep_system=True)["system"]
        self.assertGreater(s_strict.gate_stats.get("rejected", 0) + s_strict.gate_stats.get("passed", 0), 0)
        self.assertLessEqual(len(s_strict.team_closed), len(s_off.team_closed))     # Gate kann nur Trades entfernen


# ----------------------------------------------------------------------------- Portfolio Guardian
def twin_ctx(n=400, copies=("BTCUSDT", "AAAUSDT", "BBBUSDT", "CCCUSDT")):
    base = generate_synthetic(["BTCUSDT"], n, seed=21)["BTCUSDT"]
    ser = {}
    for k, name in enumerate(copies):
        s = Series(name)
        for j in range(n):
            c = base.candle(j)
            f = 1.0 + 0.0001 * k                      # praktisch identische Kursreihen (Korrelation ~1)
            s.append(Candle(c.ts, c.o * f, c.h * f, c.l * f, c.c * f, c.v))
        ser[name] = s
    return MarketCtx(ser)


class V4_Portfolio(unittest.TestCase):
    def test_hochkorrelierte_positionen_zaehlen_als_gemeinsames_risiko(self):
        m = twin_ctx()
        g = PortfolioGuardian(CFG)
        acct = Account("t", 1000.0, 1000.0)
        i = 300
        self.assertTrue(g.check(m, acct, "AAAUSDT", 1, i).ok)                         # leeres Portfolio: frei
        ex = ExecutionSimulator(CFG)
        px = m.s("BTCUSDT").c[i]
        ex.open_position(acct, "BTCUSDT", 1, 50.0, 2, 0.02, 0.04, 0.0, px, 0.004, 1, 5.0)
        r1 = g.check(m, acct, "AAAUSDT", 1, i)
        self.assertTrue(r1.ok)
        self.assertLess(r1.scale, 1.0)                                                # kleiner, nie größer
        self.assertGreater(r1.info["cluster"], 0.9)
        ex.open_position(acct, "AAAUSDT", 1, 50.0, 2, 0.02, 0.04, 0.0, m.s("AAAUSDT").c[i], 0.004, 1, 5.0)
        r2 = g.check(m, acct, "BBBUSDT", 1, i)
        self.assertFalse(r2.ok)                                                        # 2 korrelierte Longs = Limit (guard_max_cluster=2): Nr. 3 abgelehnt
        self.assertIn("gemeinsames Risiko", r2.reason)
        self.assertGreaterEqual(r2.info["cluster"], 1.9)
        self.assertTrue(g.check(m, acct, "BBBUSDT", -1, i).ok)                        # Gegenrichtung zählt nicht als gemeinsames Risiko

    def test_skala_nur_verkleinerung(self):
        m = twin_ctx()
        g = PortfolioGuardian(CFG)
        acct = Account("t", 1000.0, 1000.0)
        for res in (g.check(m, acct, "AAAUSDT", 1, 300),):
            self.assertLessEqual(res.scale, 1.0)

    def test_deaktivierter_guardian_laesst_alles_durch(self):
        g = PortfolioGuardian(dataclasses.replace(CFG, guard_enabled=False))
        self.assertTrue(g.check(None, None, "X", 1, 1).ok)


# ----------------------------------------------------------------------------- Regime
class V4_Regime(unittest.TestCase):
    def test_wahrscheinlichkeiten_summieren_sich_auf_eins(self):
        for st in (-3.0, 0.0, 3.0):
            for vp in (0.1, 0.5, 0.99):
                for un in (False, True):
                    p = regime_probs(Regime("range", "normal", un, False, st, vp), 500)
                    self.assertAlmostEqual(sum(p.values()), 1.0, places=9)
                    self.assertEqual(set(p), set(STATES))

    def test_unknown_bei_zu_wenig_historie(self):
        p = regime_probs(Regime("up", "normal", False, False, 3.0, 0.5), 50)
        self.assertEqual(p["unknown"], 1.0)
        self.assertEqual(RegimeTracker().update(p), "unknown")

    def test_hysterese_verhindert_flattern(self):
        up = regime_probs(Regime("up", "normal", False, False, 3.0, 0.5), 500)
        rg = regime_probs(Regime("range", "normal", False, False, 0.0, 0.5), 500)
        trk = RegimeTracker(min_duration=8, margin=0.15)
        trk.update(up)
        states = []
        for k in range(40):                                  # abwechselnd up/range (Rauschen)
            states.append(trk.update(up if k % 2 == 0 else rg))
        self.assertLessEqual(trk.switches, 2)
        naive = sum(1 for k in range(1, 40) if (max(up, key=up.get) != max(rg, key=rg.get)))
        self.assertGreater(naive, trk.switches)

    def test_stress_wirkt_sofort(self):
        up = regime_probs(Regime("up", "normal", False, False, 3.0, 0.5), 500)
        stress = regime_probs(Regime("up", "extreme", True, True, 3.0, 0.99), 500)
        trk = RegimeTracker()
        trk.update(up)
        self.assertEqual(trk.update(stress), "stress")


# ----------------------------------------------------------------------------- Meta-Agent
class V4_Bandit(unittest.TestCase):
    def _feed(self, b, rs):
        for k, (agent, ctx, r) in enumerate(rs):
            b.register(f"t{k}", agent, ctx)
            b.reward(f"t{k}", r, k)

    def test_delayed_reward_geht_an_den_eroeffnungskontext(self):
        b = ContextualBandit(["A"], min_samples=1)
        b.register("x", "A", "up/normal|liq_hoch")
        self.assertEqual(len(b.pending), 1)
        self.assertTrue(b.reward("x", 1.5, 10))               # Kontext beim Schließen ist egal
        self.assertIn("up/normal|liq_hoch|A", b.stats)
        self.assertFalse(b.reward("x", 1.5, 11))              # doppelte Zuordnung unmöglich
        self.assertFalse(b.reward("unbekannt", 1.0, 11))

    def test_mindeststichprobe_und_gewichtskappen(self):
        b = ContextualBandit(["A", "B"], min_samples=20, w_min=0.2, w_max=1.6)
        ctx = "range/normal|liq_hoch"
        self._feed(b, [("A", ctx, 3.0)] * 5)
        self.assertEqual(b.weights(ctx)["A"], 1.0)             # < 20 Beobachtungen: neutral
        self._feed(b, [("A", ctx, 3.0)] * 200 + [("B", ctx, -3.0)] * 200)
        w = b.weights(ctx, bar=999)
        self.assertLessEqual(w["A"], 1.6)
        self.assertGreaterEqual(w["B"], 0.2)
        self.assertGreater(w["A"], w["B"])

    def test_deterministisches_replay(self):
        seq = [("A", "c1", ((k * 7) % 5 - 2) / 2) for k in range(120)]
        b1, b2 = ContextualBandit(["A"], seed=3), ContextualBandit(["A"], seed=3)
        self._feed(b1, seq); self._feed(b2, seq)
        for bar in (5, 50, 500):
            self.assertEqual(b1.weights("c1", bar, explore=True), b2.weights("c1", bar, explore=True))
        b3 = ContextualBandit(["A"], seed=4)
        self._feed(b3, seq)
        self.assertNotEqual(b1.weights("c1", 5, explore=True), b3.weights("c1", 5, explore=True))

    def test_cooldown_nach_verlustserie_und_persistenz(self):
        b = ContextualBandit(["A"], streak=5, cooldown_bars=48, min_samples=1)
        self._feed(b, [("A", "c", -1.0)] * 5)
        self.assertLessEqual(b.weights("c", bar=10)["A"], 0.5)
        b2 = ContextualBandit(["A"], streak=5, cooldown_bars=48, min_samples=1); b2.load_dict(json.loads(json.dumps(b.to_dict())))
        self.assertEqual(b.weights("c", 10), b2.weights("c", 10))

    def test_bandit_ist_shadow_und_aendert_team_entscheidungen_nicht(self):
        d = data(1300, 6)
        c = dataclasses.replace(CFG, gate_enabled=False, guard_enabled=False)
        r1 = run_backtest(d, c, None, start=400, end=1300, keep_system=True)
        r2 = run_backtest(d, c, None, start=400, end=1300, keep_system=True)
        self.assertEqual([t.net_pnl for t in r1["trades"]], [t.net_pnl for t in r2["trades"]])   # reproduzierbar
        self.assertGreater(len(r1["system"].meta.stats), 0)                                       # lernt mit


# ----------------------------------------------------------------------------- Nutzersteuerung / Ablation
class V4_Nutzersteuerung(unittest.TestCase):
    def test_werte_werden_begrenzt_und_validiert(self):
        uc = UserControls(["A"])
        self.assertEqual(uc.set_agent("A", influence=9)["influence"], 2.0)
        self.assertEqual(uc.set_agent("A", influence=-1)["influence"], 0.0)
        with self.assertRaises(ValueError):
            uc.set_agent("A", influence="abc")
        with self.assertRaises(ValueError):
            uc.set_agent("A", influence=float("nan"))
        with self.assertRaises(KeyError):
            uc.set_agent("X", enabled=False)
        self.assertEqual(uc.set_activity(99), 5)
        self.assertEqual(uc.set_activity(-5), 1)
        with self.assertRaises(ValueError):
            uc.set_gate_mode("egal")

    def test_ausgeschalteter_agent_hat_kein_stimmrecht_aber_schattenkonto_laeuft(self):
        d = data(1400, 6)
        s_on = run_backtest(d, CFG, None, start=400, end=1400, keep_system=True)["system"]
        s_off = run_backtest(d, CFG, None, start=400, end=1400, keep_system=True, disable_agents=["Momentum"])["system"]
        self.assertEqual(s_off.learner.weight("Momentum", "up", 999), 0.0)
        self.assertGreater(s_on.learner.weight("Momentum", "up", 999), 0.0)
        self.assertEqual(len(s_off.shadow_closed["Momentum"]), len(s_on.shadow_closed["Momentum"]))   # Messung unverändert
        for t in s_off.team_closed:
            self.assertNotEqual(t.agent, "Momentum")

    def test_stimmrecht_skaliert_gewicht_und_entscheidung(self):
        from arena_v3.learning import MetaLearner, SignalAggregator
        from arena_v3.agents import Signal
        agents = build_agents(clamp_params(None), 1)
        am = {a.name: a for a in agents}
        uc = UserControls(list(am))
        ml = MetaLearner(CFG, am); ml.controls = uc
        ag = SignalAggregator(CFG, clamp_params(None), agents, uc)
        reg = Regime("up", "normal", False, False, 2.0, 0.5)
        sigs = {n: Signal(1, 0.9, 0.02, 0.01, "t") for n in ("Momentum", "Trendfolger")}
        base = ag.decide("X", sigs, ml, reg, 100, 0)
        uc.set_agent("Momentum", influence=0.0)
        off = ag.decide("X", sigs, ml, reg, 100, 0)
        self.assertEqual([p["agent"] for p in off.parts], ["Trendfolger"])
        self.assertEqual(len(base.parts), 2)
        self.assertEqual(ml.weight_perf("Momentum", "up", 100), 1.0)               # gelerntes Gewicht unverändert
        uc.set_agent("Momentum", enabled=True, influence=2.0)
        dbl = ag.decide("X", sigs, ml, reg, 100, 0)
        w = {p["agent"]: p["w"] for p in dbl.parts}
        self.assertAlmostEqual(w["Momentum"], 2 * w["Trendfolger"], places=1)

    def test_niedriges_stimmrecht_loest_keine_qualitaetssperre_aus(self):
        from arena_v3.learning import MetaLearner, SignalAggregator
        from arena_v3.agents import Signal
        agents = build_agents(clamp_params(None), 1)
        am = {a.name: a for a in agents}
        uc = UserControls(list(am))
        ml = MetaLearner(CFG, am); ml.controls = uc
        ag = SignalAggregator(CFG, clamp_params(None), agents, uc)
        for n in ("Momentum", "Trendfolger"):
            uc.set_agent(n, influence=0.3)
        d = ag.decide("X", {n: Signal(1, 0.9, 0.02, 0.01, "t") for n in ("Momentum", "Trendfolger")}, ml,
                      Regime("up", "normal", False, False, 2.0, 0.5), 100, 0)
        self.assertNotIn("Agenten-Gewichte", d.blocked or "")      # Nutzerfaktor verfälscht den Qualitätsfaktor nicht

    def test_aktivitaet_lockert_nur_signalfilter_monoton(self):
        uc = UserControls()
        p = clamp_params(None)
        th = {}
        for lv in (1, 2, 3, 4, 5):
            uc.set_activity(lv)
            th[lv] = uc.thresholds(p, CFG)
        for a, b in zip(range(1, 5), range(2, 6)):
            self.assertGreaterEqual(th[a]["consensus"], th[b]["consensus"])
            self.assertGreaterEqual(th[a]["min_conf"], th[b]["min_conf"])
            self.assertLessEqual(th[a]["agreement"], th[b]["agreement"] + 1) if False else self.assertGreaterEqual(th[a]["agreement"], th[b]["agreement"])
        self.assertAlmostEqual(th[3]["consensus"], p["team.consensus"])             # Stufe 3 = optimierte Parameter
        self.assertGreaterEqual(th[5]["agreement"], 0.55)                           # Untergrenzen bleiben

    def test_hoehere_aktivitaet_gibt_mehr_team_freigaben(self):
        d = data(1800, 6)
        c1 = dataclasses.replace(CFG, activity=1, gate_enabled=False, guard_enabled=False)
        c5 = dataclasses.replace(CFG, activity=5, gate_enabled=False, guard_enabled=False)
        s1 = run_backtest(d, c1, None, start=400, end=1800, keep_system=True)["system"]
        s5 = run_backtest(d, c5, None, start=400, end=1800, keep_system=True)["system"]
        self.assertGreater(s5.block_stats.get("freigegeben", 0), s1.block_stats.get("freigegeben", 0))

    def test_ablation_hochgewichtet_nichts_automatisch(self):
        rows = [{"agent": "A", "verdict": "hilft"}, {"agent": "B", "verdict": "schadet"}, {"agent": "C", "verdict": "kein_nachweis"},
                {"agent": "D", "verdict": "inconclusive"}]
        sug = suggest_influence(rows, {"A": 1.0, "B": 1.0, "C": 1.5, "D": 1.2})
        self.assertGreater(sug["A"], 1.0)
        self.assertLess(sug["B"], 1.0)
        self.assertLessEqual(sug["C"], 1.0)                 # kein Nachweis -> nie hochgewichten
        self.assertLessEqual(sug["D"], 1.0)

    def test_ablation_laeuft_deterministisch(self):
        from arena_v3.contribution import ablation
        d = data(1400, 5, k=2)
        c = dataclasses.replace(Config(symbols=tuple(d)), gate_enabled=False, guard_enabled=False)
        r1 = ablation(d, c, None, start=400, end=1400, agents=["Momentum"], burn_in=300)
        r2 = ablation(d, c, None, start=400, end=1400, agents=["Momentum"], burn_in=300)
        self.assertEqual(r1["rows"][0]["delta_net_return"], r2["rows"][0]["delta_net_return"])
        self.assertIn(r1["rows"][0]["verdict"], ("inconclusive", "hilft", "schadet", "kein_nachweis", "unklar"))
        self.assertEqual(r1["n_runs"], 2)


class V4_Auto_Hebel(unittest.TestCase):
    def test_hebel_waechst_nur_mit_belegter_leistung_und_bleibt_im_profil(self):
        uc = UserControls(["A"])
        self.assertEqual(uc.agent_lev_cap("A", {"n_eff": 0, "lcb": 0}, 20), 2)                   # unbewährt
        self.assertEqual(uc.agent_lev_cap("A", {"n_eff": 25, "lcb": 0.05}, 20), 5)
        self.assertEqual(uc.agent_lev_cap("A", {"n_eff": 45, "lcb": 0.15}, 20), 10)
        self.assertEqual(uc.agent_lev_cap("A", {"n_eff": 80, "lcb": 0.30}, 20), 20)
        self.assertEqual(uc.agent_lev_cap("A", {"n_eff": 500, "lcb": 5.0}, 20), 20)              # nie über SAFE
        self.assertEqual(uc.agent_lev_cap("A", {"n_eff": 80, "lcb": 0.30}, 8), 8)                # Profil gewinnt
        self.assertEqual(uc.agent_lev_cap("A", {"n_eff": 80, "lcb": -0.2}, 20), 2)               # Verlustner: kein Hebel
        self.assertEqual(uc.agent_lev_cap("A", {"n_eff": 80, "lcb": 0.9}, 20) >= uc.agent_lev_cap("A", {"n_eff": 80, "lcb": 0.3}, 20), True)

    def test_manuell_einstellbar_aber_durch_profil_begrenzt(self):
        uc = UserControls(["A"])
        uc.set_agent("A", lev_cap=7)
        self.assertEqual(uc.agent_lev_cap("A", {"n_eff": 0, "lcb": 0}, 20), 7)
        uc.set_agent("A", lev_cap=500)
        self.assertEqual(uc.agent_lev_cap("A", {"n_eff": 0, "lcb": 0}, 20), 20)
        uc.set_agent("A", lev_cap="auto")
        self.assertEqual(uc.agent_lev_cap("A", {"n_eff": 0, "lcb": 0}, 20), 2)
        with self.assertRaises(ValueError):
            uc.set_agent("A", lev_cap="x")
        uc.set_auto_leverage(False)
        self.assertEqual(uc.agent_lev_cap("A", {"n_eff": 0, "lcb": 0}, 20), 20)                  # Auto aus = nur Profil/Stufen
        d = json.loads(json.dumps(uc.to_dict())); u2 = UserControls(["A"]); u2.load_dict(d)
        self.assertFalse(u2.auto_leverage)

    def test_hebel_im_system_nie_ueber_agenten_obergrenze_und_profil(self):
        d = data(1500, 6)
        c = dataclasses.replace(CFG, activity=5, gate_enabled=False, guard_enabled=False)
        s = run_backtest(d, c, None, start=400, end=1500, keep_system=True)["system"]
        self.assertGreater(len(s.shadow_closed["Momentum"]) + len(s.team_closed), 0)
        for tr in list(s.team_closed) + [t for v in s.shadow_closed.values() for t in v]:
            self.assertLessEqual(tr.lev, SAFE_LIMITS.max_leverage)
        # manuelle Obergrenze 3x für alle: kein Trade darüber
        from arena_v3.backtest import MarketCtx as _M
        m = _M(d); s2 = TradingSystem("x", c)
        for a in list(s2.am): s2.controls.set_agent(a, lev_cap=3)
        for i in range(1, 1500): s2.step(m, i)
        allt = list(s2.team_closed) + [t for v in s2.shadow_closed.values() for t in v]
        self.assertGreater(len(allt), 0)
        self.assertLessEqual(max(t.lev for t in allt), 3)

    def test_api_und_dashboard_zeigen_hebel(self):
        a = V4_Persistenz_und_Dashboard()._app()
        for _ in range(3): a.tick()
        a.set_agent_control("Momentum", lev_cap=5)
        a.set_auto_leverage(False)
        st = build_state(a)["systems"]["champion"]
        ag = [x for x in st["agents"] if x["name"] == "Momentum"][0]
        self.assertEqual(ag["user"]["lev_cap"], 5); self.assertEqual(ag["lev_cap_eff"], 5)
        self.assertEqual(ag["lev_max"], SAFE_LIMITS.max_leverage)
        self.assertFalse(st["v4"]["controls"]["auto_leverage"])
        a.stop()


# ----------------------------------------------------------------------------- Drift / Rollback
class V4_Drift_Rollback(unittest.TestCase):
    def test_psi_erkennt_verschobene_verteilung(self):
        ref = [math.sin(k) for k in range(500)]
        self.assertLess(psi(ref, [math.sin(k + 1.3) for k in range(200)]), 0.1)
        self.assertGreater(psi(ref, [x + 2.0 for x in ref[:200]]), 0.25)
        self.assertIsNone(psi(ref[:10], ref[:10]))

    def test_drift_loest_nur_derating_pause_rollback_aus(self):
        dm = DriftMonitor(min_trades=20)
        ok = dm.assess(ref_r=[0.1, -0.1] * 50, recent_r=[0.1, -0.1] * 15)
        self.assertEqual(ok["action"], "ok")
        bad = dm.assess(ref_r=[0.2, -0.1] * 50, recent_r=[-0.6, -0.4] * 15)
        self.assertIn(bad["action"], ("pause", "rollback"))
        self.assertLessEqual(bad["weight_factor"], 1.0)
        dd = dm.assess(drawdown=0.2, max_drawdown=0.12)
        self.assertEqual(dd["action"], "rollback")
        for r in (ok, bad, dd):
            self.assertLessEqual(r["weight_factor"], 1.0)           # nie Risikosteigerung

    def test_challenger_wird_deaktiviert_champion_bleibt_intakt(self):
        cc = ChampionChallenger(Config())
        cc.challenger = {"version": 2, "params": clamp_params(None), "since": 0}
        champ = dict(cc.champion)
        res = cc.deactivate_challenger("Drift", 5)
        self.assertTrue(res["deactivated"])
        self.assertIsNone(cc.challenger)
        self.assertEqual(cc.champion, champ)
        self.assertFalse(cc.deactivate_challenger("nochmal")["deactivated"])


# ----------------------------------------------------------------------------- Ausführung
class V4_Ausfuehrung(unittest.TestCase):
    def test_gebuehren_beidseitig_und_kosten_in_geschlossenen_trades(self):
        d = data(1500, 3)
        r = run_backtest(d, dataclasses.replace(CFG, gate_enabled=False, guard_enabled=False, activity=5), None, start=400, end=1500)
        self.assertGreater(len(r["trades"]), 0)
        for t in r["trades"]:
            if not t.liquidated:
                self.assertGreater(t.fees, 0)
                self.assertGreaterEqual(t.fees, t.notional * CFG.fee_taker * 1.5 * 0.5)   # grob: Ein- UND Ausstieg
            self.assertGreaterEqual(t.slippage, 0)

    def test_order_wird_erst_zur_naechsten_kerze_ausgefuehrt(self):
        d = data(900, 3)
        m = MarketCtx(d)
        s = TradingSystem("t", dataclasses.replace(CFG, activity=5, gate_enabled=False, guard_enabled=False))
        for i in range(1, 880):
            before = {x.open_ts for x in s.team_closed}
            s.step(m, i)
        for t in s.team_closed:
            self.assertGreater(t.open_ts, 0)


# ----------------------------------------------------------------------------- Persistenz / App / Dashboard
class V4_Persistenz_und_Dashboard(unittest.TestCase):
    def _app(self, path=None, **kw):
        cfg = dataclasses.replace(Config(symbols=DEFAULT_SYMBOLS[:3]), warmup_bars=320, **kw)
        return ArenaApp(cfg, demo=True, db_path=path or os.path.join(tempfile.mkdtemp(), "t.db"))

    def test_systemzustand_roundtrip_mit_controls_meta_und_gate(self):
        d = data(1300, 6)
        s = run_backtest(d, CFG, None, start=400, end=1300, keep_system=True, disable_agents=["Momentum"])["system"]
        s.controls.set_activity(4)
        snap = json.loads(json.dumps(s.to_dict()))
        s2 = TradingSystem("n", CFG)
        s2.load_dict(snap)
        self.assertFalse(s2.controls.enabled("Momentum"))
        self.assertEqual(s2.controls.activity, 4)
        self.assertEqual(dict(s2.meta.stats), dict(s.meta.stats))
        self.assertEqual(dict(s2.gate_stats), dict(s.gate_stats))

    def test_nutzersteuerung_ueberlebt_neustart(self):
        path = os.path.join(tempfile.mkdtemp(), "t.db")
        a = self._app(path)
        for _ in range(2):
            a.tick()
        a.set_agent_control("Momentum", enabled=False, influence=0.5)
        a.set_activity(5)
        a.set_gate_mode("monitor")
        a.stop()
        b = self._app(path)
        self.assertFalse(b.controls.enabled("Momentum"))
        self.assertEqual(b.controls.agents["Momentum"]["influence"], 0.5)
        self.assertEqual(b.controls.activity, 5)
        self.assertEqual(b.controls.gate_mode, "monitor")
        self.assertIs(b.systems["champion"].controls, b.controls)         # gilt für das ganze System
        b.stop()

    def test_dashboard_zeigt_paper_status_nutzersteuerung_und_ablehnungsgruende(self):
        a = self._app()
        for _ in range(4):
            a.tick()
        st = build_state(a)
        self.assertTrue(st["meta"]["paper_only"])
        self.assertEqual(st["meta"]["risk_profile"], "safe")
        self.assertEqual(st["meta"]["hard"]["max_leverage"], SAFE_LIMITS.max_leverage)
        sy = st["systems"]["champion"]
        self.assertEqual(sy["risk"]["limits"]["max_open"], SAFE_LIMITS.max_open_positions)
        for k in ("gate", "funnel", "regime", "meta_suggestion", "controls", "risk_profile"):
            self.assertIn(k, sy["v4"])
        ag = sy["agents"][0]
        self.assertIn("user", ag); self.assertIn("share", ag); self.assertIn("learned_weight", ag)
        self.assertAlmostEqual(sum(x["share"] for x in sy["agents"]), 1.0, places=6)
        a.stop()

    def test_aus_schalten_setzt_anteil_im_dashboard_auf_null(self):
        a = self._app()
        for _ in range(3):
            a.tick()
        a.set_agent_control("Momentum", enabled=False)
        ag = [x for x in build_state(a)["systems"]["champion"]["agents"] if x["name"] == "Momentum"][0]
        self.assertEqual(ag["share"], 0.0)
        self.assertFalse(ag["user"]["enabled"])
        a.stop()

    def test_live_kurse_werden_geholt_und_im_dashboard_ausgewiesen(self):
        a = self._app()
        for _ in range(3):
            a.tick()

        class Fake:
            def tickers(self, syms):
                return {s: 123.0 for s in syms}
        a.demo, a.client = False, Fake()
        self.assertTrue(a.price_poll_once())
        st = build_state(a)
        self.assertIsNotNone(st["meta"]["price_age"])
        self.assertLess(st["meta"]["price_age"], 5)
        a.demo = True
        a.stop()

    def test_http_endpunkte_validieren_und_begrenzen(self):
        a = self._app()
        for _ in range(3):
            a.tick()
        port = 18000 + (os.getpid() % 1000)
        threading.Thread(target=serve, args=(a, "127.0.0.1", port, ""), daemon=True).start()
        time.sleep(0.5)

        def post(path, body):
            req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=json.dumps(body).encode(), method="POST",
                                         headers={"Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(req) as r:
                    return r.status, json.loads(r.read())
            except urllib.error.HTTPError as e:
                return e.code, None
        self.assertEqual(post("/api/agent", {"agent": "Momentum", "enabled": False, "influence": 9})[1]["influence"], 2.0)
        self.assertEqual(post("/api/agent", {"agent": "gibtsnicht", "enabled": False})[0], 400)
        self.assertEqual(post("/api/activity", {"level": "abc"})[0], 400)
        self.assertEqual(post("/api/activity", {"level": 7})[1]["activity"], 5)
        self.assertEqual(post("/api/gate_mode", {"mode": "evil"})[0], 400)
        # Risikoprofil lässt sich über KEINEN Endpunkt ändern
        for path in ("/api/risk_profile", "/api/limits", "/api/live"):
            self.assertEqual(post(path, {"risk_profile": "aggressive_paper"})[0], 404)
        self.assertEqual(a.cfg.risk_profile, "safe")
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/state") as r:
            st = json.loads(r.read())
        self.assertFalse(st["systems"]["champion"]["agents"][0]["user"]["enabled"] if st["systems"]["champion"]["agents"][0]["name"] == "Momentum" else True)
        a.stop()

    def test_push_intervall_ist_konfigurierbar_und_schnell(self):
        self.assertLessEqual(Config().ui_push_ms, 500)
        self.assertLessEqual(Config().price_poll_sec, 3.0)
        html = open(os.path.join(os.path.dirname(__file__), "..", "arena_v3", "web", "index.html"), encoding="utf-8").read()
        self.assertIn("now-lastRender<300", html)
        self.assertNotIn("now-lastRender<1400", html)

    def test_gate_monitor_blockiert_beforderung(self):
        a = self._app()
        for _ in range(2):
            a.tick()
        a.set_gate_mode("monitor")
        a.cc.challenger = {"version": 2, "params": clamp_params(None), "since": 0}
        a._make_system("challenger")
        a.evaluate_job()
        self.assertEqual(a.cc.champion["version"], 1)
        self.assertTrue(any(l["kind"] == "PROMOTION_BLOCKIERT" for l in a.cc.log))
        a.stop()


if __name__ == "__main__":
    unittest.main()
