#!/usr/bin/env python3
"""
KI-Trading-Arena V3 - Startskript (nur Paper Trading, Spielgeld; es gibt KEINEN Live-Trading-Code).

  python start_v3.py demo                  Demo mit synthetischen Kursen (kostenlos, schnell, zeigt alle Funktionen)
  python start_v3.py live [--llm] [--cheap]  Paper Trading mit echten Binance-Kursen (öffentliche Daten, kein Key nötig)
  python start_v3.py backtest [--synthetic | --days 60]
  python start_v3.py walkforward [--synthetic | --days 90] [--trials 20]
  python start_v3.py levstudy [--synthetic | --days 90]
  python start_v3.py optimize              einmal optimieren und ggf. Challenger anlegen
  python start_v3.py test                  alle Tests + Testbericht (TESTREPORT.md)
Optionen: --config config.json  --host 0.0.0.0  --port 8000  --reset  --speed 1.0 (Demo-Sekunden pro Kerze)
Dashboard-Passwort: Umgebungsvariable DASHBOARD_PASSWORD (Benutzer: arena)
"""
import argparse
import dataclasses
import json
import os
import sys
import threading
import time

from arena_v3.config import Config


def get_llm_fn():
    import anthropic
    client = anthropic.Anthropic()

    def fn(model, prompt):
        last = None
        for a in range(3):
            try:
                r = client.messages.create(model=model, max_tokens=2000, messages=[{"role": "user", "content": prompt}])
                text = "".join(b.text for b in r.content if getattr(b, "type", "") == "text")
                if not text:
                    raise RuntimeError("leere Antwort")
                return text, r.usage.input_tokens, r.usage.output_tokens
            except Exception as e:
                last = e
                time.sleep(2 * (a + 1))
        raise last
    return fn


def load_data(args, cfg):
    from arena_v3.data import generate_synthetic, BinanceClient, Series, INTERVAL_MS
    from arena_v3.db import DB
    from arena_v3.app import align
    if args.synthetic:
        n = args.bars or 9000
        print(f"Synthetische Daten ({n} Kerzen). Keine Aussage über echte Märkte!")
        return generate_synthetic(list(cfg.symbols), n, seed=cfg.seed)
    db = DB(cfg.db_path)
    cli = BinanceClient()
    end = int(time.time() * 1000)
    start = end - int(args.days * 96) * INTERVAL_MS
    out = {}
    for s in cfg.symbols:
        rows = db.load_candles(s, start, end)
        if len(rows) < args.days * 96 * 0.95:
            print(f"Lade {args.days} Tage {s} ...")
            rows = cli.history(s, start, end)
            db.save_candles(s, rows)
        out[s] = Series.from_rows(s, rows)
        out[s].funding = cli.funding_history(s, start)
    return align(out)


def report_metrics(m):
    from arena_v3.analytics import fmt
    return (f"netto {fmt(m['net_return'], 2, True)} | PF {fmt(m['profit_factor'])} | Sharpe {fmt(m['sharpe'])} | Sortino {fmt(m['sortino'])} | "
            f"MaxDD {fmt(m['max_drawdown'], 1, True)} | Trades {m['trades']} | Gebühren {fmt(m['fees'])} | Funding {fmt(m['funding'])} | "
            f"Liquidationen {m['liquidations']}")


def main():
    ap = argparse.ArgumentParser(description="KI-Trading-Arena V3 (Paper Trading)")
    ap.add_argument("mode", choices=["demo", "live", "backtest", "walkforward", "levstudy", "optimize", "test"])
    ap.add_argument("--config"); ap.add_argument("--host"); ap.add_argument("--port", type=int)
    ap.add_argument("--llm", action="store_true", help="KI-Agenten (Claude) zusätzlich einbinden (kostet API-Guthaben)")
    ap.add_argument("--cheap", action="store_true", help="KI-Agenten nur mit Haiku")
    ap.add_argument("--synthetic", action="store_true"); ap.add_argument("--days", type=int, default=60)
    ap.add_argument("--symbols", help="Komma-Liste, z. B. BTCUSDT,ETHUSDT,PEPEUSDT (überschreibt die Standardliste)")
    ap.add_argument("--bars", type=int); ap.add_argument("--trials", type=int)
    ap.add_argument("--reset", action="store_true"); ap.add_argument("--speed", type=float, default=1.0)
    args = ap.parse_args()
    cfg = Config.load(args.config)
    if args.host: cfg.host = args.host
    if args.port: cfg.port = args.port
    if args.symbols:
        cfg.symbols = tuple(x.strip().upper() for x in args.symbols.split(",") if x.strip())
    if "BTCUSDT" in cfg.symbols and cfg.symbols[0] != "BTCUSDT":      # BTC ist Referenzmarkt und muss vorne stehen
        cfg.symbols = ("BTCUSDT",) + tuple(x for x in cfg.symbols if x != "BTCUSDT")
    if args.mode in ("live", "optimize", "backtest", "walkforward", "levstudy") and not args.synthetic:
        from arena_v3.data import BinanceClient
        if args.mode in ("backtest", "walkforward", "levstudy"):
            min_bars = args.days * 96
        else:                                                    # live/optimize brauchen Historie für Walk-forward + Einschwingen
            min_bars = int((cfg.wf_train_bars + 3 * cfg.wf_test_bars + cfg.warmup_bars) * 1.05)
        print(f"Prüfe {len(cfg.symbols)} Paare (Existenz, Historie, Lücken) ...")
        ok, bad = BinanceClient().usable(cfg.symbols, min_bars)
        for sym_, why in bad.items():
            print(f"  übersprungen: {sym_}: {why}")
        cfg.symbols = tuple(ok)
        print(f"{len(cfg.symbols)} Paare aktiv.")
        if "BTCUSDT" not in cfg.symbols:
            sys.exit("BTCUSDT (Referenzmarkt) ist nicht abrufbar - bitte Netzwerk prüfen.")

    if args.mode == "test":
        import subprocess
        sys.exit(subprocess.call([sys.executable, "run_tests.py"]))

    if args.mode in ("backtest", "walkforward", "levstudy"):
        from arena_v3.backtest import run_backtest, walk_forward, leverage_study
        data = load_data(args, cfg)
        n = len(data[cfg.symbols[0]])
        if args.mode == "backtest":
            r = run_backtest(data, cfg, None, start=cfg.warmup_bars, end=n)
            print("Backtest:", report_metrics(r["metrics"]))
            for k, v in r["regimes"].items():
                print(f"  {k:20} Trades {v['trades']:4} Netto {v['net_pnl']:8.2f} PF {v['profit_factor']:.2f}")
        elif args.mode == "walkforward":
            wf = walk_forward(data, cfg, n_trials=args.trials, progress=lambda k, t, m: print(f" Fold {k}/{t}: OOS {report_metrics(m)}"))
            print("Walk-forward gesamt (Out-of-sample):", report_metrics(wf["metrics"]))
            print("Robust:", wf["robust"], wf["checks"])
        else:
            res = leverage_study(data, cfg, None, progress=lambda L, m: print(f" {L:2}x: {report_metrics(m)}"))
            print("Gewählte Stufe:", res["selected"], "| höchste Rendite:", res["highest_return_level"])
            print(res["note"])
        return

    from arena_v3.app import ArenaApp
    from arena_v3.dashboard import serve
    demo = args.mode == "demo"
    if demo:
        cfg = dataclasses.replace(cfg, opt_trials=3, opt_segments=2, wf_train_bars=1200, wf_test_bars=400, wf_step_bars=400,
                                  promo_min_fwd_trades=5, promo_min_oos_trades=5, promo_min_fwd_pf=0.0, promo_min_regimes=1,
                                  promo_min_pos_folds=0.0, promo_min_oos_pf=0.0, promo_max_oos_mdd=1.0, promo_max_fwd_mdd=1.0)
    if args.reset:
        for p in (cfg.db_path if not demo else "arena_v3_demo.db",):
            for ext in ("", "-wal", "-shm"):
                if os.path.exists(p + ext):
                    os.remove(p + ext)
    llm_fn = None
    if args.llm and not demo:
        if not os.environ.get("ANTHROPIC_API_KEY"):
            sys.exit("ANTHROPIC_API_KEY fehlt (nur nötig für --llm).")
        llm_fn = get_llm_fn()
    app = ArenaApp(cfg, demo=demo, use_llm=bool(args.llm and not demo), cheap=args.cheap, llm_fn=llm_fn)
    if args.mode == "optimize":
        print(app.optimize_job())
        return
    threading.Thread(target=serve, args=(app, cfg.host, cfg.port), daemon=True).start()
    app.background_loop(optimize_every_hours=0.02 if demo else 24, eval_every=20 if demo else 96)
    print(f"Dashboard: http://localhost:{cfg.port}  | Modus: {'DEMO (synthetisch)' if demo else 'LIVE-Kurse, PAPER TRADING'}  | Beenden: Strg+C")
    if not demo and not os.environ.get("DASHBOARD_PASSWORD") and cfg.host != "127.0.0.1":
        print("WARNUNG: Dashboard von außen erreichbar, aber DASHBOARD_PASSWORD nicht gesetzt!")
    try:
        app.tick()
        while True:
            if demo:
                time.sleep(args.speed)
            else:
                now = time.time()
                time.sleep(max(1, (now // cfg.interval_sec + 1) * cfg.interval_sec + 1 - now))
            if app.trading_enabled:
                app.tick()
    except KeyboardInterrupt:
        print("Beendet. Der Stand ist gespeichert.")


if __name__ == "__main__":
    main()
