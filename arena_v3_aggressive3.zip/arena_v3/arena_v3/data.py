"""
Market Data Engine: Kerzen-Datentyp, Validierung, Binance-Client (Timeout + Retry + Host-Fallback),
Historien-Download mit Paging und ein deterministischer Demo-/Test-Generator mit mehreren Marktphasen.
"""
from __future__ import annotations

import math
import random
import time
from dataclasses import dataclass, field

INTERVAL_MS = 900_000  # 15 Minuten


@dataclass
class Candle:
    ts: int
    o: float
    h: float
    l: float
    c: float
    v: float


@dataclass
class Series:
    symbol: str
    ts: list = field(default_factory=list)
    o: list = field(default_factory=list)
    h: list = field(default_factory=list)
    l: list = field(default_factory=list)
    c: list = field(default_factory=list)
    v: list = field(default_factory=list)
    funding: dict = field(default_factory=dict)   # {funding_ts_ms: rate}  (echte Daten, falls vorhanden)

    def __len__(self):
        return len(self.ts)

    def append(self, k: Candle):
        self.ts.append(k.ts); self.o.append(k.o); self.h.append(k.h)
        self.l.append(k.l); self.c.append(k.c); self.v.append(k.v)

    def candle(self, i) -> Candle:
        return Candle(self.ts[i], self.o[i], self.h[i], self.l[i], self.c[i], self.v[i])

    def slice(self, a, b) -> "Series":
        return Series(self.symbol, self.ts[a:b], self.o[a:b], self.h[a:b], self.l[a:b], self.c[a:b], self.v[a:b],
                      {k: v for k, v in self.funding.items() if self.ts[a] <= k <= self.ts[b - 1]} if b > a else {})

    @staticmethod
    def from_rows(symbol, rows) -> "Series":
        s = Series(symbol)
        for r in rows:
            s.append(Candle(int(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5])))
        return s


def validate_rows(rows, interval_ms=INTERVAL_MS, drop_last_open=False, now_ms=None):
    """
    Prüft und bereinigt Kerzen: sortiert, entfernt Duplikate, verwirft ungültige Werte (NaN, <=0, h<l, o/c außerhalb h/l).
    Optional wird die noch laufende (unfertige) letzte Kerze entfernt. Wirft ValueError, wenn nichts übrig bleibt.
    """
    clean, seen = [], set()
    for r in rows:
        try:
            ts, o, h, l, c, v = int(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5])
        except (TypeError, ValueError, IndexError):
            continue
        if ts in seen or any(math.isnan(x) or math.isinf(x) for x in (o, h, l, c, v)):
            continue
        if min(o, h, l, c) <= 0 or v < 0 or h < l or h < max(o, c) - 1e-12 or l > min(o, c) + 1e-12:
            continue
        seen.add(ts)
        clean.append([ts, o, h, l, c, v])
    clean.sort(key=lambda x: x[0])
    if drop_last_open and clean:
        now_ms = now_ms or int(time.time() * 1000)
        if clean[-1][0] + interval_ms > now_ms:
            clean = clean[:-1]
    if not clean:
        raise ValueError("keine gültigen Kerzen")
    return clean


class ClientError(RuntimeError):
    """HTTP-4xx (außer 429): Wiederholen bringt nichts, z. B. ungültiges Symbol."""


class BinanceClient:
    """Öffentliche Marktdaten (kein API-Key, keine Orders). Timeout, Retry mit Wartezeit, Host-Fallback."""
    SPOT = ["https://api.binance.com", "https://data-api.binance.vision"]
    FAPI = "https://fapi.binance.com"

    def __init__(self, retries=3, timeout=10):
        import requests
        self.rq = requests
        self.retries, self.timeout = retries, timeout

    def _get(self, hosts, path, params):
        last = None
        for host in hosts:
            for attempt in range(self.retries):
                try:
                    r = self.rq.get(host + path, params=params, timeout=self.timeout)
                    if r.status_code == 429:
                        time.sleep(2 * (attempt + 1))
                        continue
                    if r.status_code in (400, 404):                  # ungültiges Symbol/Anfrage: Wiederholen sinnlos
                        raise ClientError(f"HTTP {r.status_code} ({path}): {r.text[:120]}")
                    if r.status_code in (403, 418, 451):             # Sperre dieses Hosts/IP: sofort den nächsten Host versuchen
                        last = RuntimeError(f"HTTP {r.status_code} bei {host}")
                        break
                    r.raise_for_status()
                    return r.json()
                except ClientError:
                    raise
                except Exception as e:
                    last = e
                    time.sleep(1.5 * (attempt + 1))
        raise RuntimeError(f"API nicht erreichbar ({path}): {last}")

    def klines(self, symbol, interval="15m", limit=500, start=None, end=None):
        p = {"symbol": symbol, "interval": interval, "limit": limit}
        if start is not None:
            p["startTime"] = int(start)
        if end is not None:
            p["endTime"] = int(end)
        return self._get(self.SPOT, "/api/v3/klines", p)

    def history(self, symbol, start_ms, end_ms, interval="15m"):
        """Lädt viele Kerzen seitenweise (1000 pro Anfrage)."""
        rows, cur = [], int(start_ms)
        while cur < end_ms:
            page = self.klines(symbol, interval, 1000, start=cur, end=end_ms)
            if not page:
                break
            rows.extend(page)
            nxt = int(page[-1][0]) + INTERVAL_MS
            if nxt <= cur:
                break
            cur = nxt
            time.sleep(0.15)
        return validate_rows([r[:6] for r in rows])

    def funding_history(self, symbol, start_ms=None, limit=1000):
        p = {"symbol": symbol, "limit": limit}
        if start_ms:
            p["startTime"] = int(start_ms)
        try:
            data = self._get([self.FAPI], "/fapi/v1/fundingRate", p)
            return {int(d["fundingTime"]): float(d["fundingRate"]) for d in data}
        except Exception:
            return {}

    def available(self, symbols):
        """Gibt nur Symbole zurück, für die Kerzen abrufbar sind (z. B. nicht delistet). Nicht erreichbare API -> alle behalten."""
        ok, bad = [], []
        for s in symbols:
            try:
                rows = self.klines(s, "15m", 2)
                (ok if rows else bad).append(s)
            except Exception as e:
                if isinstance(e, ClientError) or "Invalid symbol" in str(e):
                    bad.append(s)
                else:
                    return list(symbols), []       # Netzwerkproblem: nicht still Symbole verwerfen
        return ok, bad

    def usable(self, symbols, min_bars, window=700, min_cov=0.9, workers=8):
        """
        Prüft vor dem Start, welche Paare brauchbar sind:
          - existiert das Paar (nicht delistet),
          - ist die Historie lang genug (min_bars Kerzen, sonst würde sie die Daten ALLER Paare verkürzen),
          - gibt es in den letzten `window` Kerzen kaum Lücken (wenig gehandelte Paare lassen Kerzen ohne Handel weg).
        Rückgabe: (brauchbare Symbole in Originalreihenfolge, {symbol: Grund}). Netzwerkproblem: alle behalten.
        """
        from concurrent.futures import ThreadPoolExecutor
        now = int(time.time() * 1000)

        def check(sym):
            try:
                first = self.klines(sym, "15m", 1, start=0)
                if not first:
                    return sym, "keine Kerzen vorhanden"
                have = (now - int(first[0][0])) // INTERVAL_MS
                if have < min_bars:
                    return sym, f"Historie zu kurz ({have * INTERVAL_MS / 86400000:.0f} Tage, benötigt {min_bars * INTERVAL_MS / 86400000:.0f})"
                rows = validate_rows(self.klines(sym, "15m", window), drop_last_open=True)
                cov = len(rows) / (window - 1)
                if cov < min_cov:
                    return sym, f"zu viele Lücken ({cov * 100:.0f} % der letzten {window} Kerzen vorhanden)"
                return sym, None
            except ClientError as e:
                return sym, f"nicht abrufbar ({e})"
            except Exception as e:
                return sym, ("NETZ", str(e))

        with ThreadPoolExecutor(max_workers=workers) as ex:
            res = list(ex.map(check, symbols))
        if any(isinstance(r, tuple) for _, r in res):
            return list(symbols), {}                    # Netzwerkproblem: nichts verwerfen
        bad = {s: r for s, r in res if r}
        return [s for s in symbols if s not in bad], bad

    def fng(self):
        try:
            d = self.rq.get("https://api.alternative.me/fng/?limit=1", timeout=8).json()["data"][0]
            return {"value": int(d["value"]), "label": d["value_classification"]}
        except Exception:
            return None


# ---------------------------------------------------------------------------------------------
# Synthetische Daten (deterministisch). NUR für Tests/Demo - keine Aussage über echte Märkte.
# ---------------------------------------------------------------------------------------------
REGIMES = {
    "bull":     dict(drift=0.00010, vol=0.0018, mean_rev=0.0, jump=0.0004),
    "bear":     dict(drift=-0.00010, vol=0.0020, mean_rev=0.0, jump=0.0005),
    "sideways": dict(drift=0.0, vol=0.0014, mean_rev=0.06, jump=0.0002),
    "highvol":  dict(drift=0.0, vol=0.0045, mean_rev=0.0, jump=0.002),
    "lowvol":   dict(drift=0.00002, vol=0.0007, mean_rev=0.02, jump=0.0),
    "crash":    dict(drift=-0.0006, vol=0.0045, mean_rev=0.0, jump=0.01),
}
BASE_PRICES = {"BTCUSDT": 68000.0, "ETHUSDT": 3500.0, "SOLUSDT": 170.0, "XRPUSDT": 0.55, "LINKUSDT": 16.0, "ADAUSDT": 0.45,
               "BNBUSDT": 600.0, "DOGEUSDT": 0.15, "AVAXUSDT": 35.0, "DOTUSDT": 6.0, "LTCUSDT": 85.0, "TRXUSDT": 0.16,
               "ATOMUSDT": 7.0, "NEARUSDT": 5.0, "UNIUSDT": 9.0, "AAVEUSDT": 160.0, "SUIUSDT": 1.8, "APTUSDT": 8.0,
               "ARBUSDT": 0.8, "OPUSDT": 1.8, "INJUSDT": 22.0, "FILUSDT": 4.0, "ETCUSDT": 20.0, "BCHUSDT": 450.0, "XLMUSDT": 0.11,
               "HBARUSDT": 0.07, "ICPUSDT": 9.0, "IMXUSDT": 1.3, "RUNEUSDT": 4.0, "MKRUSDT": 1500.0, "FETUSDT": 1.2,
               "TIAUSDT": 5.0, "SEIUSDT": 0.35, "STXUSDT": 1.5, "ALGOUSDT": 0.2, "VETUSDT": 0.03, "GRTUSDT": 0.2,
               "SANDUSDT": 0.4, "MANAUSDT": 0.4, "AXSUSDT": 6.0, "EGLDUSDT": 25.0, "CRVUSDT": 0.5, "LDOUSDT": 1.2,
               "SHIBUSDT": 0.00002, "WLDUSDT": 2.0, "TONUSDT": 5.5, "PEPEUSDT": 0.00001, "ENAUSDT": 0.4,
               "RENDERUSDT": 5.0, "GALAUSDT": 0.02}   # nur Startwerte für synthetische Demo-Daten
DEFAULT_PLAN = ["sideways", "bull", "highvol", "bear", "lowvol", "bull", "crash", "sideways", "bear", "bull"]


def generate_synthetic(symbols, n_bars, seed=1, plan=None, seg_len=500, start_ts=1_735_689_600_000):
    """Mehrere Marktphasen, korrelierte Coins, gelegentliche Kurslücken (Gaps) und Volumen-Spitzen."""
    rng = random.Random(seed)
    plan = plan or DEFAULT_PLAN
    out = {s: Series(s) for s in symbols}
    px = {s: BASE_PRICES.get(s, 10.0) for s in symbols}
    anchor = dict(px)
    beta = {s: 0.5 + 0.1 * (i % 5) for i, s in enumerate(symbols)}
    for i in range(n_bars):
        reg = REGIMES[plan[(i // seg_len) % len(plan)]]
        if i % seg_len == 0:
            anchor = dict(px)
        common = rng.gauss(0, reg["vol"])
        for s in symbols:
            idio = rng.gauss(0, reg["vol"])
            ret = reg["drift"] + beta[s] * common + (1 - beta[s] * 0.5) * idio
            ret += reg["mean_rev"] * math.log(anchor[s] / px[s])
            gap = 0.0
            if rng.random() < reg["jump"]:
                gap = rng.gauss(0, reg["vol"] * 6)
            o = px[s] * (1 + gap)
            c = o * math.exp(ret)
            wick = reg["vol"] * 0.6
            h = max(o, c) * (1 + abs(rng.gauss(0, wick)))
            l = min(o, c) * (1 - abs(rng.gauss(0, wick)))
            vol = rng.uniform(80, 120) * (1 + 6 * abs(ret) / reg["vol"] * 0.2) * (1.8 if abs(gap) > 0 else 1.0)
            out[s].append(Candle(start_ts + i * INTERVAL_MS, o, h, l, c, vol))
            px[s] = c
    return out
