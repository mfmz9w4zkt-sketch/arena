"""
Dashboard (nur Standardbibliothek): HTTP-Server mit JSON-Schnittstelle und einer Seite.
Login optional über DASHBOARD_PASSWORD (Benutzer: arena). Alles zeigt Paper-Trading-Spielgeld.
"""
from __future__ import annotations

import base64
import csv
import hmac
import io
import json
import math
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

from .analytics import compute_metrics, by_regime
from .config import HARD
from .regime import label


def clean(o):
    if isinstance(o, float):
        return "inf" if o == float("inf") else None if (math.isnan(o) or o == float("-inf")) else o
    if isinstance(o, dict):
        return {str(k): clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    return o


def down(curve, n=500):
    if len(curve) <= n:
        return [[t, round(e, 2)] for t, e in curve]
    step = len(curve) / n
    out = [curve[int(i * step)] for i in range(n)] + [curve[-1]]
    return [[t, round(e, 2)] for t, e in out]


def system_state(app, role, s):
    cfg = app.cfg
    prices = {sym: app.window[sym].c[-1] for sym in app.window} if app.window else {}
    team = s.team
    eq = team.equity(prices) if prices else cfg.start_equity
    m = compute_metrics(s.curve, s.team_closed, cfg.start_equity, cfg.interval_sec)
    st = s.risk.state(team.name)
    lim = s.risk.limits(s.params)
    day = max(0.0, (st.day_start - eq) / st.day_start) if st.day_start else 0.0
    week = max(0.0, (st.week_start - eq) / st.week_start) if st.week_start else 0.0
    tot = max(0.0, (st.peak - eq) / st.peak) if st.peak else 0.0
    pos = []
    for sym, p in team.positions.items():
        px = prices.get(sym, p.entry)
        info = p.lev_info or {}
        liq = s.ex.liq_for(p)
        pos.append({"sym": sym, "side": p.side, "lev": p.lev, "rec_lev": info.get("recommended_lev"), "tier_cap": info.get("tier_cap"),
                    "entry": p.entry, "price": px, "sl": p.sl, "tp": p.tp, "liq": liq, "liq_dist": abs(1 - liq / px),
                    "sl_dist": abs(1 - p.sl / px), "margin": p.margin, "mm": info.get("maintenance_margin"),
                    "fees": info.get("fee_est"), "slip": info.get("slippage_est"), "funding": p.funding_paid,
                    "max_loss": info.get("max_loss_sim"), "loss_stop": info.get("loss_at_stop"), "upnl": p.unreal(px),
                    "reason": info.get("reason"), "score": info.get("score"), "factors": info.get("factors"),
                    "risk_status": st.status, "regime": p.regime})
    agents = []
    bar = (s.last_ts or 0) // s.interval_ms
    for a in s.agents:
        acct = s.shadow.get(a.name)
        cur = s.shadow_curves.get(a.name, [])
        tr = s.shadow_closed.get(a.name, [])
        mm = compute_metrics(cur, tr, cfg.start_equity, cfg.interval_sec) if cur else None
        w = s.learner.weights.get(a.name, {})
        sg = {sym: [v.dir, round(v.conf, 2), v.reason] for sym, v in s.last_signals.get(a.name, {}).items() if v.dir}
        dis = a.name in s.learner.disabled_until
        agents.append({"name": a.name, "family": a.family, "in_team": a.in_team, "style": a.style,
                       "equity": s.shadow_equity.get(a.name, cfg.start_equity), "metrics": mm,
                       "weights": {k: round(v, 2) for k, v in w.items()}, "reliability": round(s.learner.reliability(a.name, bar), 2),
                       "stats": s.learner.agent_stats(a.name, bar), "disabled": dis,
                       "probation": a.name in s.learner.probation, "dead": s.dead.get(a.name), "llm_error": getattr(a, "last_error", ""), "signals": sg,
                       "status": s.risk.state(acct.name).status if acct else "-"})
    decisions = {sym: {"dir": d.dir, "score": round(d.score, 2), "agreement": round(d.agreement, 2), "conflict": round(d.conflict, 2),
                       "conf": round(d.conf, 2), "blocked": d.blocked, "reason": d.reason}
                 for sym, d in s.last_decisions.items()}
    reg = {sym: {"trend": r.trend, "vol": r.vol, "unusual": r.unusual, "fast": r.fast, "strength": round(r.strength, 2),
                 "vol_pct": round(r.vol_pct, 2)} for sym, r in s.last_regime.items()}
    rows = app.db.load_equity(s.name, 2000)
    return {"role": role, "version": s.name, "params": s.params, "equity": eq, "metrics": m,
            "regimes_perf": by_regime(s.team_closed),
            "risk": {"status": st.status, "reason": st.reason, "day": day, "week": week, "total": tot,
                     "limits": {"daily": HARD.max_daily_loss, "weekly": HARD.max_weekly_loss, "total": HARD.max_total_drawdown,
                                "risk_trade": lim.risk_trade, "max_lev": lim.max_lev, "exposure": lim.exposure,
                                "port_risk": lim.port_risk, "max_open": lim.max_open},
                     "exposure_x": team.exposure(prices) / eq if eq > 0 and prices else 0,
                     "rejects": dict(s.risk.rejects), "consec_losses": team.consec_losses},
            "team_dead": s.team_dead, "n_dead": len(s.dead), "positions": pos, "agents": agents, "decisions": decisions, "regime": reg,
            "curve": [[r[0], r[1], r[2]] for r in rows][-1500:],
            "learn": s.learn_log[-8:],
            "trades": list(reversed(app.db.load_trades(system=s.name, account=team.name, limit=60)))}


def build_state(app):
    with app.lock:
        systems = {role: system_state(app, role, s) for role, s in app.systems.items()}
        opts = app.db.optimizations("walkforward", 3)
        lev = app.db.optimizations("leverage", 1)
        return clean({
            "meta": {"demo": app.demo, "cycle": app.cycle, "now": int(time.time()), "opt_running": app.opt_running,
                     "symbols": list(app.cfg.symbols), "paper_only": True,
                     "hard": {"max_leverage": HARD.max_leverage, "risk_trade": HARD.max_risk_per_trade,
                              "daily": HARD.max_daily_loss, "weekly": HARD.max_weekly_loss, "total": HARD.max_total_drawdown},
                     "last_candle": app.window[app.cfg.symbols[0]].ts[-1] if app.window else None},
            "systems": systems,
            "cc": app.cc.to_dict(), "optimizations": opts, "leverage": lev[0] if lev else None,
            "events": app.db.events(40), "log": app.log[-12:]})


PAGE = r"""<!DOCTYPE html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>KI-Trading-Arena V3</title><style>
*{box-sizing:border-box}body{background:#0a0c0f;color:#e6e8eb;font-family:system-ui,-apple-system,sans-serif;margin:0 auto;padding:14px;max-width:1300px;font-size:13.5px}
h1{font-size:19px;margin:0}h2{font-size:14px;margin:0 0 8px;color:#c9d1d9}.mut{color:#8b95a1;font-size:11px}.up{color:#2ecc71}.down{color:#ff5b5b}.warn{color:#f1c40f}
.box{background:#12161b;border:1px solid #232a32;border-radius:10px;padding:12px;margin-bottom:12px}.row{display:flex;flex-wrap:wrap;gap:8px}
.chip{background:#14181d;border:1px solid #232a32;border-radius:14px;padding:3px 10px;font-size:12px}.chip.bad{border-color:#a62b2b;color:#ff5b5b}
.card{background:#0d1116;border:1px solid #232a32;border-radius:8px;padding:6px 10px;min-width:104px}.card small{display:block;color:#8b95a1;font-size:10px}.card b{font-size:15px}
table{width:100%;border-collapse:collapse;font-size:12px}td,th{padding:5px 6px;border-bottom:1px solid #1d242c;text-align:left;vertical-align:top;white-space:nowrap}th{color:#8b95a1;font-weight:500;font-size:10.5px}
td.w{white-space:normal}.scroll{overflow-x:auto}canvas{width:100%;height:300px;display:block}.bar{height:7px;background:#1d242c;border-radius:4px;overflow:hidden;min-width:90px}.bar i{display:block;height:100%;background:#2ecc71}
.btn{background:#1a2027;border:1px solid #2b333d;color:#c9d1d9;border-radius:6px;padding:4px 10px;font-size:12px;cursor:pointer}.btn.on{background:#24415f;border-color:#4da3ff}
.v{display:inline-block;min-width:34px;text-align:center;border-radius:4px;padding:1px 3px;font-size:11px}.vL{background:#12361f;color:#2ecc71}.vS{background:#3d1717;color:#ff5b5b}.v0{color:#4a5560}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}@media(max-width:950px){.grid{grid-template-columns:1fr}}
</style></head><body>
<div class="row" style="align-items:center;margin-bottom:10px"><h1>KI-Trading-Arena V3</h1><span class="chip warn">PAPER TRADING - nur Spielgeld, keine echten Orders</span><span id="chips" class="row"></span></div>
<div id="err" class="down mut"></div>
<div class="box"><div class="row" style="margin-bottom:6px"><button class="btn on" data-s="champion">Champion</button><button class="btn" data-s="challenger">Challenger</button>
<button class="btn" id="bOpt">Optimierung starten</button><button class="btn" id="bLev">Hebel-Studie starten</button><span class="mut" id="act"></span></div>
<canvas id="c"></canvas><div class="mut" id="leg"></div></div>
<div class="box"><h2>Kennzahlen (netto nach Gebühren, Slippage, Funding)</h2><div class="row" id="kpi"></div><div class="mut" id="basis" style="margin-top:6px"></div></div>
<div class="grid"><div class="box"><h2>Risikostatus</h2><div id="risk"></div></div><div class="box"><h2>Marktphase je Paar</h2><div class="scroll"><table id="reg"></table></div></div></div>
<div class="box scroll"><h2>Agenten (Schatten-Konto = echte Netto-Performance jedes Agenten)</h2><table id="ag"></table></div>
<div class="box scroll"><h2>Signalübereinstimmung und Team-Entscheidung</h2><table id="sig"></table></div>
<div class="box scroll"><h2>Offene Positionen (Team) - Hebel, Liquidation, Kosten</h2><table id="pos"></table></div>
<div class="grid"><div class="box scroll"><h2>Performance je Hebelstufe (Walk-forward, Hebel-Studie)</h2><table id="lev"></table><div class="mut" id="levn"></div></div>
<div class="box scroll"><h2>Champion / Challenger</h2><div id="cc"></div></div></div>
<div class="grid"><div class="box scroll"><h2>Optimierungsergebnisse (Walk-forward)</h2><div id="opt"></div></div><div class="box scroll"><h2>Letzte Lernzyklen (Gewichte)</h2><table id="lrn"></table></div></div>
<div class="box scroll"><h2>Historische Trades (Team)</h2><table id="tr"></table></div>
<div class="box"><h2>Ereignisse</h2><div class="mut" id="ev"></div></div>
<script>
const $=id=>document.getElementById(id);let D=null,role='champion',hover=null;
const COL=['#4da3ff','#ff9f43','#9aa4af'];
function el(t,c,x){const e=document.createElement(t);if(c)e.className=c;if(x!==undefined&&x!==null)e.textContent=x;return e}
function f(n,d){if(n===null||n===undefined||n==='')return '-';if(n==='inf')return '∞';d=d===undefined?2:d;return Number(n).toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d})}
function pc(n,d){return n===null||n===undefined?'-':(n>0?'+':'')+f(n*100,d===undefined?2:d)+' %'}
function cl(n){return n>0?'up':(n<0?'down':'')}
function tbl(t,head,rows){t.innerHTML='';const h=el('tr');head.forEach(x=>h.appendChild(el('th',null,x)));t.appendChild(h);
 rows.forEach(r=>{const tr=el('tr');r.forEach(c=>{let x=c;let k='';if(c&&typeof c==='object'&&c.t!==undefined){x=c.t;k=c.c||''}tr.appendChild(el('td',k,x))});t.appendChild(tr)})}
function S(){return D&&D.systems[role]||null}
async function load(){try{const r=await fetch('/api/state',{cache:'no-store'});if(!r.ok)throw new Error(r.status);D=await r.json();$('err').textContent='';if(!D.systems[role])role='champion';render()}catch(e){$('err').textContent='Verbindung gestört: '+e.message}}
function render(){const s=S();if(!s)return;chips(s);chart(s);kpi(s);risk(s);reg(s);agents(s);sig(s);pos(s);lev();cc();opt();lrn(s);trs(s);$('ev').textContent=D.events.map(e=>new Date(e.ts).toISOString().slice(5,16)+' '+e.kind+' '+e.account+' '+e.detail).join('  |  ')||'keine'}
function chips(s){const c=$('chips');c.innerHTML='';const a=(t,b)=>c.appendChild(el('span','chip'+(b?' bad':''),t));
 if(D.meta.demo)a('DEMO: synthetische Kurse');a('Version '+s.version);a('Durchlauf #'+D.meta.cycle);if(D.meta.last_candle)a('Letzte Kerze '+new Date(D.meta.last_candle).toISOString().slice(5,16)+' UTC');
 a('Risikostatus: '+s.risk.status,s.risk.status!=='OK');a('☠ gestorbene KI-Agenten: '+s.n_dead,s.n_dead>0);if(s.team_dead)a('☠ TEAM-KONTO AUFGEBRAUCHT',true);if(D.meta.opt_running)a('Optimierung läuft')}
function chart(s){const c=$('c'),r=window.devicePixelRatio||1,W=c.clientWidth,Ht=c.clientHeight;c.width=W*r;c.height=Ht*r;const g=c.getContext('2d');g.scale(r,r);
 const series=[];['champion','challenger'].forEach((k,i)=>{if(D.systems[k])series.push({n:k==='champion'?'Champion v'+D.systems[k].version.slice(1):'Challenger v'+D.systems[k].version.slice(1),col:COL[i],v:D.systems[k].curve.map(p=>[p[0],p[1]])})});
 series.push({n:'Bitcoin halten',col:COL[2],v:s.curve.map(p=>[p[0],p[2]]),dash:[6,4]});
 const all=[];series.forEach(x=>x.v.forEach(p=>{if(p[1]!==null)all.push(p[1])}));if(!all.length){g.fillStyle='#8b95a1';g.fillText('Warte auf Daten ...',20,30);return}
 let mn=Math.min.apply(null,all.concat([1000])),mx=Math.max.apply(null,all.concat([1000]));if(mx===mn){mx+=1;mn-=1}
 let t0=Infinity,t1=-Infinity;series.forEach(x=>x.v.forEach(p=>{t0=Math.min(t0,p[0]);t1=Math.max(t1,p[0])}));const PL=50,PR=10,PT=10,PB=18;
 const X=t=>PL+(t1>t0?(t-t0)/(t1-t0):0)*(W-PL-PR),Y=v=>Ht-PB-(v-mn)/(mx-mn)*(Ht-PT-PB);g.font='11px sans-serif';
 for(let k=0;k<=4;k++){const v=mn+(mx-mn)*k/4,y=Y(v);g.strokeStyle='#1d242c';g.beginPath();g.moveTo(PL,y);g.lineTo(W-PR,y);g.stroke();g.fillStyle='#8b95a1';g.fillText(f(v,0),4,y+4)}
 series.forEach(x=>{g.strokeStyle=x.col;g.lineWidth=2;g.setLineDash(x.dash||[]);g.beginPath();let st=false;x.v.forEach(p=>{if(p[1]===null)return;if(st)g.lineTo(X(p[0]),Y(p[1]));else g.moveTo(X(p[0]),Y(p[1]));st=true});g.stroke()});g.setLineDash([]);
 $('leg').innerHTML='';series.forEach(x=>{const sp=el('span',null,x.n+'  ');sp.style.color=x.col;$('leg').appendChild(sp)})}
function kpi(s){const m=s.metrics,k=$('kpi');k.innerHTML='';const add=(l,v,c)=>{const d=el('div','card');d.appendChild(el('small',null,l));const b=el('b',c||'',v);d.appendChild(b);k.appendChild(d)};
 add('Kontowert',f(s.equity));add('Gesamtrendite (netto)',pc(m.net_return),cl(m.net_return));add('Nettogewinn',f(m.net_pnl),cl(m.net_pnl));add('Profit Factor',f(m.profit_factor));add('Sharpe',f(m.sharpe));add('Sortino',f(m.sortino));
 add('Max. Drawdown',pc(-m.max_drawdown,1));add('Trades',m.trades);add('Trefferquote',m.win_rate===null?'-':f(m.win_rate*100,0)+' %');add('Gebühren',f(m.fees));add('Slippage',f(m.slippage));add('Funding',f(m.funding));add('Liquidationen',m.liquidations);
 $('basis').textContent='Sharpe/Sortino-Basis: '+m.ratio_basis+'. Ziele (keine Garantie): PF > 1,5, Sharpe > 1,5, Drawdown < 10-15 %.'}
function bar(v,lim){const w=Math.min(100,v/lim*100),b=el('div','bar'),i=el('i');i.style.width=w+'%';i.style.background=w>=100?'#ff5b5b':w>70?'#f1c40f':'#2ecc71';b.appendChild(i);return b}
function risk(s){const r=s.risk,b=$('risk');b.innerHTML='';const line=(n,v,l)=>{const d=el('div');d.style.margin='4px 0';d.appendChild(el('span',null,n+': '+f(v*100,2)+' % von '+f(l*100,0)+' % Limit'));d.appendChild(bar(v,l));b.appendChild(d)};
 line('Tagesverlust',r.day,r.limits.daily);line('Wochenverlust',r.week,r.limits.weekly);line('Gesamt-Drawdown',r.total,r.limits.total);
 b.appendChild(el('div','mut','Exposure '+f(r.exposure_x)+'x (max '+f(r.limits.exposure,1)+'x) | Risiko je Trade max '+f(r.limits.risk_trade*100,2)+' % | Hebel max '+r.limits.max_lev+'x | Positionen max '+r.limits.max_open+' | Verlustserie '+r.consec_losses));
 if(r.reason)b.appendChild(el('div','down',r.reason));b.appendChild(el('div','mut','Abgelehnt: '+(Object.keys(r.rejects).map(k=>k+' ('+r.rejects[k]+')').join(', ')||'-')))}
function reg(s){tbl($('reg'),['Paar','Trend','Volatilität','Ungewöhnlich','Schnell','Stärke'],Object.keys(s.regime).map(k=>{const r=s.regime[k];return [k.replace('USDT',''),{t:r.trend==='up'?'Aufwärts':r.trend==='down'?'Abwärts':'Seitwärts',c:r.trend==='up'?'up':r.trend==='down'?'down':''},r.vol+' ('+f(r.vol_pct,2)+')',r.unusual?'ja':'-',r.fast?'ja':'-',f(r.strength)]}))}
function agents(s){tbl($('ag'),['Agent','Team','Wert','Netto %','PF','Sharpe','Sortino','Max DD','Trades','Gewicht ges./auf/ab/seit','Zuverl.','Mean R (untere Gr.)','Status'],s.agents.map(a=>{const m=a.metrics||{};
 return [a.name,a.in_team?'ja':'nein (Baseline)',f(a.equity),{t:pc(m.net_return),c:cl(m.net_return)},f(m.profit_factor),f(m.sharpe),f(m.sortino),pc(m.max_drawdown?-m.max_drawdown:0,1),m.trades,
 [a.weights.all,a.weights.up,a.weights.down,a.weights.range].map(x=>f(x,2)).join(' / '),f(a.reliability),f(a.stats.mean_r,2)+' ('+f(a.stats.lcb,2)+')',a.llm_error?{t:'KI-Fehler: '+a.llm_error,c:'down w'}:a.dead?{t:'☠ gestorben '+new Date(a.dead.ts).toISOString().slice(0,10),c:'down'}:a.disabled?{t:'deaktiviert',c:'down'}:a.probation?{t:'Bewährung',c:'warn'}:a.status==='OK'?'aktiv':a.status]}))}
function sig(s){const t=$('sig');const syms=D.meta.symbols;const h=['Agent'].concat(syms.map(x=>x.replace('USDT','')));const rows=s.agents.map(a=>[a.name].concat(syms.map(x=>{const v=a.signals[x];return v?{t:(v[0]>0?'L ':'S ')+f(v[1],2),c:v[0]>0?'up':'down'}:'-'})));
 rows.push(['TEAM-Entscheidung'].concat(syms.map(x=>{const d=s.decisions[x];if(!d)return '-';return d.blocked?{t:f(d.score,2)+' ('+d.blocked+')',c:'mut'}:{t:(d.dir>0?'LONG ':'SHORT ')+f(d.score,2),c:d.dir>0?'up':'down'}})));
 rows.push(['Übereinstimmung / Konflikt'].concat(syms.map(x=>{const d=s.decisions[x];return d?f(d.agreement*100,0)+' % / '+f(d.conflict*100,0)+' %':'-'})));tbl(t,h,rows)}
function pos(s){tbl($('pos'),['Paar','Seite','Hebel','empf. Hebel (Obergr.)','Einstieg','Aktuell','Stop (Abst.)','Ziel','Liquidation (Abst.)','Init. Margin','Maint. Margin','Kosten (Gebühr/Slip/Fund.)','Max. Verlust (Stop / Sim.)','G/V','Begründung'],
 s.positions.map(p=>[p.sym.replace('USDT',''),{t:p.side>0?'LONG':'SHORT',c:p.side>0?'up':'down'},p.lev+'x',(p.rec_lev||'-')+'x ('+(p.tier_cap||'-')+'x)',f(p.entry,p.entry<10?4:2),f(p.price,p.price<10?4:2),f(p.sl,p.sl<10?4:2)+' ('+f(p.sl_dist*100,2)+' %)',f(p.tp,p.tp<10?4:2),
 f(p.liq,p.liq<10?4:2)+' ('+f(p.liq_dist*100,1)+' %)',f(p.margin),f(p.mm),f(p.fees)+' / '+f(p.slip)+' / '+f(p.funding),f(p.loss_stop)+' / '+f(p.max_loss),{t:f(p.upnl),c:cl(p.upnl)},{t:p.reason||'-',c:'w'}]))}
function lev(){const L=D.leverage;if(!L){tbl($('lev'),['Hinweis'],[['Noch keine Hebel-Studie. Oben "Hebel-Studie starten" (Walk-forward, feste Stufen 1-20x).']]);$('levn').textContent='';return}
 const d=L.data;tbl($('lev'),['Hebel','Netto %','PF','Sharpe','Sortino','Max DD','Trades','Liq.','Gebühren','Funding','Margin-Anteil','Unsicher abgelehnt','Score'],d.rows.map(r=>[{t:r.level+'x'+(r.level===d.selected?' (gewählt)':'')+(r.level===d.highest_return_level?' (höchste Rendite)':''),c:r.level===d.selected?'up':''},pc(r.net_return),f(r.pf),f(r.sharpe),f(r.sortino),pc(-r.mdd,1),r.trades,r.liq,f(r.fees),f(r.funding),pc(r.util,1),r.rejected_unsafe,f(r.score,2)]));$('levn').textContent=d.note}
function cc(){const b=$('cc');b.innerHTML='';const c=D.cc;b.appendChild(el('div',null,'Champion: Version '+c.champion.version+' - '+(c.champion.note||'')));
 b.appendChild(el('div',null,c.challenger?'Challenger: Version '+c.challenger.version+' (Walk-forward robust, läuft isoliert im Paper Trading)':'Challenger: keiner aktiv'));
 b.appendChild(el('div','mut','Frühere Champions (Rollback möglich): '+(c.history.map(h=>'v'+h.version).join(', ')||'-')));
 b.appendChild(el('div',null,'Protokoll:'));c.log.slice(-6).reverse().forEach(l=>b.appendChild(el('div','mut',new Date(l.ts).toISOString().slice(0,16)+' '+l.kind+' '+l.detail)))}
function opt(){const b=$('opt');b.innerHTML='';if(!D.optimizations.length){b.appendChild(el('div','mut','Noch keine Optimierung (läuft automatisch alle 24 h oder per Knopf).'));return}
 const o=D.optimizations[0].data;b.appendChild(el('div',o.robust?'up':'warn','Walk-forward '+(o.robust?'ROBUST':'NICHT robust')+' | OOS Netto '+pc(o.oos.net_return)+', PF '+f(o.oos.profit_factor)+', Sharpe '+f(o.oos.sharpe)+', Max DD '+pc(-o.oos.max_drawdown,1)+', Trades '+o.oos.trades+' | Methode: '+o.backend));
 b.appendChild(el('div','mut','Prüfungen: '+Object.keys(o.checks).map(k=>k+':'+(o.checks[k]?'ok':'nein')).join(', ')));const t=el('table');b.appendChild(t);
 tbl(t,['Fold','Train-Score','Basis-Score','OOS Netto','OOS Trades','OOS PF'],o.folds.map(x=>[x.fold,f(x.train_score,2),f(x.baseline_score,2),pc(x.oos_net),x.oos_trades,f(x.oos_pf)]))}
function lrn(s){tbl($('lrn'),['Zeit','Gewichte (gesamt)','Ereignisse'],s.learn.slice().reverse().map(l=>[new Date(l.ts).toISOString().slice(5,16),{t:Object.keys(l.weights).map(k=>k+' '+f(l.weights[k],2)).join(', '),c:'w'},{t:(l.events||[]).join('; ')||'-',c:'w'}]))}
function trs(s){tbl($('tr'),['Schluss','Paar','Seite','Hebel','Einstieg','Ausstieg','Netto','R','Gebühren','Slip.','Funding','Haltedauer','Max. Rückgang','Grund'],s.trades.map(t=>[new Date(t.close_ts).toISOString().slice(5,16),t.symbol.replace('USDT',''),t.side>0?'L':'S',t.lev+'x',f(t.entry,t.entry<10?4:2),f(t.exit,t.exit<10?4:2),{t:f(t.net_pnl),c:cl(t.net_pnl)},f(t.r_multiple),f(t.fees),f(t.slippage),f(t.funding),t.hold_bars+' Kerzen',pc(t.max_adverse_pct,1),t.reason]))}
document.querySelectorAll('[data-s]').forEach(b=>b.onclick=()=>{role=b.dataset.s;document.querySelectorAll('[data-s]').forEach(x=>x.classList.toggle('on',x===b));if(D&&D.systems[role])render()});
function post(u){fetch(u,{method:'POST'}).then(r=>r.json()).then(j=>{$('act').textContent=JSON.stringify(j).slice(0,160)}).catch(e=>{$('act').textContent=e.message})}
$('bOpt').onclick=()=>post('/api/optimize');$('bLev').onclick=()=>post('/api/leverage');
window.addEventListener('resize',()=>{if(D)render()});load();setInterval(load,15000);
</script></body></html>"""


def make_handler(app, password):
    class H(BaseHTTPRequestHandler):
        def _send(self, code, body, ctype, extra=None):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            self.wfile.write(body)

        def _auth(self):
            if not password:
                return True
            exp = "Basic " + base64.b64encode(("arena:" + password).encode()).decode()
            if hmac.compare_digest(self.headers.get("Authorization", ""), exp):
                return True
            self._send(401, b"Login erforderlich", "text/plain", {"WWW-Authenticate": 'Basic realm="Arena"'})
            return False

        def do_GET(self):
            if not self._auth():
                return
            path = urlparse(self.path).path
            try:
                if path == "/":
                    return self._send(200, PAGE.encode(), "text/html; charset=utf-8")
                if path == "/api/state":
                    return self._send(200, json.dumps(build_state(app)).encode(), "application/json")
                if path == "/api/health":
                    return self._send(200, b'{"ok":true}', "application/json")
                if path == "/api/export/trades.csv":
                    buf = io.StringIO()
                    w = csv.writer(buf)
                    w.writerow(["close_ts", "system", "symbol", "side", "lev", "entry", "exit", "net_pnl", "fees", "slippage", "funding", "reason"])
                    for s in app.systems.values():
                        for t in app.db.load_trades(system=s.name, account=s.team.name):
                            w.writerow([t["close_ts"], t["system"], t["symbol"], t["side"], t["lev"], t["entry"], t["exit"],
                                        t["net_pnl"], t["fees"], t["slippage"], t["funding"], t["reason"]])
                    return self._send(200, buf.getvalue().encode("utf-8-sig"), "text/csv; charset=utf-8",
                                      {"Content-Disposition": "attachment; filename=trades.csv"})
                return self._send(404, b"nicht gefunden", "text/plain")
            except Exception as e:
                return self._send(500, str(e).encode(), "text/plain")

        def do_POST(self):
            if not self._auth():
                return
            path = urlparse(self.path).path
            try:
                if path == "/api/optimize":
                    threading.Thread(target=app.optimize_job, daemon=True).start()
                    return self._send(200, b'{"started":true}', "application/json")
                if path == "/api/leverage":
                    threading.Thread(target=app.leverage_job, daemon=True).start()
                    return self._send(200, b'{"started":true}', "application/json")
                return self._send(404, b"nicht gefunden", "text/plain")
            except Exception as e:
                return self._send(500, str(e).encode(), "text/plain")

        def log_message(self, *a):
            pass
    return H


def serve(app, host="127.0.0.1", port=8000, password=None):
    password = password if password is not None else os.environ.get("DASHBOARD_PASSWORD", "")
    srv = ThreadingHTTPServer((host, port), make_handler(app, password))
    srv.serve_forever()
