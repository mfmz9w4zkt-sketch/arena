"""
Testsuite KI-Trading-Arena V3. Läuft komplett offline (synthetische Daten, kein Netzwerk, keine KI-Kosten).
Die Nummern (T01 ...) entsprechen dem Testplan; "S" = Sicherheitsprüfungen des Hebel-Managers (Abschnitt 16.10).
"""
import dataclasses
import glob
import json
import os
import py_compile
import sys
import threading
import unittest
import urllib.request
import base64

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from arena_v3.config import Config, HARD, SAFE_LIMITS, DEFAULT_SYMBOLS, clamp_params, PARAM_SPACE, DEFAULT_PARAMS, LIVE_TRADING_IMPLEMENTED
from arena_v3.data import generate_synthetic, Candle, validate_rows, Series
from arena_v3.agents import MarketCtx, build_agents, Signal, NEUTRAL
from arena_v3.regime import Regime
from arena_v3.sim import (ExecutionSimulator, Account, liq_price, maintenance_margin, mm_tier, TIERS, FUND_MS)
from arena_v3.risk import RiskEngine, OrderRequest, LeverageManager
from arena_v3.learning import MetaLearner, SignalAggregator
from arena_v3.system import TradingSystem
from arena_v3.backtest import run_backtest, walk_forward, folds_for, evaluate_oos
from arena_v3.champion import ChampionChallenger
from arena_v3.db import DB

CFG = Config(symbols=DEFAULT_SYMBOLS[:6])      # Tests mit 6 Paaren (schnell); das 50er-Standarduniversum prüft T21_Universum
SYMS = list(CFG.symbols)
MON = 1736121600000   # Montag 2025-01-06 00:00 UTC


def small_cfg(**kw):
    return dataclasses.replace(CFG, **kw)


def mkreq(**kw):
    d = dict(sym="BTCUSDT", side=1, ref_price=100.0, atr_pct=0.004, vol_pct=0.3, conf=0.8, agreement=0.9, exp_ret=0.012,
             stop_dist=0.008, tp_dist=0.016, trail_atr=0.0, reliability=0.8, ts=MON, regime_trend="up")
    d.update(kw)
    return OrderRequest(**d)


def fresh_risk(cfg=CFG):
    ex = ExecutionSimulator(cfg)
    return RiskEngine(cfg, ex), ex


_DATA = {}


def data(n=2000, seed=3):
    if (n, seed) not in _DATA:
        _DATA[(n, seed)] = generate_synthetic(SYMS, n, seed=seed)
    return _DATA[(n, seed)]


class T01_Syntax_Import(unittest.TestCase):
    def test_T01_syntax_aller_python_dateien(self):
        files = glob.glob(os.path.join(ROOT, "**", "*.py"), recursive=True)
        self.assertGreater(len(files), 10)
        for f in files:
            py_compile.compile(f, doraise=True)

    def test_T02_importpruefung(self):
        import importlib
        for m in ("config", "indicators", "data", "sim", "regime", "agents", "learning", "risk", "system", "analytics", "db",
                  "backtest", "optimizer", "champion", "llm_agents", "app", "dashboard"):
            importlib.import_module("arena_v3." + m)

    def test_S_nur_paper_trading_keine_echten_orders(self):
        self.assertFalse(LIVE_TRADING_IMPLEMENTED)
        for f in glob.glob(os.path.join(ROOT, "arena_v3", "*.py")):
            src = open(f, encoding="utf-8").read()
            self.assertNotIn("requests.post", src, f)
            self.assertNotIn("/api/v3/order", src, f)
            self.assertNotIn("/fapi/v1/order", src, f)
            self.assertNotIn("X-MBX-APIKEY", src, f)


class T03_Demo_und_Zyklen(unittest.TestCase):
    def test_T03_demo_modus_und_dashboarddaten(self):
        from arena_v3.app import ArenaApp
        from arena_v3.dashboard import build_state
        cfg = small_cfg()
        app = ArenaApp(cfg, demo=True, db_path=":memory:")
        for _ in range(4):
            app.tick()
        self.assertGreaterEqual(app.cycle, 3)
        st = build_state(app)
        json.dumps(st)
        self.assertIn("champion", st["systems"])
        self.assertTrue(st["meta"]["paper_only"])

    def test_T04_ein_vollstaendiger_zyklus(self):
        m = MarketCtx(data())
        s = TradingSystem("t", CFG)
        for i in range(1, CFG.warmup_bars + 3):
            s.step(m, i)
        self.assertTrue(s.last_signals)
        self.assertEqual(set(s.last_signals), {a.name for a in s.agents})
        self.assertTrue(s.last_decisions)
        self.assertTrue(s.curve)

    def test_T05_mehrere_aufeinanderfolgende_zyklen(self):
        m = MarketCtx(data())
        s = TradingSystem("t", CFG)
        for i in range(1, 1500):
            s.step(m, i)
        eq = [e for _, e in s.curve]
        self.assertTrue(all(e == e and abs(e) < 1e9 for e in eq))
        self.assertGreater(len(s.team_closed) + sum(len(v) for v in s.shadow_closed.values()), 20)
        for a, acct in s.shadow.items():
            self.assertGreaterEqual(acct.cash, -1e-6, a)


class T06_Kooperation(unittest.TestCase):
    def setUp(self):
        self.agents = build_agents()
        self.am = {a.name: a for a in self.agents}
        self.learner = MetaLearner(CFG, self.am)
        self.agg = SignalAggregator(CFG, clamp_params(None), self.agents)
        self.reg = Regime("up", "normal", False, False, 2.0, 0.4)

    def sigs(self, longs=(), shorts=(), conf=0.8):
        d = {a.name: NEUTRAL for a in self.agents}
        for n in longs:
            d[n] = Signal(1, conf, 0.012, 0.008, "t")
        for n in shorts:
            d[n] = Signal(-1, conf, 0.012, 0.008, "t")
        return d

    def test_T06_agenten_kooperation_gemeinsame_entscheidung(self):
        d = self.agg.decide("BTCUSDT", self.sigs(longs=["Momentum", "Trendfolger", "Breakout", "Vorsichtig"]), self.learner, self.reg, 100, MON)
        self.assertEqual(d.dir, 1)
        self.assertIsNone(d.blocked)
        self.assertGreater(d.agreement, 0.9)
        self.assertEqual(len([p for p in d.parts if p["dir"] == 1]), 4)

    def test_T06b_ein_einzelner_agent_loest_keinen_trade_aus(self):
        d = self.agg.decide("BTCUSDT", self.sigs(longs=["Momentum"], conf=1.0), self.learner, self.reg, 100, MON)
        self.assertIsNotNone(d.blocked)

    def test_T06c_zufalls_baseline_zaehlt_nicht_zum_team(self):
        d = self.agg.decide("BTCUSDT", self.sigs(longs=["Zufall"]), self.learner, self.reg, 100, MON)
        self.assertNotIn("Zufall", [p["agent"] for p in d.parts])

    def test_T07_widerspruechliche_signale(self):
        d = self.agg.decide("BTCUSDT", self.sigs(longs=["Momentum", "Trendfolger"], shorts=["Contrarian", "Mean Reversion"]),
                            self.learner, self.reg, 100, MON)
        self.assertIsNotNone(d.blocked)
        self.assertGreater(d.conflict, 0.4)

    def test_T07b_gegensignal_schliesst_position(self):
        m = MarketCtx(data())
        s = TradingSystem("t", CFG)
        for i in range(1, 700):
            s.step(m, i)
        from arena_v3.sim import Position
        i = 700
        ts = m.s("BTCUSDT").ts[i - 1]
        px = m.s("BTCUSDT").c[i - 1]
        s.team.positions.clear(); s.pend_team.clear(); s.risk.states.clear()     # sauberer Ausgangszustand (kein Risiko-Lock)
        s.team.positions["BTCUSDT"] = Position("BTCUSDT", 1, 0.001, px, 1, 0.001 * px, 0.001 * px, px * 0.5, px * 2.0, 0.0, ts, 0.1, px, 1.0, oid="x")
        orig = s.agg.decide
        from arena_v3.learning import Decision
        s.agg.decide = lambda sym, *a, **k: Decision(sym, -1, -0.9, 0.95, 0.0, 0.9, 0.01, 0.01, [], "Test", None)
        s.step(m, i)
        self.assertEqual(s.pend_team.get("BTCUSDT", {}).get("kind"), "close")


class T08_Gewichtung(unittest.TestCase):
    def setUp(self):
        self.agents = build_agents()
        self.am = {a.name: a for a in self.agents}
        self.L = MetaLearner(CFG, self.am)

    def feed(self, agent, rs, bar0=1000):
        for k, r in enumerate(rs):
            self.L.record(agent, bar0 + k, "up", r)

    def test_T08_gute_agenten_mehr_gewicht_schlechte_weniger(self):
        self.feed("Momentum", [0.9, -0.2, 0.8, 0.7, -0.1] * 16)           # 80 Trades, klar positiv (+0,42 R)
        self.feed("Breakout", [-0.9, 0.2, -0.8, -0.7, 0.1] * 16)          # 80 Trades, klar negativ
        for k in range(6):
            self.L.update(1100 + 96 * k)
        self.assertGreater(self.L.weights["Momentum"]["all"], 1.2)
        self.assertLess(self.L.weights["Breakout"]["all"], 0.7)

    def test_T08b_kurzfristiges_glueck_wird_nicht_belohnt(self):
        self.feed("Momentum", [1.0] * 8)                                  # nur 8 Gewinner < n_min
        for k in range(6):
            self.L.update(1100 + 96 * k)
        self.assertLess(self.L.weights["Momentum"]["all"], 1.15)

    def test_T08c_statistisch_schlechter_agent_wird_deaktiviert_und_bewaehrung(self):
        self.feed("Scalper", [-1.0, -0.8, -1.0, -0.6] * 15)
        self.L.update(1100)
        self.assertIn("Scalper", self.L.disabled_until)
        self.assertEqual(self.L.weight("Scalper", "up", 1101), 0.0)
        later = int(self.L.disabled_until["Scalper"]) + 1
        self.L.update(later)
        self.assertIn("Scalper", self.L.probation)
        self.assertLessEqual(self.L.weight("Scalper", "up", later), 0.3)

    def test_T08d_gewichte_bleiben_begrenzt(self):
        self.feed("Momentum", [3.0] * 400)
        for k in range(30):
            self.L.update(2000 + 96 * k)
        self.assertLessEqual(self.L.weights["Momentum"]["all"], CFG.w_max + 1e-9)


class T09_Kosten(unittest.TestCase):
    def test_T09_gebuehrenberechnung(self):
        cfg = small_cfg(half_spread=0.0, slip_base=0.0, slip_vol_mult=0.0)
        ex = ExecutionSimulator(cfg)
        a = Account("a", 1000.0, 1000.0)
        ex.open_position(a, "BTCUSDT", 1, 5000.0, 10, 0.01, 0.02, 0, 100.0, 0.004, MON, 50.0)
        t = ex.close_market(a, "BTCUSDT", 100.0, MON + 900000, "test", 0.004)
        self.assertAlmostEqual(t.fees, 2 * cfg.fee_taker * 5000.0, places=6)
        self.assertAlmostEqual(t.net_pnl, -t.fees, places=6)
        self.assertAlmostEqual(a.cash, 1000.0 - t.fees, places=6)

    def test_T10_funding_konstant_konservativ_beide_seiten_zahlen(self):
        ex = ExecutionSimulator(CFG)
        for side in (1, -1):
            a = Account("a", 1000.0, 1000.0)
            p = ex.open_position(a, "BTCUSDT", side, 1000.0, 5, 0.05, 0.05, 0, 100.0, 0.004, MON + 27_000_000, 10.0)
            c = Candle(MON + FUND_MS, 100.0, 100.5, 99.5, 100.0, 1)
            m0 = p.margin
            ex.apply_funding(a, p, c, MON + 27_000_000)
            self.assertAlmostEqual(m0 - p.margin, CFG.funding_const_8h * p.qty * 100.0, places=8)

    def test_T10b_funding_echte_raten_mit_vorzeichen_und_genau_ein_intervall(self):
        ex = ExecutionSimulator(CFG)
        a_l, a_s = Account("l", 1000.0, 1000.0), Account("s", 1000.0, 1000.0)
        pl = ex.open_position(a_l, "BTCUSDT", 1, 1000.0, 5, 0.05, 0.05, 0, 100.0, 0.004, MON + 27_000_000, 10.0)
        ps = ex.open_position(a_s, "BTCUSDT", -1, 1000.0, 5, 0.05, 0.05, 0, 100.0, 0.004, MON + 27_000_000, 10.0)
        fund = {MON + FUND_MS: 0.0003}
        c = Candle(MON + FUND_MS, 100.0, 100.5, 99.5, 100.0, 1)
        ex.apply_funding(a_l, pl, c, MON + 27_000_000, fund)
        ex.apply_funding(a_s, ps, c, MON + 27_000_000, fund)
        self.assertGreater(pl.funding_paid, 0)         # Long zahlt bei positiver Rate
        self.assertLess(ps.funding_paid, 0)            # Short erhält
        again = pl.funding_paid
        ex.apply_funding(a_l, pl, Candle(MON + FUND_MS + 900000, 100, 101, 99, 100, 1), MON + FUND_MS, fund)
        self.assertEqual(pl.funding_paid, again)       # nicht doppelt belastet


class T11_Stops_Liquidation(unittest.TestCase):
    def test_T11_stop_loss_ausfuehrung_mit_slippage(self):
        ex = ExecutionSimulator(CFG)
        a = Account("a", 1000.0, 1000.0)
        p = ex.open_position(a, "BTCUSDT", 1, 1000.0, 2, 0.01, 0.05, 0, 100.0, 0.004, MON, 10.0)
        sl = p.sl
        t = ex.process_candle(a, "BTCUSDT", Candle(MON + 900000, 100.0, 100.2, sl - 0.5, sl - 0.2, 1), 0.004, MON)[0]
        self.assertIn("Stop-Loss", t.reason)
        self.assertLess(t.exit, sl)                    # Stop wird NICHT exakt zum Wunschpreis ausgeführt
        self.assertLess(t.net_pnl, 0)

    def test_T11b_kurzluecke_wird_zum_schlechteren_eroeffnungskurs_ausgefuehrt(self):
        ex = ExecutionSimulator(CFG)
        a = Account("a", 1000.0, 1000.0)
        p = ex.open_position(a, "BTCUSDT", 1, 1000.0, 2, 0.01, 0.05, 0, 100.0, 0.004, MON, 10.0)
        t = ex.process_candle(a, "BTCUSDT", Candle(MON + 900000, 95.0, 96.0, 94.0, 95.0, 1), 0.004, MON)[0]
        self.assertIn("Gap", t.reason)
        self.assertLess(t.exit, p.sl)
        self.assertLess(t.exit, 95.0)
        self.assertGreater(abs(t.net_pnl), t.notional * 0.01)   # Verlust größer als der geplante Stop-Abstand

    def test_T11c_stop_slippage_groesser_als_normale_slippage(self):
        ex = ExecutionSimulator(CFG)
        self.assertGreater(ex.stop_slip(0.004), ex.slip(0.004))

    def test_T12_liquidationspreis_formel_und_buchung(self):
        for side in (1, -1):
            q, e, m = 10.0, 100.0, 100.0           # 10x
            lp = liq_price(side, q, e, m, 0.0)
            rate, cum = mm_tier(q * e)
            equity = m + side * (lp - e) * q
            self.assertAlmostEqual(equity, q * lp * rate - cum, places=6)     # Equity == Maintenance Margin
        ex = ExecutionSimulator(CFG)
        a = Account("a", 1000.0, 1000.0)
        p = ex.open_position(a, "BTCUSDT", 1, 10000.0, 20, 0.04, 0.05, 0, 100.0, 0.004, MON, 100.0)
        liq = ex.liq_for(p)
        t = ex.process_candle(a, "BTCUSDT", Candle(MON + 900000, 99.0, 99.5, liq - 1, liq, 1), 0.004, MON)[0]
        self.assertTrue(t.liquidated)
        self.assertAlmostEqual(t.net_pnl, -(p.margin0 + p.open_fee), places=6)        # Margin + Gebühr, nicht mehr
        self.assertAlmostEqual(a.cash, 1000.0 - p.margin0 - p.open_fee, places=6)      # kein Nachschuss, kein Minus
        self.assertEqual(a.liquidations, 1)

    def test_S_maintenance_margin_stufen(self):
        self.assertEqual(mm_tier(1000)[0], 0.004)
        self.assertEqual(mm_tier(60_000)[0], 0.005)
        self.assertEqual(mm_tier(300_000)[0], 0.01)
        self.assertEqual(mm_tier(2_000_000)[0], 0.025)
        self.assertAlmostEqual(maintenance_margin(100_000), 100_000 * 0.005 - 50.0)
        prev = 0
        for n in (10_000, 49_999, 50_000, 249_999, 250_000, 999_999, 1_000_000):   # stetig, steigend
            mm = maintenance_margin(n)
            self.assertGreaterEqual(mm, prev)
            prev = mm


class T13_DB(unittest.TestCase):
    def test_T13_datenbankpersistenz(self):
        db = DB(":memory:")
        m = MarketCtx(data())
        s = TradingSystem("t", CFG)
        for i in range(1, 1000):
            s.step(m, i)
        trades, events = s.pop_new()
        self.assertTrue(trades)
        for t in trades:
            db.save_trade(t)
        for e in events:
            db.add_event(e["ts"], "t", e["account"], e["kind"], e["detail"])
        db.kv_set("x", {"a": [1, 2, 3]})
        db.save_params("champion", 1, DEFAULT_PARAMS)
        db.save_candles("BTCUSDT", [[1, 1, 2, 0.5, 1.5, 10], [2, 1, 2, 0.5, 1.5, 10]])
        self.assertEqual(len(db.load_trades(system="t")), len(trades))
        self.assertEqual(db.kv_get("x"), {"a": [1, 2, 3]})
        self.assertEqual(db.params_history()[0]["params"], DEFAULT_PARAMS)
        self.assertEqual(len(db.load_candles("BTCUSDT")), 2)
        self.assertTrue(db.register_order("o1"))
        self.assertFalse(db.register_order("o1"))                         # doppelte Order abgelehnt

    def test_T13b_datei_datenbank_ueberlebt_neuoeffnen(self):
        import tempfile
        p = os.path.join(tempfile.mkdtemp(), "t.db")
        db = DB(p)
        db.kv_set("k", 42)
        db.close()
        self.assertEqual(DB(p).kv_get("k"), 42)


class T14_Neustart(unittest.TestCase):
    def test_T14_neustart_gleiches_ergebnis_wie_durchlauf(self):
        m = MarketCtx(data(1600))
        a = TradingSystem("t", CFG)
        for i in range(1, 1400):
            a.step(m, i)
        b = TradingSystem("t", CFG)
        for i in range(1, 900):
            b.step(m, i)
        state = json.loads(json.dumps(b.to_dict()))                       # wie aus der Datenbank
        c = TradingSystem("t", CFG)
        c.load_dict(state)
        for i in range(900, 1400):
            c.step(m, i)
        self.assertAlmostEqual(a.curve[-1][1], c.curve[-1][1], places=6)
        self.assertEqual(len(a.team_closed), len(c.team_closed))
        self.assertEqual({k: round(v, 6) for k, v in a.shadow_equity.items()}, {k: round(v, 6) for k, v in c.shadow_equity.items()})

    def test_T14b_schutz_vor_doppelten_trades(self):
        m = MarketCtx(data())
        s = TradingSystem("t", CFG)
        for i in range(1, 400):
            s.step(m, i)
        ts = m.s("BTCUSDT").ts[399]
        order = {"kind": "open", "side": 1, "conf": 0.8, "agreement": 0.9, "exp_ret": 0.015, "stop_dist": 0.008, "tp_dist": 0.02,
                 "trail_atr": 0.0, "reliability": 0.8, "trend": "up", "unusual": False, "vol_label": "normal", "vol_pct": 0.3,
                 "atr_pct": 0.004, "liquidity": 0.9, "agent": "team", "regime": "up/normal", "decision_ts": ts, "fund_rate": None}
        s.team.positions.clear(); s.team.cooldown.clear(); s.pend_team.clear(); s.risk.states.clear()
        s.team.cash = CFG.start_equity                                      # Margin der entfernten Positionen zurückbuchen
        s.pend_team["BTCUSDT"] = dict(order)
        s.step(m, 400)
        self.assertIn("BTCUSDT", s.team.positions)
        s.team.positions.pop("BTCUSDT")
        s.pend_team["BTCUSDT"] = dict(order)
        s.step(m, 401)
        self.assertNotIn("BTCUSDT", s.team.positions)                      # identische Order wird nicht erneut ausgeführt


class T15_Backtest(unittest.TestCase):
    cfg = small_cfg(wf_train_bars=900, wf_test_bars=400, wf_step_bars=400, opt_trials=2, opt_segments=2)

    def test_T15_backtest_reproduzierbar_mit_kosten(self):
        d = data(1800)
        r1 = run_backtest(d, self.cfg, None, start=400, end=1800)
        r2 = run_backtest(d, self.cfg, None, start=400, end=1800)
        self.assertEqual(r1["metrics"]["net_return"], r2["metrics"]["net_return"])
        self.assertEqual(len(r1["trades"]), len(r2["trades"]))
        if r1["trades"]:
            self.assertGreater(r1["metrics"]["fees"], 0)
            self.assertGreater(r1["metrics"]["slippage"], 0)

    def test_T15b_kein_lookahead_signale_unabhaengig_von_zukunftsdaten(self):
        full = data(900)
        cut = {s: full[s].slice(0, 700) for s in SYMS}
        a, b = MarketCtx(full), MarketCtx(cut)
        for ag in build_agents():
            for s in SYMS:
                self.assertEqual(ag.signal(a, s, 699), ag.signal(b, s, 699), (ag.name, s))
        self.assertEqual(a.regime["BTCUSDT"][699], b.regime["BTCUSDT"][699])

    def test_T15c_ergebnis_unabhaengig_von_daten_nach_dem_testende(self):
        d = data(1500)
        noisy = {s: Series(s, list(d[s].ts), list(d[s].o), list(d[s].h), list(d[s].l), list(d[s].c), list(d[s].v)) for s in SYMS}
        for s in SYMS:
            for i in range(1200, 1500):
                for arr in (noisy[s].o, noisy[s].h, noisy[s].l, noisy[s].c):
                    arr[i] = arr[i] * 3.0
        r1 = run_backtest(d, self.cfg, None, start=400, end=1200)
        r2 = run_backtest(noisy, self.cfg, None, start=400, end=1200)
        self.assertEqual(r1["metrics"]["net_return"], r2["metrics"]["net_return"])        # keine Datenleckage


class T16_WalkForward(unittest.TestCase):
    cfg = T15_Backtest.cfg

    def test_T16_walk_forward_fenster_ohne_ueberlappung_und_oos_auswertung(self):
        d = data(2400)
        folds = folds_for(2400, self.cfg)
        self.assertGreaterEqual(len(folds), 2)
        for a, b, c in folds:
            self.assertLess(a, b)
            self.assertEqual(b, a + self.cfg.wf_train_bars)
            self.assertGreater(c, b)                                       # Test liegt strikt NACH dem Training
        rep = walk_forward(d, self.cfg, n_trials=2)
        self.assertEqual(rep["n_folds"], len(folds))
        for f in rep["folds"]:
            self.assertLessEqual(f["train"][1], f["test"][0])
            self.assertIn("params", f)
            for k, v in f["params"].items():
                lo, hi, _ = PARAM_SPACE[k]
                self.assertTrue(lo <= v <= hi)
        self.assertIn("checks", rep)

    def test_T16b_optimierung_nutzt_nur_erlaubten_parameterraum(self):
        from arena_v3.optimizer import sample
        import random
        rng = random.Random(1)
        for _ in range(200):
            p = sample(rng)
            self.assertLessEqual(p["team.risk_frac"], HARD.max_risk_per_trade)
            self.assertLessEqual(p["lev.cap"], HARD.max_leverage)
            self.assertLessEqual(p["mom.ema_fast"], p["mom.ema_slow"])


class T17_ChampionChallenger(unittest.TestCase):
    def rep(self, robust=True):
        m = {"net_return": 0.05, "profit_factor": 1.6, "sharpe": 1.2, "sortino": 1.5, "max_drawdown": 0.06, "trades": 60}
        return {"robust": robust, "checks": {"pf": robust, "mdd": True}, "metrics": m, "positive_fold_fraction": 0.8}

    def good(self):
        return {"net_return": 0.04, "profit_factor": 1.5, "sharpe": 1.1, "sortino": 1.3, "max_drawdown": 0.05, "trades": 40}

    def test_T17_challenger_nur_nach_robustem_walk_forward(self):
        cc = ChampionChallenger(CFG)
        self.assertFalse(cc.propose({"mom.ema_fast": 9}, self.rep(False))["accepted"])
        self.assertIsNone(cc.challenger)
        self.assertTrue(cc.propose({"mom.ema_fast": 9}, self.rep(True))["accepted"])
        self.assertIsNotNone(cc.challenger)

    def test_T17b_befoerderung_nur_bei_allen_kriterien(self):
        cc = ChampionChallenger(CFG)
        cc.propose({"mom.ema_fast": 9}, self.rep(True))
        weak = dict(self.good(), trades=5)
        reg = {"Bull": {"trades": 10, "net_pnl": 5.0}, "Bear": {"trades": 8, "net_pnl": 2.0}}
        self.assertFalse(cc.evaluate_promotion(weak, reg, {"net_return": 0.0, "profit_factor": 1.0, "sharpe": 0, "sortino": 0, "max_drawdown": 0.05, "trades": 40, "liquidations": 0}, 1)["promote"])
        self.assertEqual(cc.champion["version"], 1)
        champ_m = {"net_return": 0.0, "profit_factor": 1.0, "sharpe": 0.0, "sortino": 0.0, "max_drawdown": 0.05, "trades": 40, "liquidations": 0}
        good = dict(self.good(), liquidations=0)
        self.assertTrue(cc.evaluate_promotion(good, reg, champ_m, 2)["promote"])
        self.assertEqual(cc.champion["version"], 2)
        self.assertIsNone(cc.challenger)

    def test_T17c_automatischer_rollback(self):
        cc = ChampionChallenger(CFG)
        cc.propose({"mom.ema_fast": 9}, self.rep(True))
        reg = {"Bull": {"trades": 10, "net_pnl": 5.0}, "Bear": {"trades": 8, "net_pnl": 2.0}}
        cc.evaluate_promotion(dict(self.good(), liquidations=0), reg, {"net_return": 0.0, "profit_factor": 1.0, "sharpe": 0, "sortino": 0, "max_drawdown": 0.05, "trades": 40, "liquidations": 0}, 2)
        self.assertEqual(cc.champion["version"], 2)
        bad = {"net_return": -0.08, "profit_factor": 0.6, "sharpe": -1, "sortino": -1, "max_drawdown": 0.2, "trades": 30}
        self.assertTrue(cc.check_rollback(bad, 3)["rollback"])
        self.assertEqual(cc.champion["version"], 1)
        self.assertEqual(cc.champion["params"], DEFAULT_PARAMS)


class T18_Notfall(unittest.TestCase):
    def test_T18_notfallabschaltung_gesamt_drawdown(self):
        rk, ex = fresh_risk()
        a = Account("a", 1000.0, 1000.0)
        self.assertIsNone(rk.update(a, 1000.0, MON))
        self.assertEqual(rk.update(a, 495.0, MON + 900000), "close_all")
        self.assertEqual(rk.state("a").status, "EMERGENCY")
        self.assertEqual(rk.update(a, 1100.0, MON + 1800000), "halt")        # bleibt gesperrt, auch bei Erholung
        ap = rk.approve(a, {"BTCUSDT": 100.0}, mkreq(), clamp_params(None), 0)
        self.assertFalse(ap.ok)
        self.assertIn("EMERGENCY", ap.reason)
        self.assertEqual(rk.events[0]["kind"], "NOTFALL")                   # dauerhaft protokolliert
        rk.reset_emergency("a")
        self.assertEqual(rk.state("a").status, "OK")

    def test_T18b_system_schliesst_positionen_bei_notfall(self):
        m = MarketCtx(data())
        s = TradingSystem("t", CFG, shadow=False)
        for i in range(1, 500):
            s.step(m, i)
        from arena_v3.sim import Position
        ts = m.s("BTCUSDT").ts[499]
        px = m.s("BTCUSDT").c[499]
        s.team.positions.clear()
        s.team.positions["BTCUSDT"] = Position("BTCUSDT", 1, 0.01, px, 10, 0.001 * px, 0.001 * px, px * 0.5, px * 2.0, 0.0, ts, 0.1, px, 1.0, oid="n")
        s.team.cash = 300.0                                                  # Equity ca. 370 statt 1000: Drawdown > 50 %
        s.step(m, 500)
        self.assertEqual(s.risk.state(s.team.name).status, "EMERGENCY")
        self.assertFalse(s.team.positions)
        self.assertFalse(s.pend_team)
        self.assertTrue(any(e["kind"] == "NOTFALL" for e in s.new_events))


class S_Hebel_und_Risiko(unittest.TestCase):
    def test_S_hebelgrenze_technisch_erzwungen(self):
        self.assertEqual(clamp_params({"lev.cap": 500})["lev.cap"], HARD.max_leverage)
        rk, ex = fresh_risk(small_cfg(fixed_lev=500, lev_mode="fixed"))
        self.assertLessEqual(rk.limits(clamp_params({"lev.cap": 999})).max_lev, HARD.max_leverage)
        a = Account("a", 100000.0, 100000.0)
        for stop in (0.003, 0.004, 0.006, 0.01):
            ap = rk.approve(a, {"BTCUSDT": 100.0}, mkreq(stop_dist=stop, tp_dist=stop * 3, exp_ret=stop * 3), clamp_params(None), 0)
            if ap.ok:
                self.assertLessEqual(ap.lev, HARD.max_leverage)
        for lev in (1, 5, 20, 100, 125, 500):
            rk2, _ = fresh_risk(small_cfg(fixed_lev=lev, lev_mode="fixed"))
            ap = rk2.approve(Account("b", 1000.0, 1000.0), {"BTCUSDT": 100.0}, mkreq(stop_dist=0.004, tp_dist=0.012, exp_ret=0.012), clamp_params(None), 0)
            if ap.ok:
                self.assertLessEqual(ap.lev, HARD.max_leverage)

    def test_S_positionsgroesse_aus_risiko_nicht_aus_hebel(self):
        rk, ex = fresh_risk()
        for stop in (0.004, 0.008, 0.02):
            a = Account("a", 1000.0, 1000.0)
            ap = rk.approve(a, {"BTCUSDT": 100.0}, mkreq(stop_dist=stop, tp_dist=stop * 3, exp_ret=stop * 3), clamp_params(None), 0)
            self.assertTrue(ap.ok, ap.reason)
            self.assertLessEqual(ap.risk_amount, HARD.max_risk_per_trade * 1000.0 + 1e-9)    # <= Risiko-Hardlimit der Equity
            self.assertLessEqual(ap.info["loss_at_stop"], HARD.max_risk_per_trade * 1000.0 + 1e-9)
            self.assertLessEqual(ap.notional / ap.lev, CFG.max_margin_share * 1000.0 + 1e-6)                 # Margin-Anteil begrenzt

    def test_S_stop_loss_immer_vor_liquidation_mit_sicherheitsabstand(self):
        for lev_mode, lev in (("adaptive", 1), ("fixed", 5), ("fixed", 10), ("fixed", 20), ("fixed", 50), ("fixed", 100)):
            rk, ex = fresh_risk(small_cfg(lev_mode=lev_mode, fixed_lev=lev))
            for side in (1, -1):
                for stop in (0.003, 0.005, 0.01, 0.03):
                    a = Account("a", 1000.0, 1000.0)
                    ap = rk.approve(a, {"BTCUSDT": 100.0}, mkreq(side=side, stop_dist=stop, tp_dist=max(0.02, stop * 2), exp_ret=0.03), clamp_params(None), 0)
                    if not ap.ok:
                        continue
                    sl_price = 100.0 * (1 - side * ap.sl_dist)
                    liq = ap.info["liq_price"]
                    self.assertTrue((side > 0 and liq < sl_price) or (side < 0 and liq > sl_price), (lev_mode, lev, side, stop))
                    self.assertGreaterEqual(ap.info["liq_distance"], HARD.min_liq_safety_mult * ap.info["sl_distance"])

    def test_S_zu_riskante_trades_werden_abgelehnt(self):
        rk, ex = fresh_risk()
        a = Account("a", 1000.0, 1000.0)
        self.assertFalse(rk.approve(a, {"BTCUSDT": 100.0}, mkreq(exp_ret=0.002, tp_dist=0.003), clamp_params(None), 0).ok)   # Kosten fressen Gewinn
        a2 = Account("a", 1000.0, 1000.0)
        ap = rk.approve(a2, {"BTCUSDT": 100.0}, mkreq(stop_dist=0.5), clamp_params(None), 0)                                # riesiger Stop wird begrenzt
        self.assertTrue((not ap.ok) or ap.sl_dist <= 0.08)
        a3 = Account("a", 1000.0, 1000.0)
        a3.cooldown["BTCUSDT"] = 100
        self.assertFalse(rk.approve(a3, {"BTCUSDT": 100.0}, mkreq(), clamp_params(None), 50).ok)                              # Cooldown nach Stop

    def test_S_tages_wochen_gesamt_limits(self):
        rk, ex = fresh_risk()
        a = Account("a", 1000.0, 1000.0)
        rk.update(a, 1000.0, MON)
        self.assertEqual(rk.update(a, 840.0, MON + 3_600_000), "close_losers")          # -16 % am Tag
        self.assertEqual(rk.state("a").status, "DAILY_LOCK")
        self.assertFalse(rk.approve(a, {"BTCUSDT": 100.0}, mkreq(), clamp_params(None), 0).ok)
        rk.update(a, 840.0, MON + 86_400_000 + 1000)                                     # neuer Tag
        self.assertEqual(rk.state("a").status, "OK")
        rk2, _ = fresh_risk()
        b = Account("b", 1000.0, 1000.0)
        for d, eq in enumerate((1000, 950, 900, 850, 800)):
            rk2.update(b, float(eq), MON + d * 86_400_000)
        act = rk2.update(b, 690.0, MON + 4 * 86_400_000 + 3_600_000)                     # -31 % in der Woche
        self.assertEqual(rk2.state("b").status, "WEEKLY_LOCK")
        self.assertIsNotNone(act)

    def test_S_keine_hebelerhoehung_nach_verlusten_und_drawdown(self):
        lm = LeverageManager()
        rk, ex = fresh_risk()
        lim = rk.limits(clamp_params(None))
        f = {"signal": .95, "reliability": .9, "vol": .8, "regime": 1.0, "liquidity": .9, "cost": .9, "util": .9, "corr": 1.0,
             "drawdown": 1.0, "agreement": .95, "unusual": False}
        caps = []
        for losses in range(0, 8):
            caps.append(lm.decide(f, CFG, lim, losses)[1])
        self.assertEqual(caps, sorted(caps, reverse=True))
        self.assertLess(caps[-1], caps[0])
        prev = 999
        for dd in (1.0, .8, .6, .4, .2, 0.0):
            c = lm.decide(dict(f, drawdown=dd), CFG, lim, 0)[1]
            self.assertLessEqual(c, prev)
            prev = c

    def test_S_hohe_confidence_allein_loest_keinen_hohen_hebel_aus(self):
        lm = LeverageManager()
        rk, ex = fresh_risk()
        lim = rk.limits(clamp_params(None))
        f = {"signal": 1.0, "reliability": 0.0, "vol": 1.0, "regime": 1.0, "liquidity": 1.0, "cost": 1.0, "util": 1.0, "corr": 1.0,
             "drawdown": 1.0, "agreement": 1.0, "unusual": False}
        self.assertLessEqual(lm.decide(f, CFG, lim, 0)[1], 5)                       # ohne statistische Grundlage max. 5x
        f2 = dict(f, reliability=0.9)
        self.assertEqual(lm.decide(f2, CFG, lim, 0)[1], HARD.max_leverage)         # nur mit Beleg + allen Prüfungen
        self.assertLessEqual(lm.decide(dict(f2, unusual=True), CFG, lim, 0)[1], 20)      # ungewöhnlicher Markt: kein 35x+

    def test_S_kein_martingale_risiko_sinkt_nach_verlustserie(self):
        rk, ex = fresh_risk()
        base = Account("a", 1000.0, 1000.0)
        loss = Account("b", 1000.0, 1000.0)
        loss.consec_losses = 4
        r0 = rk.approve(base, {"BTCUSDT": 100.0}, mkreq(), clamp_params(None), 0)
        r1 = rk.approve(loss, {"BTCUSDT": 100.0}, mkreq(), clamp_params(None), 0)
        self.assertTrue(r0.ok and r1.ok)
        self.assertLess(r1.risk_amount, r0.risk_amount)

    def test_S_keine_umgehung_der_grenzen_durch_agenten_optimierer_konfiguration(self):
        with self.assertRaises(dataclasses.FrozenInstanceError):
            HARD.max_leverage = 100
        p = clamp_params({"team.risk_frac": 0.5, "lev.cap": 1000, "team.stop_atr": -4})
        self.assertLessEqual(p["team.risk_frac"], HARD.max_risk_per_trade)
        self.assertLessEqual(p["lev.cap"], HARD.max_leverage)
        rk, ex = fresh_risk(small_cfg(risk_frac=0.5, max_margin_share=5.0))
        a = Account("a", 1000.0, 1000.0)
        ap = rk.approve(a, {"BTCUSDT": 100.0}, mkreq(conf=1.0, agreement=1.0, exp_ret=0.5, tp_dist=0.5, reliability=1.0),
                        {"team.risk_frac": 9.9, "lev.cap": 999}, 0)
        if ap.ok:
            self.assertLessEqual(ap.risk_amount, HARD.max_risk_per_trade * 1000.0 + 1e-9)
            self.assertLessEqual(ap.lev, HARD.max_leverage)
        # System-Ebene: ein "übermütiger" Agent kann das Risiko nicht erhöhen
        m = MarketCtx(data())
        s = TradingSystem("t", CFG, {"team.risk_frac": 5.0, "lev.cap": 500})
        for i in range(1, 900):
            s.step(m, i)
        for t in s.team_closed:
            self.assertLessEqual(t.lev, HARD.max_leverage)
        self.assertLessEqual(s.risk.limits(s.params).risk_trade, HARD.max_risk_per_trade)

    def test_S_portfolio_exposure_und_gesamtrisiko_begrenzt(self):
        m = MarketCtx(data())
        s = TradingSystem("t", CFG)
        worst_exp, worst_risk = 0.0, 0.0
        for i in range(1, 1500):
            s.step(m, i)
            prices = {x: m.s(x).c[i] for x in SYMS}
            for acct in [s.team] + list(s.shadow.values()):
                eq = acct.equity(prices)
                if eq > 0:
                    worst_exp = max(worst_exp, acct.exposure(prices) / eq)
        self.assertLessEqual(worst_exp, HARD.max_portfolio_exposure_x * 1.6)       # Marktbewegung kann Quote kurz anheben, aber nicht explodieren
        self.assertLessEqual(max(len(a.positions) for a in [s.team] + list(s.shadow.values())), HARD.max_open_positions)


class T19_Tod(unittest.TestCase):
    def test_T19_ki_stirbt_wenn_geld_bei_null_ist_dauerhaft(self):
        m = MarketCtx(data())
        s = TradingSystem("t", CFG)
        for i in range(1, 700):
            s.step(m, i)
        acct = s.shadow["Momentum"]
        acct.positions.clear()
        acct.cash = s.death_threshold() * 0.5
        s.step(m, 700)
        self.assertIn("Momentum", s.dead)
        self.assertTrue(any(e["kind"] == "KI_GESTORBEN" for e in s.new_events))
        n = len(s.shadow_closed["Momentum"])
        for i in range(701, 1100):
            s.step(m, i)
        self.assertEqual(len(s.shadow_closed["Momentum"]), n)                      # keine Trades mehr
        self.assertFalse(s.shadow["Momentum"].positions)
        self.assertEqual(s.learner.weight("Momentum", "up", m.s("BTCUSDT").ts[1000] // 900000), 0.0)   # kein Stimmrecht im Team
        s2 = TradingSystem("t", CFG)
        s2.load_dict(json.loads(json.dumps(s.to_dict())))
        self.assertIn("Momentum", s2.dead)                                          # bleibt auch nach Neustart tot

    def test_T19b_team_konto_tod(self):
        m = MarketCtx(data())
        s = TradingSystem("t", CFG, shadow=False)
        for i in range(1, 500):
            s.step(m, i)
        s.team.positions.clear()
        s.team.cash = s.death_threshold() * 0.5
        s.step(m, 500)
        self.assertIsNotNone(s.team_dead)
        s.step(m, 501)
        self.assertFalse(s.team.positions)


class T20_Dashboard(unittest.TestCase):
    def test_T20_http_state_login_und_seite(self):
        from arena_v3.app import ArenaApp
        from arena_v3.dashboard import make_handler
        from http.server import ThreadingHTTPServer
        app = ArenaApp(small_cfg(), demo=True, db_path=":memory:")
        app.tick(); app.tick()
        srv = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(app, "pw"))
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        base = f"http://127.0.0.1:{srv.server_address[1]}"
        try:
            with self.assertRaises(Exception):
                urllib.request.urlopen(base + "/api/state")                           # ohne Login: 401
            req = urllib.request.Request(base + "/api/state", headers={"Authorization": "Basic " + base64.b64encode(b"arena:pw").decode()})
            st = json.loads(urllib.request.urlopen(req).read())
            self.assertIn("systems", st)
            req = urllib.request.Request(base + "/", headers={"Authorization": "Basic " + base64.b64encode(b"arena:pw").decode()})
            self.assertIn("KI-Trading-Arena V3", urllib.request.urlopen(req).read().decode())
        finally:
            srv.shutdown()



class T21_Universum_und_Aggressives_Profil(unittest.TestCase):
    def test_T21_standarduniversum_50_paare_gueltig(self):
        syms = Config().symbols
        self.assertEqual(len(syms), 50)
        self.assertEqual(len(set(syms)), len(syms))
        self.assertEqual(syms[0], "BTCUSDT")                                  # BTC = Referenzmarkt
        self.assertTrue(all(x.endswith("USDT") for x in syms))
        from arena_v3.data import BASE_PRICES
        self.assertTrue(all(x in BASE_PRICES for x in syms))

    def test_T21b_universum_laeuft_durch_50_paare(self):
        cfg = small_cfg(symbols=Config().symbols)
        d = generate_synthetic(list(cfg.symbols), 450, seed=5)
        m = MarketCtx(d)
        s = TradingSystem("u", cfg, shadow=False)
        for i in range(1, 450):
            s.step(m, i)
        self.assertLessEqual(len(s.team.positions), HARD.max_open_positions)
        self.assertGreater(s.team.equity({x: d[x].c[449] for x in d}), 0)

    def test_T21c_hohe_hebel_werden_tatsaechlich_genehmigt(self):
        rk, _ = fresh_risk()
        a = Account("a", 1000.0, 1000.0)
        ap = rk.approve(a, {"BTCUSDT": 100.0}, mkreq(conf=1.0, agreement=1.0, reliability=0.95, stop_dist=0.003, tp_dist=0.02,
                                                    exp_ret=0.02, atr_pct=0.0015, vol_pct=0.1), clamp_params(None), 0)
        self.assertTrue(ap.ok, ap.reason)
        self.assertGreaterEqual(ap.lev, 50)                                   # grosse Hebel sind jetzt moeglich
        self.assertLessEqual(ap.lev, HARD.max_leverage)
        liq = ap.info["liq_price"]
        self.assertLess(liq, 100.0 * (1 - ap.sl_dist))                        # Stop-Loss liegt trotzdem VOR der Liquidation
        self.assertLessEqual(ap.risk_amount, HARD.max_risk_per_trade * 1000.0 + 1e-9)

    def test_T21d_profile_und_alte_grenzen_als_referenz(self):
        self.assertGreater(HARD.max_leverage, SAFE_LIMITS.max_leverage)
        self.assertGreater(HARD.max_risk_per_trade, SAFE_LIMITS.max_risk_per_trade)
        self.assertGreater(HARD.min_liq_safety_mult, 1.0)                    # Stop muss immer vor der Liquidation liegen

    def test_T21e_binance_available_filtert_ungueltige_symbole(self):
        from arena_v3.data import BinanceClient
        c = BinanceClient.__new__(BinanceClient)
        def fake(symbol, interval="15m", limit=500, **kw):
            if symbol == "XXXUSDT":
                raise RuntimeError("API nicht erreichbar: 400 Client Error: Invalid symbol")
            return [[1, 1, 1, 1, 1, 1]]
        c.klines = fake
        ok, bad = c.available(["BTCUSDT", "XXXUSDT", "ETHUSDT"])
        self.assertEqual(ok, ["BTCUSDT", "ETHUSDT"])
        self.assertEqual(bad, ["XXXUSDT"])


class T22_Login_Cookie_und_Agenten_im_Dashboard(unittest.TestCase):
    """Anmeldeseite mit langlebigem Cookie statt ständiger Passwortabfrage; Agenten-Daten fürs Dashboard."""

    @classmethod
    def setUpClass(cls):
        from arena_v3.app import ArenaApp
        from arena_v3.dashboard import make_handler
        from http.server import ThreadingHTTPServer
        cls.app = ArenaApp(small_cfg(), demo=True, db_path=":memory:")
        for _ in range(60):
            cls.app.tick()
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(cls.app, "pw"))
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.port = cls.srv.server_address[1]

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def req(self, method, path, body=None, headers=None):
        import http.client
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        c.request(method, path, body=body, headers=headers or {})
        r = c.getresponse()
        data = r.read()
        return r.status, dict(r.getheaders()), data

    def login(self):
        st, hd, _ = self.req("POST", "/login", "password=pw", {"Content-Type": "application/x-www-form-urlencoded"})
        self.assertEqual(st, 303)
        return hd["Set-Cookie"]

    def test_T22_ohne_login_umleitung_und_401(self):
        st, hd, _ = self.req("GET", "/")
        self.assertEqual((st, hd["Location"]), (303, "/login"))
        self.assertEqual(self.req("GET", "/api/state")[0], 401)
        self.assertEqual(self.req("GET", "/api/trades")[0], 401)
        st, _, body = self.req("GET", "/login")
        self.assertEqual(st, 200)
        self.assertIn("Passwort", body.decode())

    def test_T22b_cookie_90_tage_httponly_und_funktioniert(self):
        sc = self.login()
        self.assertIn("HttpOnly", sc)
        self.assertIn("Max-Age=7776000", sc)
        self.assertIn("SameSite=Lax", sc)
        cookie = sc.split(";")[0]
        st, _, body = self.req("GET", "/", headers={"Cookie": cookie})
        self.assertEqual(st, 200)
        self.assertIn("KI-Trading-Arena V3", body.decode())
        st, _, body = self.req("GET", "/api/state", headers={"Cookie": cookie})
        self.assertEqual(st, 200)
        self.assertIn("systems", json.loads(body))
        st, _, body = self.req("GET", "/api/trades?role=champion&limit=5", headers={"Cookie": cookie})
        self.assertEqual(st, 200)
        self.assertLessEqual(len(json.loads(body)["trades"]), 5)

    def test_T22c_cookie_ueberlebt_neustart_manipulation_und_ablauf_werden_abgelehnt(self):
        from arena_v3.dashboard import Sessions
        val = self.login().split(";")[0].split("=", 1)[1]
        self.assertTrue(Sessions("pw").valid(val))                      # neuer Server, gleiches Passwort: weiter angemeldet
        self.assertFalse(Sessions("anderes").valid(val))                # anderes Passwort: ungültig
        exp, sig = val.split(".")
        self.assertFalse(Sessions("pw").valid(str(int(exp) + 999) + "." + sig))      # Ablaufzeit manipuliert
        self.assertFalse(Sessions("pw").valid("muell"))
        old = Sessions("pw").make(days=-1)
        self.assertFalse(Sessions("pw").valid(old))                     # abgelaufen

    def test_T22d_falsches_passwort_und_basic_auth_fuer_skripte(self):
        st, hd, _ = self.req("POST", "/login", "password=falsch", {"Content-Type": "application/x-www-form-urlencoded"})
        self.assertEqual(st, 401)
        self.assertNotIn("Set-Cookie", hd)
        auth = "Basic " + base64.b64encode(b"arena:pw").decode()
        self.assertEqual(self.req("GET", "/api/state", headers={"Authorization": auth})[0], 200)

    def test_T22e_logout_loescht_cookie(self):
        st, hd, _ = self.req("GET", "/logout")
        self.assertEqual((st, hd["Location"]), (303, "/login"))
        self.assertIn("Max-Age=0", hd["Set-Cookie"])

    def test_T22f_agenten_haben_verlauf_signale_positionen_trades(self):
        auth = "Basic " + base64.b64encode(b"arena:pw").decode()
        st = json.loads(self.req("GET", "/api/state", headers={"Authorization": auth})[2])
        ag = st["systems"]["champion"]["agents"]
        self.assertGreaterEqual(len(ag), 5)
        for a in ag:
            for k in ("name", "equity", "curve", "positions", "recent", "signals", "weights"):
                self.assertIn(k, a)
            self.assertLessEqual(len(a["curve"]), 80)
        self.assertTrue(any(a["recent"] for a in ag))

    def test_T22g_websocket_zustand_ohne_trades_und_mit_cookie(self):
        import socket
        cookie = self.login().split(";")[0]
        sk = socket.create_connection(("127.0.0.1", self.port), timeout=10)
        sk.sendall(("GET /ws HTTP/1.1\r\nHost: x\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                    "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\nSec-WebSocket-Version: 13\r\nCookie: " + cookie + "\r\n\r\n").encode())
        buf = b""
        while len(buf) < 4096 and b"\r\n\r\n" not in buf:
            buf += sk.recv(4096)
        self.assertIn(b"101", buf.split(b"\r\n")[0])
        sk.close()
        sk = socket.create_connection(("127.0.0.1", self.port), timeout=10)
        sk.sendall(b"GET /ws HTTP/1.1\r\nHost: x\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\nSec-WebSocket-Version: 13\r\n\r\n")
        self.assertIn(b"401", sk.recv(4096).split(b"\r\n")[0])           # ohne Anmeldung kein Live-Strom
        sk.close()

    def test_T22h_sperre_nach_fuenf_fehlversuchen(self):
        from arena_v3.dashboard import make_handler
        from http.server import ThreadingHTTPServer
        srv = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(self.app, "pw"))
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            import http.client
            codes = []
            for _ in range(7):
                c = http.client.HTTPConnection("127.0.0.1", srv.server_address[1], timeout=10)
                c.request("POST", "/login", body="password=x", headers={"Content-Type": "application/x-www-form-urlencoded"})
                codes.append(c.getresponse().status)
            self.assertEqual(codes[:5], [401] * 5)
            self.assertEqual(codes[5], 429)
        finally:
            srv.shutdown()


if __name__ == "__main__":
    unittest.main(verbosity=2)
