# KI-Trading-Arena V3 (nur Paper Trading / Spielgeld)

Kooperatives, selbstlernendes Multi-Agent-Trading-System mit Risiko-Engine, adaptivem Hebel-Manager (max. 125x, aggressives Profil),
Backtesting, Walk-forward-Validierung, Optimierer, Champion/Challenger und Dashboard.

**Es gibt keinen Live-Trading-Code. Es werden keine echten Orders gesendet. Es gibt keine Garantie auf Gewinne.**
Alle Beispielergebnisse stammen aus Zufallsdaten und belegen keine Profitabilität.

## Installation
```
python3 -m venv venv && source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt                          # Pflicht: requests. Optional: anthropic (KI-Agenten), optuna
```
Python 3.9 oder neuer (3.10+ empfohlen).

## Start
| Befehl | Zweck |
|---|---|
| `python start_v3.py demo` | Demo mit synthetischen Kursen (kostenlos, zeigt alle Funktionen) |
| `python start_v3.py live` | Paper Trading mit echten Binance-Kursen (öffentliche Daten, kein Key) |
| `python start_v3.py live --llm --cheap` | zusätzlich 3 KI-Agenten (Claude Haiku, kostet API-Guthaben, `ANTHROPIC_API_KEY` nötig) |
| `python start_v3.py backtest --synthetic` oder `--days 60` | Backtest |
| `python start_v3.py walkforward --days 90 --trials 20` | Walk-forward (Training/Test getrennt) |
| `python start_v3.py levstudy --days 90` | Hebel-Studie 1/2/5/10/20/35/50/75/100/125x |
| `python start_v3.py optimize` | einmal optimieren, ggf. Challenger anlegen |
| `python start_v3.py test` | alle Tests + `TESTREPORT.md` |
Dashboard: `http://localhost:8000` (Design im iOS-Glas-Stil, hell und dunkel, für iPhone und Desktop).
Von außen: `--host 0.0.0.0` und `DASHBOARD_PASSWORD="..."`. Du meldest dich **einmal** auf einer Anmeldeseite an; ein Cookie hält die Anmeldung
90 Tage (übersteht auch Neustarts des Servers, solange das Passwort gleich bleibt). Skripte können weiter Basic-Auth nutzen (Benutzer `arena`).
Nach 5 falschen Versuchen pro Minute wird gesperrt. Ohne HTTPS wird das Passwort unverschlüsselt übertragen: für Zugriff übers Internet einen Tunnel oder Reverse-Proxy mit HTTPS verwenden.

**Bereiche (untere Leiste):** Übersicht (Kontowert, Kennzahlen, Risiko, Kosten), Agenten (jeder Agent als Karte mit eigenem Verlauf;
Tippen öffnet Details mit Kennzahlen, Signalen, Positionen, Gewicht im Team und letzten Trades), Positionen, Trades (mit Suche und CSV), System.
Bedienelemente gibt es nur noch für Pause/Start, Champion/Challenger-Umschalter (wenn ein Challenger läuft) und den Zeitraum.
Optimierung läuft automatisch alle 24 Stunden; die Hebel-Studie startest du im Terminal: `python start_v3.py levstudy`.
Neustart-fest: Stand liegt in `arena_v3.db` (SQLite). Neu anfangen: `--reset`.

## Konfiguration
`config.example.json` kopieren, anpassen und mit `--config config.json` laden. Jeder Parameter ist in `arena_v3/config.py` dokumentiert.
**Hard Limits (aggressives Profil, nur Paper!)** - im Code fest, per Konfiguration/Optimierer/Agent NICHT änderbar:
Hebel 125x, Risiko 5 % je Trade, Tagesverlust 15 %, Wochenverlust 30 %, Gesamt-Drawdown 50 % (Notfallabschaltung),
Exposure 40x, Portfoliorisiko 15 %, max. 50 Positionen (pro Coin höchstens eine, real begrenzt durch die Anzahl der Coins und das Portfoliorisiko), Stop-Loss liegt immer vor der Liquidation (Sicherheitsfaktor 1,2).
Das frühere konservative Profil (20x, 1 %, 3 %, 6 %, 10 %) steht als `SAFE_LIMITS` in `config.py` zum Vergleich.
**Märkte:** 50 USDT-Paare (u. a. BTC, ETH, SOL, XRP, BNB, ADA, DOGE, AVAX, LINK, DOT, LTC, TRX, ATOM, NEAR, UNI, AAVE, SUI, APT, ARB, OP, INJ, TON, PEPE; vollständige Liste: `DEFAULT_SYMBOLS` in `config.py`).
Eigene Liste: `--symbols BTCUSDT,ETHUSDT,...` oder `symbols` in der Config (BTCUSDT ist Referenzmarkt). Nicht abrufbare Paare (z. B. delistet) werden beim Start übersprungen. Neuere Coins haben kürzere Historie; Daten werden auf den gemeinsamen Zeitraum gekürzt.

## Wie der Hebel entschieden wird (wichtig)
Die Positionsgröße kommt aus dem erlaubten Verlust bei Stop-Loss (inkl. Gebühren, Spread, Slippage, Funding) - nicht aus dem Hebel.
Der Hebel folgt einer Stufenleiter 2 / 5 / 10 / 20 / 35 / 50 / 75 / 100 / 125x. Die Stufen-Obergrenze hängt ab von Signalqualität,
Zuverlässigkeit, Volatilität, Marktphase, Liquidität, Kosten, Auslastung, Korrelation, Drawdown und Verlustserie; 75-125x nur mit
`experimental_high_leverage` und sehr strengen Prüfungen. Standard ist `lev_policy: "tier_pref"` (Hebel passend zur Stufe);
`"min_feasible"` nimmt stattdessen den kleinsten Hebel, der die Position finanziert. Zusätzlich begrenzt der Liquidations-Sicherheitsabstand
den Hebel: je weiter der Stop und je höher die Volatilität, desto niedriger der maximal mögliche Hebel (hohe Hebel gehen nur bei engem Stop).
`lev_rel_floor` (Standard 0.5) setzt eine Mindest-Zuverlässigkeit für die Hebelstufe; mit 0 wird streng statistisch entschieden
(ohne Schatten-Konten, z. B. im Backtest, bleibt der Hebel dann bei max. 5x).
**Achtung:** Diese Einstellungen sind für Spielgeld gedacht. Mit echtem Geld wären 5 % Risiko je Trade und 50 % Drawdown-Limit extrem gefährlich.

## KI stirbt bei Geld = 0
Jeder Agent hat ein eigenes Schatten-Konto. Fällt dessen Equity auf 0 (praktisch: unter 0,08 USDT, `death_equity`), stirbt der Agent
dauerhaft: Positionen werden geschlossen, er gibt keine Signale mehr ab, hat kein Stimmrecht im Team, das Ereignis `KI_GESTORBEN`
wird gespeichert und bleibt auch nach Neustart bestehen (Wiederbelebung nur mit `--reset`). Das gilt auch für das Team-Konto
(`TEAM_GESTORBEN`). Hinweis: Wegen der 1 %-Regel und der Limits dauert es bei schlechten Agenten lange, bis das Konto 0 erreicht.
Wer es früher will, setzt `death_equity` höher (z. B. 500 = Tod bei -50 %).

## Änderungen/Bugfixes während der Entwicklung
Sharpe-Berechnung (Startwert fehlte), Aggregator-Qualitätsfaktor (schlechte Agenten dürfen das Team nicht antreiben), Funding-Vorzeichen,
Gap-Ausführung, mehrere Testannahmen. Details: Git-freie Historie siehe TESTREPORT.md.


## Fehlerbehebung: "zu wenige Kerzen" / leeres Dashboard
Alle Paare laufen auf einer gemeinsamen Zeitachse (BTCUSDT). Früher kürzte eine einzige fehlende Kerze (Binance lässt Kerzen ohne Handel weg)
oder ein neu gelistetes Paar die Daten aller Paare unter das Minimum. Jetzt gilt:
- Beim Start prüft `python start_v3.py live` jedes Paar (existiert, genug Historie, kaum Lücken) und nennt die übersprungenen mit Grund.
- Fehlende Kerzen werden als flache Kerze (Volumen 0) ergänzt. Fällt ein einzelner Abruf aus, werden die letzten Daten dieses Paars weiterverwendet.
- Reicht es trotzdem nicht, steht im Log und im Dashboard, welches Paar schuld ist (z. B. `zu wenige Kerzen: XYZUSDT hat nur 86`). Dann mit `--symbols` ohne dieses Paar starten.
- Nach dem Start erscheint das erste Ergebnis erst mit der nächsten 15-Minuten-Kerze (der Bot handelt bewusst erst ab der nächsten Kerze).


## Die Agenten (15 Regel-Agenten, optional 3 KI-Agenten)
Alle geben nur Signale ab (Richtung, Überzeugung, erwartete Bewegung, Risiko, Begründung). Das Team entscheidet daraus, danach der Risiko-Manager.
Jeder Agent hat ein Schatten-Konto; sein Teamgewicht folgt seiner echten Netto-Bilanz.

**1-10, optimiert:** Momentum, Mean Reversion, Breakout, Trendfolger, Vorsichtig, Scalper, Contrarian, Diversifizierer, Regelbot EMA (feste Referenz), Zufall (Vergleich, nicht im Team).
Verbesserungen: Gegenbewegungs-Agenten handeln nicht gegen starke Trends; Momentum meidet erschöpfte Bewegungen (RSI-Extreme); Breakout verlangt Schluss am Kerzenextrem
(kein langer Docht) und meidet Nachrichtenspitzen; Scalper meidet ruhige Märkte (ATR < 0,3 %, Kosten fressen den Gewinn) und Kerzen, die nicht am Extrem schließen;
Trendfolger pausiert bei extremer Volatilität; der Diversifizierer wählt jetzt die oberen/unteren ~10 % des Universums (bei 50 Coins: je 5) statt fester Schwellen.

**11-15, neu (starten auf Bewährung: Teamgewicht höchstens 0,3, bis ihr Schatten-Konto genug Netto-Ergebnisse hat):**
| Agent | Analysiert | Daten |
|---|---|---|
| Orderbuch | Ungleichgewicht Käufer/Verkäufer, große Limit-Orders, Spread, Tiefe und deren Veränderung. Prüft, ob hinter der Kursbewegung echter Druck steht | nur live, nur die neueste Kerze (es gibt keine Orderbuch-Historie) |
| Derivate | Open Interest gegen Preis (neue Positionen oder Liquidation?), Funding, Long/Short-Verhältnis, Extremwerte | nur mit Futures-Daten |
| Liquidations-Agent | Geschätzte Liquidationszonen (aus Open-Interest-Zuwachs und Hebelstufen 5-100x, bereits ausgelöste Zonen entfallen), Stop-Cluster über gleichen Hochs/Tiefs, Sweeps, Squeeze-Magnete | Zonen: Futures-Daten; Stop-Cluster: nur Kerzen |
| Marktstruktur | Swing-Hochs/-Tiefs, BOS, CHoCH, Fair Value Gaps, Liquidity Sweeps, Unterstützung/Widerstand | nur Kerzen (auch im Backtest) |
| Multi-Timeframe | Trend auf 15m, 1h, 4h und Tag (aus 15m-Kerzen zusammengesetzt, nur abgeschlossene höhere Kerzen). Einstieg nur, wenn der 15m-Rücksetzer zum übergeordneten Trend passt | nur Kerzen (auch im Backtest) |

**Wichtige Grenzen (ehrlich):**
- Orderbuch, Derivate und die Zonen des Liquidations-Agenten gibt es im Backtest, Walk-forward und Optimierer nicht (keine Historie). Dort bleiben sie neutral. Bewertet werden sie nur live über ihr Schatten-Konto.
- Liquidationszonen sind **Schätzungen** (kein echter Liquidations-Feed). Große Limit-Orders können gespooft sein; Signale daraus sind auf Überzeugung 0,7 gedeckelt.
- Binance liefert Open-Interest- und Long/Short-Verlauf nur für etwa 30 Tage. Paare ohne Futures-Kontrakt bleiben für diese Agenten neutral.
- Im Demo-Modus sind alle Zusatzdaten **synthetisch** (erfunden), nur um die Agenten zu zeigen.
- Das Datenfenster ist jetzt 1000 Kerzen (statt 700), damit die Tagesebene des Multi-Timeframe-Agenten berechenbar ist.
